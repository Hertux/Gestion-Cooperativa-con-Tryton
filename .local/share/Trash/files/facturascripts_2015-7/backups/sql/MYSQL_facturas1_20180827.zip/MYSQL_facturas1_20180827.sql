SET AUTOCOMMIT=0;
SET FOREIGN_KEY_CHECKS=0;
-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: facturas1
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `facturas1`
--

/*!40000 DROP DATABASE IF EXISTS `facturas1`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `facturas1` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `facturas1`;

--
-- Table structure for table `agenciastrans`
--

DROP TABLE IF EXISTS `agenciastrans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenciastrans` (
  `codtrans` varchar(8) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`codtrans`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenciastrans`
--

LOCK TABLES `agenciastrans` WRITE;
/*!40000 ALTER TABLE `agenciastrans` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenciastrans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agentes`
--

DROP TABLE IF EXISTS `agentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agentes` (
  `apellidos` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `coddepartamento` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dnicif` varchar(15) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `idusuario` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `nombreap` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `seg_social` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banco` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `f_alta` date DEFAULT NULL,
  `f_baja` date DEFAULT NULL,
  `f_nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`codagente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agentes`
--

LOCK TABLES `agentes` WRITE;
/*!40000 ALTER TABLE `agentes` DISABLE KEYS */;
INSERT INTO `agentes` VALUES ('Pepe','Victoria','1',NULL,NULL,'','','00000014Z','',NULL,NULL,NULL,NULL,'Paco',NULL,0,'Entre Ríos','','','','',NULL,NULL,NULL),('Ferrari','Victoria','2',NULL,NULL,'','','12312312','nuni@acme.com',NULL,NULL,NULL,NULL,'Nuni',NULL,0,'Entre Ríos','422222','','','','2018-07-01',NULL,'2018-07-01'),('Ferrari','Victoria','3',NULL,NULL,'','','22123123','acme@acme.com',NULL,NULL,NULL,NULL,'Jose',NULL,0,'Entre Ríos','423213','','','','2018-07-11',NULL,'2018-07-11'),('b','Victoria','4',NULL,NULL,'','','20221221224','acme@acme.com',NULL,NULL,NULL,NULL,'tito',NULL,0,'Entre Ríos','422222','','','','2018-08-04',NULL,'2018-08-04');
/*!40000 ALTER TABLE `agentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albaranescli`
--

DROP TABLE IF EXISTS `albaranescli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albaranescli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time DEFAULT '00:00:00',
  `femail` date DEFAULT NULL,
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `netosindto` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombrecliente` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `apartadoenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpaisenv` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0',
  `dtopor1` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `dtopor5` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranescli` (`codigo`),
  KEY `ca_albaranescli_series2` (`codserie`),
  KEY `ca_albaranescli_ejercicios2` (`codejercicio`),
  KEY `ca_albaranescli_facturas` (`idfactura`),
  CONSTRAINT `ca_albaranescli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranescli_facturas` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranescli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albaranescli`
--

LOCK TABLES `albaranescli` WRITE;
/*!40000 ALTER TABLE `albaranescli` DISABLE KEYS */;
/*!40000 ALTER TABLE `albaranescli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albaranesprov`
--

DROP TABLE IF EXISTS `albaranesprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albaranesprov` (
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `numdocs` int(11) DEFAULT '0',
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranesprov` (`codigo`),
  KEY `ca_albaranesprov_series2` (`codserie`),
  KEY `ca_albaranesprov_ejercicios2` (`codejercicio`),
  KEY `ca_albaranesprov_facturas` (`idfactura`),
  CONSTRAINT `ca_albaranesprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranesprov_facturas` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranesprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albaranesprov`
--

LOCK TABLES `albaranesprov` WRITE;
/*!40000 ALTER TABLE `albaranesprov` DISABLE KEYS */;
INSERT INTO `albaranesprov` VALUES ('302221231','2','ALG','ARS','2018','REM2018A1C','RAPIPAGO','000001','A','2018-08-22','19:30:34',1,NULL,0,300,'Escuela JFK','1','1557','',1,0,33.255547,363,10.91547,0,63,0,0);
/*!40000 ALTER TABLE `albaranesprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `almacenes`
--

DROP TABLE IF EXISTS `almacenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `almacenes` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `observaciones` text COLLATE utf8_bin,
  `poblacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `porpvp` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipovaloracion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `altura` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codalmacen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almacenes`
--

LOCK TABLES `almacenes` WRITE;
/*!40000 ALTER TABLE `almacenes` DISABLE KEYS */;
INSERT INTO `almacenes` VALUES (NULL,'ALG','ARG','3153','juan perez','Matanza25','123123',NULL,'COLEGIO PRIVADO JFK',NULL,'Victoria',NULL,'Entre Ríos','123123',NULL,NULL);
/*!40000 ALTER TABLE `almacenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alumnos` (
  `fecha_agregado` date NOT NULL,
  `fecha_actualizado` date DEFAULT NULL,
  `alumno_inactivo` tinyint(1) DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cursando` text COLLATE utf8_bin,
  `costemedio` double DEFAULT NULL,
  `preciocoste` double DEFAULT NULL,
  `tipocodbarras` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `codfamilia` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `publico` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articulo_propiedades`
--

DROP TABLE IF EXISTS `articulo_propiedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo_propiedades` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`name`,`referencia`),
  KEY `ca_articulo_propiedades_articulos` (`referencia`),
  CONSTRAINT `ca_articulo_propiedades_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo_propiedades`
--

LOCK TABLES `articulo_propiedades` WRITE;
/*!40000 ALTER TABLE `articulo_propiedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `articulo_propiedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articulo_trazas`
--

DROP TABLE IF EXISTS `articulo_trazas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo_trazas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `numserie` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `lote` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fecha_entrada` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `idlalbventa` int(11) DEFAULT NULL,
  `idlfacventa` int(11) DEFAULT NULL,
  `idlalbcompra` int(11) DEFAULT NULL,
  `idlfaccompra` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_codigo_articulo_trazas` (`numserie`),
  KEY `ca_articulo_trazas_articulos` (`referencia`),
  KEY `ca_articulo_trazas_linalbcli` (`idlalbventa`),
  KEY `ca_articulo_trazas_linfaccli` (`idlfacventa`),
  KEY `ca_articulo_trazas_linalbprov` (`idlalbcompra`),
  KEY `ca_articulo_trazas_linfacprov` (`idlfaccompra`),
  CONSTRAINT `ca_articulo_trazas_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_articulo_trazas_linalbcli` FOREIGN KEY (`idlalbventa`) REFERENCES `lineasalbaranescli` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_articulo_trazas_linalbprov` FOREIGN KEY (`idlalbcompra`) REFERENCES `lineasalbaranesprov` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_articulo_trazas_linfaccli` FOREIGN KEY (`idlfacventa`) REFERENCES `lineasfacturascli` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_articulo_trazas_linfacprov` FOREIGN KEY (`idlfaccompra`) REFERENCES `lineasfacturasprov` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo_trazas`
--

LOCK TABLES `articulo_trazas` WRITE;
/*!40000 ALTER TABLE `articulo_trazas` DISABLE KEYS */;
/*!40000 ALTER TABLE `articulo_trazas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulos` (
  `factualizado` date DEFAULT NULL,
  `bloqueado` tinyint(1) DEFAULT '0',
  `equivalencia` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentairpfcom` int(11) DEFAULT NULL,
  `idsubcuentacom` int(11) DEFAULT NULL,
  `stockmin` double DEFAULT '0',
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stockfis` double DEFAULT '0',
  `stockmax` double DEFAULT '0',
  `costemedio` double DEFAULT '0',
  `preciocoste` double DEFAULT '0',
  `tipocodbarras` varchar(8) COLLATE utf8_bin DEFAULT 'Code39',
  `nostock` tinyint(1) DEFAULT '0',
  `codsubcuentacom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `codsubcuentairpfcom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `secompra` tinyint(1) DEFAULT '1',
  `codfamilia` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `controlstock` tinyint(1) DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `pvp` double DEFAULT '0',
  `sevende` tinyint(1) DEFAULT '1',
  `publico` tinyint(1) DEFAULT '0',
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  `trazabilidad` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`referencia`),
  KEY `ca_articulos_impuestos` (`codimpuesto`),
  KEY `ca_articulos_familias` (`codfamilia`),
  KEY `ca_articulos_fabricantes` (`codfabricante`),
  CONSTRAINT `ca_articulos_fabricantes` FOREIGN KEY (`codfabricante`) REFERENCES `fabricantes` (`codfabricante`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_articulos_familias` FOREIGN KEY (`codfamilia`) REFERENCES `familias` (`codfamilia`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_articulos_impuestos` FOREIGN KEY (`codimpuesto`) REFERENCES `impuestos` (`codimpuesto`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulos`
--

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES ('2018-08-03',0,NULL,NULL,NULL,0,'','12345',NULL,0,0,0,0,'Code39',0,NULL,'Juan Perez Jr.',NULL,1,'002',NULL,NULL,1,'1',NULL,120,1,0,'',1),('2018-08-11',0,NULL,NULL,NULL,0,'','',NULL,0,0,0,0,'Code39',0,NULL,'jose ferrari jr',NULL,1,'011',NULL,NULL,1,'2',NULL,100,1,0,NULL,0),('2018-08-22',0,NULL,NULL,NULL,0,'','12345','AR27',0,0,150,0,'Code39',1,NULL,'Alumno',NULL,1,'004','OEM',NULL,1,'3',NULL,118.11,1,0,'',0),('2018-08-25',0,NULL,NULL,NULL,0,'','','AR21',0,0,0,0,'Code39',0,NULL,'a',NULL,1,'VARI','OEM',NULL,1,'4',NULL,0,1,0,NULL,0);
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articulosprov`
--

DROP TABLE IF EXISTS `articulosprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulosprov` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `refproveedor` varchar(25) COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin,
  `precio` double DEFAULT NULL,
  `dto` double DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stock` double DEFAULT NULL,
  `nostock` tinyint(1) DEFAULT '1',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_articulo_proveedor2` (`codproveedor`,`refproveedor`),
  CONSTRAINT `ca_articulosprov_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulosprov`
--

LOCK TABLES `articulosprov` WRITE;
/*!40000 ALTER TABLE `articulosprov` DISABLE KEYS */;
INSERT INTO `articulosprov` VALUES (1,'3','000001','3','',150,0,NULL,0,1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `articulosprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atributos`
--

DROP TABLE IF EXISTS `atributos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atributos` (
  `codatributo` varchar(20) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codatributo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos`
--

LOCK TABLES `atributos` WRITE;
/*!40000 ALTER TABLE `atributos` DISABLE KEYS */;
/*!40000 ALTER TABLE `atributos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cajas`
--

DROP TABLE IF EXISTS `cajas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cajas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fs_id` int(11) NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `f_inicio` timestamp NOT NULL DEFAULT '2018-08-13 03:00:00',
  `d_inicio` double NOT NULL DEFAULT '0',
  `f_fin` timestamp NULL DEFAULT NULL,
  `d_fin` double DEFAULT NULL,
  `tickets` int(11) DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cajas`
--

LOCK TABLES `cajas` WRITE;
/*!40000 ALTER TABLE `cajas` DISABLE KEYS */;
INSERT INTO `cajas` VALUES (1,1,'2','2018-08-12 12:33:19',50,NULL,50,0,'::1');
/*!40000 ALTER TABLE `cajas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cajas_terminales`
--

DROP TABLE IF EXISTS `cajas_terminales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cajas_terminales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `tickets` text COLLATE utf8_bin,
  `anchopapel` int(11) DEFAULT NULL,
  `comandocorte` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `comandoapertura` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `num_tickets` int(11) DEFAULT NULL,
  `sin_comandos` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cajas_terminales`
--

LOCK TABLES `cajas_terminales` WRITE;
/*!40000 ALTER TABLE `cajas_terminales` DISABLE KEYS */;
INSERT INTO `cajas_terminales` VALUES (1,'ALG','A',NULL,'p0\n',40,'27.105','27.112.48',1,0);
/*!40000 ALTER TABLE `cajas_terminales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_propiedades`
--

DROP TABLE IF EXISTS `cliente_propiedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_propiedades` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`name`,`codcliente`),
  KEY `ca_cliente_propiedades_clientes` (`codcliente`),
  CONSTRAINT `ca_cliente_propiedades_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_propiedades`
--

LOCK TABLES `cliente_propiedades` WRITE;
/*!40000 ALTER TABLE `cliente_propiedades` DISABLE KEYS */;
INSERT INTO `cliente_propiedades` VALUES ('password','000005','7110eda4d09e062aa5e4a390b0a572ac0d2c0220');
/*!40000 ALTER TABLE `cliente_propiedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `capitalimpagado` double DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codtiporappel` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `copiasfactura` int(11) DEFAULT NULL,
  `debaja` tinyint(1) DEFAULT '0',
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `fechabaja` date DEFAULT NULL,
  `fechaalta` date DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaincluido` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recargo` tinyint(1) DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `riesgoalcanzado` double DEFAULT NULL,
  `riesgomax` double DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `personafisica` tinyint(1) DEFAULT '1',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `diaspago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcliente`),
  KEY `ca_clientes_grupos` (`codgrupo`),
  CONSTRAINT `ca_clientes_grupos` FOREIGN KEY (`codgrupo`) REFERENCES `gruposclientes` (`codgrupo`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (NULL,'22222222',NULL,'000001',NULL,NULL,NULL,'ARS',NULL,NULL,'CONT',NULL,NULL,NULL,NULL,NULL,0,'','',NULL,'2018-07-01',NULL,NULL,'tito','tito','',0,'General',NULL,NULL,'','','DNI',1,'',NULL,NULL,NULL),(NULL,'302221231',NULL,'000002',NULL,NULL,NULL,'ARS',NULL,NULL,'CONT',NULL,NULL,NULL,NULL,NULL,0,'','',NULL,'2018-08-01',NULL,NULL,'Escuela JFK','Escuela JFK','',0,'General',NULL,NULL,'','','CUIT',0,'',NULL,'000001',NULL),(NULL,'20222123','3','000003',NULL,NULL,NULL,'ARS',NULL,'000001','CONT',NULL,NULL,NULL,NULL,NULL,0,'juanperez@acme.com','',NULL,'2018-08-03',NULL,NULL,'Perez Juan','Perez Juan','',0,'General',NULL,NULL,'15615615','424242','DNI',1,'',NULL,NULL,'000003'),(NULL,'1234','1','000004',NULL,NULL,NULL,'ARS',NULL,'000001','TRANS',NULL,NULL,NULL,NULL,NULL,0,'acme@gmail.com','',NULL,'2018-08-03',NULL,NULL,'cliente1','cliente1','',0,'General',NULL,NULL,'1234','','CUIT',1,'http://localhost/facturascripts_2015-master/index.php?page=ventas_clientes',NULL,NULL,NULL),(NULL,'201221231235',NULL,'000005',NULL,NULL,NULL,'ARS',NULL,'000001','CONT',NULL,NULL,NULL,NULL,NULL,0,'ctomattis@acme.com','',NULL,'2018-08-11',NULL,NULL,'Carlos Tomattis','Carlos Tomattis','',0,'General',NULL,NULL,'422222','','CUIT',1,'',NULL,NULL,NULL),(NULL,'201221224',NULL,'000006',NULL,NULL,NULL,'ARS',NULL,'000002','RAPIPAGO',NULL,NULL,NULL,NULL,NULL,0,'pgomez@acme.com','',NULL,'2018-08-11',NULL,NULL,'Gómez Pedro','Gómez Pedro','',0,'General',NULL,NULL,'15615623','424242','CUIT/CUIL',1,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_asientos`
--

DROP TABLE IF EXISTS `co_asientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_asientos` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codplanasiento` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `editable` tinyint(1) NOT NULL,
  `fecha` date NOT NULL,
  `idasiento` int(11) NOT NULL AUTO_INCREMENT,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idasiento`),
  KEY `ca_co_asientos_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_co_asientos_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_asientos`
--

LOCK TABLES `co_asientos` WRITE;
/*!40000 ALTER TABLE `co_asientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_asientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_codbalances08`
--

DROP TABLE IF EXISTS `co_codbalances08`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_codbalances08` (
  `descripcion4ba` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `descripcion4` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel4` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion3` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orden3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `nivel3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel2` int(11) DEFAULT NULL,
  `descripcion1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel1` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `naturaleza` varchar(15) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codbalance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_codbalances08`
--

LOCK TABLES `co_codbalances08` WRITE;
/*!40000 ALTER TABLE `co_codbalances08` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_codbalances08` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_conceptospar`
--

DROP TABLE IF EXISTS `co_conceptospar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_conceptospar` (
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idconceptopar` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idconceptopar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_conceptospar`
--

LOCK TABLES `co_conceptospar` WRITE;
/*!40000 ALTER TABLE `co_conceptospar` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_conceptospar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_cuentas`
--

DROP TABLE IF EXISTS `co_cuentas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_cuentas` (
  `codbalance` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `idcuentaesp` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  UNIQUE KEY `uniq_codcuenta` (`codcuenta`,`codejercicio`),
  KEY `ca_co_cuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_cuentas_epigrafes2` (`idepigrafe`),
  CONSTRAINT `ca_co_cuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_cuentas_epigrafes2` FOREIGN KEY (`idepigrafe`) REFERENCES `co_epigrafes` (`idepigrafe`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_cuentas`
--

LOCK TABLES `co_cuentas` WRITE;
/*!40000 ALTER TABLE `co_cuentas` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_cuentas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_cuentascbba`
--

DROP TABLE IF EXISTS `co_cuentascbba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_cuentascbba` (
  `desccuenta` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_cuentascbba`
--

LOCK TABLES `co_cuentascbba` WRITE;
/*!40000 ALTER TABLE `co_cuentascbba` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_cuentascbba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_cuentasesp`
--

DROP TABLE IF EXISTS `co_cuentasesp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_cuentasesp` (
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuentaesp` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idcuentaesp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_cuentasesp`
--

LOCK TABLES `co_cuentasesp` WRITE;
/*!40000 ALTER TABLE `co_cuentasesp` DISABLE KEYS */;
INSERT INTO `co_cuentasesp` VALUES (NULL,NULL,'Cuentas de acreedores','ACREED'),(NULL,NULL,'Cuentas de caja','CAJA'),(NULL,NULL,'Cuentas de diferencias negativas de cambio','CAMNEG'),(NULL,NULL,'Cuentas de diferencias positivas de cambio','CAMPOS'),(NULL,NULL,'Cuentas de clientes','CLIENT'),(NULL,NULL,'Cuentas de compras','COMPRA'),(NULL,NULL,'Devoluciones de compras','DEVCOM'),(NULL,NULL,'Devoluciones de ventas','DEVVEN'),(NULL,NULL,'Cuentas por diferencias positivas en divisa extranjera','DIVPOS'),(NULL,NULL,'Cuentas por diferencias negativas de conversión a la moneda local','EURNEG'),(NULL,NULL,'Cuentas por diferencias positivas de conversión a la moneda local','EURPOS'),(NULL,NULL,'Gastos por recargo financiero','GTORF'),(NULL,NULL,'Ingresos por recargo financiero','INGRF'),(NULL,NULL,'Cuentas de retenciones IRPF','IRPF'),(NULL,NULL,'Cuentas de retenciones para proveedores IRPFPR','IRPFPR'),(NULL,NULL,'Cuentas acreedoras de IVA en la regularización','IVAACR'),(NULL,NULL,'Cuentas deudoras de IVA en la regularización','IVADEU'),(NULL,NULL,'IVA en entregas intracomunitarias U.E.','IVAEUE'),(NULL,NULL,'Cuentas de IVA repercutido','IVAREP'),(NULL,NULL,'Cuentas de IVA repercutido para clientes exentos de IVA','IVAREX'),(NULL,NULL,'Cuentas de IVA soportado UE','IVARUE'),(NULL,NULL,'Cuentas de IVA repercutido en exportaciones','IVARXP'),(NULL,NULL,'Cuentas de IVA soportado en importaciones','IVASIM'),(NULL,NULL,'Cuentas de IVA soportado','IVASOP'),(NULL,NULL,'Cuentas de IVA soportado UE','IVASUE'),(NULL,NULL,'Cuentas relativas al ejercicio previo','PREVIO'),(NULL,NULL,'Cuentas de proveedores','PROVEE'),(NULL,NULL,'Pérdidas y ganancias','PYG'),(NULL,NULL,'Cuentas de ventas','VENTAS');
/*!40000 ALTER TABLE `co_cuentasesp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_epigrafes`
--

DROP TABLE IF EXISTS `co_epigrafes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_epigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL AUTO_INCREMENT,
  `idgrupo` int(11) DEFAULT NULL,
  `idpadre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idepigrafe`),
  KEY `ca_co_epigrafes_ejercicios` (`codejercicio`),
  KEY `ca_co_epigrafes_gruposepigrafes2` (`idgrupo`),
  CONSTRAINT `ca_co_epigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_epigrafes_gruposepigrafes2` FOREIGN KEY (`idgrupo`) REFERENCES `co_gruposepigrafes` (`idgrupo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_epigrafes`
--

LOCK TABLES `co_epigrafes` WRITE;
/*!40000 ALTER TABLE `co_epigrafes` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_epigrafes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_gruposepigrafes`
--

DROP TABLE IF EXISTS `co_gruposepigrafes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_gruposepigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idgrupo` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idgrupo`),
  KEY `ca_co_gruposepigrafes_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_gruposepigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_gruposepigrafes`
--

LOCK TABLES `co_gruposepigrafes` WRITE;
/*!40000 ALTER TABLE `co_gruposepigrafes` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_gruposepigrafes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_partidas`
--

DROP TABLE IF EXISTS `co_partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_partidas` (
  `baseimponible` double NOT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `codcontrapartida` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `debe` double NOT NULL DEFAULT '0',
  `debeme` double NOT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `factura` double DEFAULT NULL,
  `haber` double NOT NULL DEFAULT '0',
  `haberme` double NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `idcontrapartida` int(11) DEFAULT NULL,
  `idpartida` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuenta` int(11) NOT NULL,
  `iva` double NOT NULL,
  `punteada` tinyint(1) NOT NULL DEFAULT '0',
  `recargo` double NOT NULL,
  `tasaconv` double NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idpartida`),
  KEY `ca_co_partidas_co_asientos2` (`idasiento`),
  KEY `ca_co_partidas_subcuentas` (`idsubcuenta`),
  CONSTRAINT `ca_co_partidas_co_asientos2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_partidas_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_partidas`
--

LOCK TABLES `co_partidas` WRITE;
/*!40000 ALTER TABLE `co_partidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_partidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_regiva`
--

DROP TABLE IF EXISTS `co_regiva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_regiva` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `fechaasiento` date NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idregiva` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `periodo` varchar(8) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idregiva`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_regiva`
--

LOCK TABLES `co_regiva` WRITE;
/*!40000 ALTER TABLE `co_regiva` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_regiva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_secuencias`
--

DROP TABLE IF EXISTS `co_secuencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_secuencias` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `idsecuencia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsecuencia`),
  KEY `ca_co_secuencias_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_secuencias_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_secuencias`
--

LOCK TABLES `co_secuencias` WRITE;
/*!40000 ALTER TABLE `co_secuencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_secuencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_subcuentas`
--

DROP TABLE IF EXISTS `co_subcuentas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_subcuentas` (
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `debe` double NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `haber` double NOT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  `saldo` double NOT NULL,
  PRIMARY KEY (`idsubcuenta`),
  UNIQUE KEY `uniq_codsubcuenta` (`codsubcuenta`,`codejercicio`),
  KEY `ca_co_subcuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_subcuentas_cuentas2` (`idcuenta`),
  CONSTRAINT `ca_co_subcuentas_cuentas2` FOREIGN KEY (`idcuenta`) REFERENCES `co_cuentas` (`idcuenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_subcuentas`
--

LOCK TABLES `co_subcuentas` WRITE;
/*!40000 ALTER TABLE `co_subcuentas` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_subcuentas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_subcuentascli`
--

DROP TABLE IF EXISTS `co_subcuentascli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_subcuentascli` (
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuenta` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_co_subcuentascli_ejercicios` (`codejercicio`),
  KEY `ca_co_subcuentascli_clientes` (`codcliente`),
  KEY `ca_co_subcuentascli_subcuentas` (`idsubcuenta`),
  CONSTRAINT `ca_co_subcuentascli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentascli_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentascli_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_subcuentascli`
--

LOCK TABLES `co_subcuentascli` WRITE;
/*!40000 ALTER TABLE `co_subcuentascli` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_subcuentascli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_subcuentasprov`
--

DROP TABLE IF EXISTS `co_subcuentasprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_subcuentasprov` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuenta` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_co_subcuentasprov_ejercicios` (`codejercicio`),
  KEY `ca_co_subcuentasprov_proveedores` (`codproveedor`),
  KEY `ca_co_subcuentasprov_subcuentas` (`idsubcuenta`),
  CONSTRAINT `ca_co_subcuentasprov_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentasprov_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentasprov_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_subcuentasprov`
--

LOCK TABLES `co_subcuentasprov` WRITE;
/*!40000 ALTER TABLE `co_subcuentasprov` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_subcuentasprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuentasbanco`
--

DROP TABLE IF EXISTS `cuentasbanco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuentasbanco` (
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuentasbanco`
--

LOCK TABLES `cuentasbanco` WRITE;
/*!40000 ALTER TABLE `cuentasbanco` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuentasbanco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuentasbcocli`
--

DROP TABLE IF EXISTS `cuentasbcocli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuentasbcocli` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  `fmandato` date DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcocli_clientes` (`codcliente`),
  CONSTRAINT `ca_cuentasbcocli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuentasbcocli`
--

LOCK TABLES `cuentasbcocli` WRITE;
/*!40000 ALTER TABLE `cuentasbcocli` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuentasbcocli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuentasbcopro`
--

DROP TABLE IF EXISTS `cuentasbcopro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuentasbcopro` (
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcopro_proveedores` (`codproveedor`),
  CONSTRAINT `ca_cuentasbcopro_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuentasbcopro`
--

LOCK TABLES `cuentasbcopro` WRITE;
/*!40000 ALTER TABLE `cuentasbcopro` DISABLE KEYS */;
INSERT INTO `cuentasbcopro` VALUES (NULL,'1','000001',NULL,NULL,NULL,'banco x',NULL,'','ksejfikmed',1);
/*!40000 ALTER TABLE `cuentasbcopro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dirclientes`
--

DROP TABLE IF EXISTS `dirclientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dirclientes` (
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `domenvio` tinyint(1) DEFAULT NULL,
  `domfacturacion` tinyint(1) DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_dirclientes_clientes` (`codcliente`),
  CONSTRAINT `ca_dirclientes_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dirclientes`
--

LOCK TABLES `dirclientes` WRITE;
/*!40000 ALTER TABLE `dirclientes` DISABLE KEYS */;
INSERT INTO `dirclientes` VALUES ('000001','ARG','',NULL,'Victoria','Victoria','','',1,1,'Principal',1,'2018-07-01'),('000002','ARG','25',NULL,'Entre Ríos','Victoria','3153','Matanza',1,1,'Principal',2,'2018-08-01'),('000003','ARG','',NULL,'Entre Ríos','Victoria','3153','Basualdo y Bvard. Moreno',1,1,'Principal',3,'2018-08-03'),('000004','ARG','',NULL,'Entre Ríos','Victoria','3153','test',1,1,'Principal',4,'2018-08-03'),('000005','ARG','',NULL,'Entre Ríos','Victoria','3153','Basualdo 177',1,1,'Principal',5,'2018-08-11'),('000006','ARG','',NULL,'Entre Ríos','Victoria','','Chacabuco 138',1,1,'Principal',6,'2018-08-11');
/*!40000 ALTER TABLE `dirclientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dirproveedores`
--

DROP TABLE IF EXISTS `dirproveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dirproveedores` (
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `direccionppal` tinyint(1) DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_dirproveedores_proveedores` (`codproveedor`),
  CONSTRAINT `ca_dirproveedores_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dirproveedores`
--

LOCK TABLES `dirproveedores` WRITE;
/*!40000 ALTER TABLE `dirproveedores` DISABLE KEYS */;
INSERT INTO `dirproveedores` VALUES ('000001','ARG','25',NULL,'Entre Ríos','Victoria','3153','Matanza',1,'Principal',1,'2018-08-01');
/*!40000 ALTER TABLE `dirproveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `divisas`
--

DROP TABLE IF EXISTS `divisas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `divisas` (
  `bandera` text COLLATE utf8_bin,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codiso` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `simbolo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `tasaconv_compra` double DEFAULT NULL,
  PRIMARY KEY (`coddivisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `divisas`
--

LOCK TABLES `divisas` WRITE;
/*!40000 ALTER TABLE `divisas` DISABLE KEYS */;
INSERT INTO `divisas` VALUES (NULL,'ARS','32','PESOS (ARG)',NULL,'AR$',35.026239,35.026239);
/*!40000 ALTER TABLE `divisas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ejercicios`
--

DROP TABLE IF EXISTS `ejercicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ejercicios` (
  `idasientocierre` int(11) DEFAULT NULL,
  `idasientopyg` int(11) DEFAULT NULL,
  `idasientoapertura` int(11) DEFAULT NULL,
  `plancontable` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `longsubcuenta` int(11) DEFAULT NULL,
  `estado` varchar(15) COLLATE utf8_bin NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codejercicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ejercicios`
--

LOCK TABLES `ejercicios` WRITE;
/*!40000 ALTER TABLE `ejercicios` DISABLE KEYS */;
INSERT INTO `ejercicios` VALUES (NULL,NULL,NULL,'08',10,'ABIERTO','2018-12-31','2018-01-01','2018','2018');
/*!40000 ALTER TABLE `ejercicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `administrador` varchar(100) COLLATE utf8_bin NOT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `contintegrada` tinyint(1) DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `horario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idprovincia` int(11) DEFAULT NULL,
  `xid` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `lema` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `logo` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecorto` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `pie_factura` text COLLATE utf8_bin,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recequivalencia` tinyint(1) DEFAULT NULL,
  `stockpedidos` tinyint(1) DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `inicioact` date DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `altura` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES ('Carlos','25','CUIT: 30-54050846-8','Victoria','ALG',NULL,'ARS',NULL,'2018','CONT','ARG','3153','A',1,'AV CONGRESO 1816','test@test.com','','8 a 18 Horas',1,NULL,'fiS6Z4myghnCTxbUA1jqt5VHFLROMe','Quien se atreve, gana.',NULL,'INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY','Instituto JFKennedy','Gracias por estar al día','Entre Ríos',0,0,'422222','https://www.institutojfk.com.ar','1970-01-01',NULL,'');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fabricantes`
--

DROP TABLE IF EXISTS `fabricantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fabricantes` (
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codfabricante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabricantes`
--

LOCK TABLES `fabricantes` WRITE;
/*!40000 ALTER TABLE `fabricantes` DISABLE KEYS */;
INSERT INTO `fabricantes` VALUES ('OEM','OEM');
/*!40000 ALTER TABLE `fabricantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturascli`
--

DROP TABLE IF EXISTS `facturascli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturascli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `vencimiento` date DEFAULT NULL,
  `femail` date DEFAULT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `netosindto` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombrecliente` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double DEFAULT NULL,
  `tpv` tinyint(1) DEFAULT NULL,
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `apartadoenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpaisenv` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idimprenta` int(11) DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0',
  `dtopor1` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `dtopor5` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturascli` (`codigo`),
  KEY `ca_facturascli_series2` (`codserie`),
  KEY `ca_facturascli_ejercicios2` (`codejercicio`),
  KEY `ca_facturascli_asiento2` (`idasiento`),
  KEY `ca_facturascli_asientop` (`idasientop`),
  CONSTRAINT `ca_facturascli_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturascli`
--

LOCK TABLES `facturascli` WRITE;
/*!40000 ALTER TABLE `facturascli` DISABLE KEYS */;
INSERT INTO `facturascli` VALUES ('',NULL,'22222222','Victoria','1','ALG','000001',1,'ARS','2018','FAC2018A1',NULL,'CONT','ARG','','A',0,'',0,'2018-07-01','2018-07-01',NULL,'20:29:01',NULL,NULL,1,NULL,NULL,NULL,0,138.36,138.36,NULL,'tito','1','','factura corespondiente a mes agosto-2018',1,0,0,'Victoria',NULL,16.684,167.41,10.03416,0,29.05,0,NULL,NULL,'','','','','','','','','ARG',NULL,0,0,0,0,0,0),('',NULL,'20222123','Victoria','2','ALG','000003',3,'ARS','2018','FAC2018A2',NULL,'TRANS','ARG','3153','A',0,'Basualdo y Bvard. Moreno',0,'2018-08-03','2018-09-03',NULL,'16:55:06',NULL,NULL,2,NULL,NULL,NULL,0,120,120,NULL,'Perez Juan','2','','',0,0,0,'Entre Ríos',NULL,16.684,120,7.19252,0,0,0,NULL,NULL,'','','','','','','','','ARG',NULL,0,0,0,0,0,0),('',NULL,'20222123','Victoria','2','ALG','000003',3,'ARS','2018','FAC2018B1',NULL,'RAPIPAGO','ARG','3153','B',0,'Basualdo y Bvard. Moreno',0,'2018-08-11','2018-08-18',NULL,'13:07:35',NULL,NULL,3,NULL,NULL,NULL,0,0,0,NULL,'Perez Juan','1','','',0,0,0,'Entre Ríos',NULL,16.684,0,0,0,0,0,NULL,NULL,'','','','','','','','','ARG',NULL,0,0,0,0,0,0);
/*!40000 ALTER TABLE `facturascli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturasprov`
--

DROP TABLE IF EXISTS `facturasprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturasprov` (
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `neto` double DEFAULT NULL,
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `total` double DEFAULT NULL,
  `totaleuros` double DEFAULT NULL,
  `totalirpf` double DEFAULT NULL,
  `totaliva` double DEFAULT NULL,
  `totalrecargo` double DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0',
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturasprov` (`codigo`),
  KEY `ca_facturasprov_series2` (`codserie`),
  KEY `ca_facturasprov_ejercicios2` (`codejercicio`),
  KEY `ca_facturasprov_asiento2` (`idasiento`),
  KEY `ca_facturasprov_asientop` (`idasientop`),
  CONSTRAINT `ca_facturasprov_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturasprov`
--

LOCK TABLES `facturasprov` WRITE;
/*!40000 ALTER TABLE `facturasprov` DISABLE KEYS */;
INSERT INTO `facturasprov` VALUES (NULL,'302221231','2','ALG','ARS','2018','FAC2018A1C',NULL,'RAPIPAGO','000001','A',0,0,'2018-08-22','19:26:52',NULL,NULL,1,NULL,NULL,0,450,NULL,'Escuela JFK','1','1557','',0,0,NULL,33.255547,571.5,17.1851,0,121.5,0,0);
/*!40000 ALTER TABLE `facturasprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `familias`
--

DROP TABLE IF EXISTS `familias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `familias` (
  `descripcion` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfamilia` varchar(8) COLLATE utf8_bin NOT NULL,
  `madre` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codfamilia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `familias`
--

LOCK TABLES `familias` WRITE;
/*!40000 ALTER TABLE `familias` DISABLE KEYS */;
INSERT INTO `familias` VALUES ('Estudiantes de pre-escolar','001',NULL),('Estudiantes Primaria','002',NULL),('Estudiantes Secundaria','003',NULL),('Estudiantes','004',NULL),('Preescolar cuatro años','010','001'),('Preescolar cinco años','011','001'),('VARIOS','VARI',NULL);
/*!40000 ALTER TABLE `familias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formaspago`
--

DROP TABLE IF EXISTS `formaspago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formaspago` (
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `genrecibos` varchar(10) COLLATE utf8_bin NOT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `domiciliado` tinyint(1) DEFAULT NULL,
  `imprimir` tinyint(1) DEFAULT '1',
  `vencimiento` varchar(20) COLLATE utf8_bin DEFAULT '+1month',
  PRIMARY KEY (`codpago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formaspago`
--

LOCK TABLES `formaspago` WRITE;
/*!40000 ALTER TABLE `formaspago` DISABLE KEYS */;
INSERT INTO `formaspago` VALUES ('CONT','Al contado','Pagados',NULL,0,1,'+0day'),('RAPIPAGO','Rapipago','Emitidos',NULL,0,1,'+1week'),('TARJETA','Tarjeta de crédito','Pagados',NULL,0,1,'+0day'),('TRANS','Transferencia bancaria','Emitidos',NULL,0,1,'+1month');
/*!40000 ALTER TABLE `formaspago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_access`
--

DROP TABLE IF EXISTS `fs_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_access` (
  `fs_user` varchar(12) COLLATE utf8_bin NOT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin NOT NULL,
  `allow_delete` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`fs_user`,`fs_page`),
  KEY `fs_access_page2` (`fs_page`),
  CONSTRAINT `fs_access_page2` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fs_access_user2` FOREIGN KEY (`fs_user`) REFERENCES `fs_users` (`nick`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_access`
--

LOCK TABLES `fs_access` WRITE;
/*!40000 ALTER TABLE `fs_access` DISABLE KEYS */;
INSERT INTO `fs_access` VALUES ('cliente1','nueva_compra',0),('tito-emplead','nueva_venta',1),('tito-emplead','ventas_clientes',1),('tito-emplead','ventas_clientes_opciones',1),('tito-emplead','ventas_factura',1),('tito-emplead','ventas_factura_devolucion',1),('tito-emplead','ventas_facturas',1),('usuario1','ventas_agrupar_albaranes',1),('usuario1','ventas_albaran',1),('usuario1','ventas_albaranes',1),('usuario1','ventas_articulo',1),('usuario1','ventas_articulos',1),('usuario1','ventas_atributos',1),('usuario1','ventas_cliente',1),('usuario1','ventas_cliente_articulos',1),('usuario1','ventas_clientes',1),('usuario1','ventas_clientes_opciones',1),('usuario1','ventas_factura',1),('usuario1','ventas_factura_devolucion',1),('usuario1','ventas_facturas',1),('usuario1','ventas_familia',1),('usuario1','ventas_familias',1),('usuario1','ventas_grupo',1),('usuario1','ventas_trazabilidad',1);
/*!40000 ALTER TABLE `fs_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_extensions2`
--

DROP TABLE IF EXISTS `fs_extensions2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_extensions2` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `page_from` varchar(30) COLLATE utf8_bin NOT NULL,
  `page_to` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `text` text COLLATE utf8_bin,
  `params` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`,`page_from`),
  KEY `ca_fs_extensions2_fs_pages` (`page_from`),
  CONSTRAINT `ca_fs_extensions2_fs_pages` FOREIGN KEY (`page_from`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_extensions2`
--

LOCK TABLES `fs_extensions2` WRITE;
/*!40000 ALTER TABLE `fs_extensions2` DISABLE KEYS */;
INSERT INTO `fs_extensions2` VALUES ('agrupar_albaranes','compras_agrupar_albaranes','compras_albaranes','button','<span class=\"glyphicon glyphicon-duplicate\"></span><span class=\"hidden-xs\">&nbsp; Agrupar</span>',''),('agrupar_albaranes','ventas_agrupar_albaranes','ventas_albaranes','button','<span class=\"glyphicon glyphicon-duplicate\"></span><span class=\"hidden-xs\">&nbsp; Agrupar</span>',''),('albaranes_agente','compras_albaranes','admin_agente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos de proveedor',''),('albaranes_agente','ventas_albaranes','admin_agente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos de cliente',''),('albaranes_articulo','compras_albaranes','ventas_articulo','tab_button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos de proveedor',''),('albaranes_articulo','ventas_albaranes','ventas_articulo','tab_button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos de cliente',''),('albaranes_cliente','ventas_albaranes','ventas_cliente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos',''),('albaranes_proveedor','compras_albaranes','compras_proveedor','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Remitos',''),('api_remote_printer','tpv_recambios',NULL,'api','remote_printer',NULL),('articulo_subcuentas','articulo_subcuentas','ventas_articulo','tab','<span class=\"glyphicon glyphicon-book\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Subcuentas</span>',NULL),('btn_albaran','compras_actualiza_arts','compras_albaran','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Actualizar</span>','&doc=albaran'),('btn_atributos','ventas_atributos','ventas_articulos','button','<span class=\"glyphicon glyphicon-list-alt\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Atributos</span>',NULL),('btn_balances','editar_balances','informe_contabilidad','button','<span class=\"glyphicon glyphicon-wrench\"></span><span class=\"hidden-xs\">&nbsp; Balances</a>',NULL),('btn_fabricantes','ventas_fabricantes','ventas_articulos','button','<span class=\"glyphicon glyphicon-folder-open\" aria-hidden=\"true\"></span><span class=\"hidden-xs\"> &nbsp; Fabricantes</span>',NULL),('btn_familias','ventas_familias','ventas_articulos','button','<span class=\"glyphicon glyphicon-folder-open\" aria-hidden=\"true\"></span><span class=\"hidden-xs\"> &nbsp; Familias</span>',NULL),('btn_pedido','compras_actualiza_arts','compras_pedido','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Actualizar</span>','&doc=pedido'),('cosmo','admin_user','admin_user','css','view/css/bootstrap-cosmo.min.css',''),('darkly','admin_user','admin_user','css','view/css/bootstrap-darkly.min.css',''),('email_albaran','ventas_imprimir','ventas_albaran','email','Remito simple','&albaran=TRUE'),('email_albaran_proveedor','compras_imprimir','compras_albaran','email','Remito simple','&albaran=TRUE'),('email_factura','ventas_imprimir','ventas_factura','email','Factura simple','&factura=TRUE&tipo=simple'),('facturas_agente','compras_facturas','admin_agente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas de proveedor',''),('facturas_agente','ventas_facturas','admin_agente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas de cliente',''),('facturas_articulo','compras_facturas','ventas_articulo','tab_button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas de proveedor',''),('facturas_articulo','ventas_facturas','ventas_articulo','tab_button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas de cliente',''),('facturas_cliente','ventas_facturas','ventas_cliente','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas',''),('facturas_proveedor','compras_facturas','compras_proveedor','button','<span class=\"glyphicon glyphicon-list\" aria-hidden=\"true\"></span> &nbsp; Facturas',''),('flatly','admin_user','admin_user','css','view/css/bootstrap-flatly.min.css',''),('imprimir_albaran','ventas_imprimir','ventas_albaran','pdf','<span class=\"glyphicon glyphicon-print\"></span>&nbsp; Remito simple','&albaran=TRUE'),('imprimir_albaran_noval','ventas_imprimir','ventas_albaran','pdf','<span class=\"glyphicon glyphicon-print\"></span>&nbsp; Remito sin valorar','&albaran=TRUE&noval=TRUE'),('imprimir_albaran_proveedor','compras_imprimir','compras_albaran','pdf','Remito simple','&albaran=TRUE'),('imprimir_factura','ventas_imprimir','ventas_factura','pdf','<span class=\"glyphicon glyphicon-print\"></span>&nbsp; Factura simple','&factura=TRUE&tipo=simple'),('imprimir_factura_carta','ventas_imprimir','ventas_factura','pdf','<span class=\"glyphicon glyphicon-print\"></span>&nbsp; Modelo carta','&factura=TRUE&tipo=carta'),('imprimir_factura_proveedor','compras_imprimir','compras_factura','pdf','Factura simple','&factura=TRUE'),('lumen','admin_user','admin_user','css','view/css/bootstrap-lumen.min.css',''),('maquetar_albaran','ventas_maquetar','ventas_albaran','pdf','<i class=\"fa fa-magic\"></i>&nbsp; Maquetar','&albaran=TRUE'),('maquetar_factura','ventas_maquetar','ventas_factura','pdf','<i class=\"fa fa-magic\"></i>&nbsp; Maquetar','&factura=TRUE'),('opciones_clientes','ventas_clientes_opciones','ventas_clientes','button','<span class=\"glyphicon glyphicon-wrench\" aria-hidden=\"true\" title=\"Opciones para nuevos clientes\"></span><span class=\"hidden-xs\">&nbsp; Opciones</span>',NULL),('paper','admin_user','admin_user','css','view/css/bootstrap-paper.min.css',''),('sandstone','admin_user','admin_user','css','view/css/bootstrap-sandstone.min.css',''),('simplex','admin_user','admin_user','css','view/css/bootstrap-simplex.min.css',''),('spacelab','admin_user','admin_user','css','view/css/bootstrap-spacelab.min.css',''),('tab_devoluciones','compras_factura_devolucion','compras_factura','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Devoluciones</span>',NULL),('tab_devoluciones','ventas_factura_devolucion','ventas_factura','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Devoluciones</span>',NULL),('tab_editar_factura','compras_factura_devolucion','editar_factura_prov','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Devoluciones</span>',NULL),('tab_editar_factura','ventas_factura_devolucion','editar_factura','tab','<span class=\"glyphicon glyphicon-share\" aria-hidden=\"true\"></span><span class=\"hidden-xs\">&nbsp; Devoluciones</span>',NULL),('tab_ventas_cliente_articulos','ventas_cliente_articulos','ventas_cliente','tab','<i class=\"fa fa-cubes\" aria-hidden=\"true\"></i>&nbsp; Artículos',NULL),('united','admin_user','admin_user','css','view/css/bootstrap-united.min.css',''),('yeti','admin_user','admin_user','css','view/css/bootstrap-yeti.min.css','');
/*!40000 ALTER TABLE `fs_extensions2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_logs`
--

DROP TABLE IF EXISTS `fs_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `detalle` text COLLATE utf8_bin NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `alerta` tinyint(1) DEFAULT NULL,
  `controlador` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=661 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_logs`
--

LOCK TABLES `fs_logs` WRITE;
/*!40000 ALTER TABLE `fs_logs` DISABLE KEYS */;
INSERT INTO `fs_logs` VALUES (574,'msg','Historial borrado correctamente.','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(575,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 12','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(576,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(577,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 17','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(578,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(579,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 22','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(580,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(581,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 27','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(582,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(583,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 33','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(584,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(585,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 38','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(586,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(587,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 43','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(588,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(589,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 48','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(590,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:52','admin','172.68.211.207',0,'admin_info'),(591,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 10','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(592,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(593,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 15','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(594,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(595,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 20','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(596,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(597,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 25','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(598,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(599,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 31','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(600,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(601,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 36','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(602,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(603,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 41','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(604,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(605,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 46','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(606,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:15:57','admin','172.68.211.207',0,'admin_info'),(607,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 31','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(608,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(609,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 36','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(610,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(611,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 41','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(612,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(613,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 46','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(614,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(615,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 52','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(616,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(617,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 57','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(618,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(619,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 62','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(620,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(621,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 67','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(622,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:05','admin','172.68.211.207',0,'admin_info'),(623,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 10','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(624,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(625,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 15','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(626,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(627,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 20','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(628,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(629,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 25','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(630,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(631,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 31','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(632,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(633,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 36','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(634,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(635,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 41','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(636,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(637,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 46','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(638,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:27','admin','172.68.211.207',0,'admin_info'),(639,'error','Error al ejecutar la consulta 0: Invalid default value for &#39;fecha&#39;. La secuencia ocupa la posición 12','2018-08-24 21:16:35','admin','172.68.211.207',0,'admin_users'),(640,'error','Error al comprobar la tabla fs_logs','2018-08-24 21:16:35','admin','172.68.211.207',0,'admin_users'),(641,'error','Archivo model/table/tutores.xml no encontrado.','2018-08-24 21:17:03','admin','172.68.211.207',0,'ventas_tutores'),(642,'error','Error con el xml.','2018-08-24 21:17:03','admin','172.68.211.207',0,'ventas_tutores'),(643,'error','Archivo model/table/tutores.xml no encontrado.','2018-08-24 21:18:09','admin','172.68.211.207',0,'ventas_tutores'),(644,'error','Error con el xml.','2018-08-24 21:18:09','admin','172.68.211.207',0,'ventas_tutores'),(645,'error','Error al leer el archivo plugins/alumno/model/table/tutores.xml','2018-08-24 21:21:40','admin','172.68.211.207',0,'ventas_tutores'),(646,'error','Error con el xml.','2018-08-24 21:21:40','admin','172.68.211.207',0,'ventas_tutores'),(647,'error','Unknown column &#39;documento&#39; in &#39;field list&#39;','2018-08-24 22:28:46','admin','172.68.211.231',0,'ventas_tutores'),(648,'error','Unknown column &#39;documento&#39; in &#39;field list&#39;','2018-08-24 22:44:47','admin','172.68.211.231',0,'ventas_tutores'),(649,'login','Login correcto.','2018-08-25 12:50:55','admin','172.68.211.231',0,'admin_home'),(650,'login','Login correcto.','2018-08-25 17:12:11','admin','172.68.47.119',0,'admin_home'),(651,'login','¡Contraseña incorrecta! (admin)','2018-08-27 13:13:07',NULL,'172.68.211.21',1,'admin_home'),(652,'login','¡Contraseña incorrecta! (admin)','2018-08-27 13:13:18',NULL,'172.68.211.21',1,'admin_home'),(653,'login','El usuario ha cerrado la sesión.','2018-08-27 13:32:49',NULL,'172.68.211.159',0,'admin_home'),(654,'login','Login correcto.','2018-08-27 16:33:27','admin','172.68.211.159',0,'admin_home'),(655,'error','Error al leer el archivo plugins/alumno/model/table/alumnos.xml','2018-08-27 13:33:52','admin','172.68.211.159',0,'ventas_alumnos'),(656,'error','Error con el xml.','2018-08-27 13:33:52','admin','172.68.211.159',0,'ventas_alumnos'),(657,'error','Unknown column &#39;bloqueado&#39; in &#39;where clause&#39;','2018-08-27 13:33:52','admin','172.68.211.159',0,'ventas_alumnos'),(658,'error','Error al leer el archivo plugins/alumno/model/table/alumnos.xml','2018-08-27 13:34:48','admin','172.68.211.159',0,'ventas_alumnos'),(659,'error','Error con el xml.','2018-08-27 13:34:48','admin','172.68.211.159',0,'ventas_alumnos'),(660,'error','Unknown column &#39;bloqueado&#39; in &#39;where clause&#39;','2018-08-27 13:34:48','admin','172.68.211.159',0,'ventas_alumnos');
/*!40000 ALTER TABLE `fs_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_pages`
--

DROP TABLE IF EXISTS `fs_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_pages` (
  `name` varchar(30) COLLATE utf8_bin NOT NULL,
  `title` varchar(40) COLLATE utf8_bin NOT NULL,
  `folder` varchar(15) COLLATE utf8_bin NOT NULL,
  `version` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `show_on_menu` tinyint(1) NOT NULL DEFAULT '1',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  `orden` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_pages`
--

LOCK TABLES `fs_pages` WRITE;
/*!40000 ALTER TABLE `fs_pages` DISABLE KEYS */;
INSERT INTO `fs_pages` VALUES ('admin_agente','Empleado','admin','2017.031',0,0,100),('admin_agentes','Empleados','admin','2017.031',1,0,100),('admin_almacenes','Almacenes','admin','2017.031',1,0,100),('admin_divisas','Divisas','admin','2017.903',1,0,100),('admin_empresa','Empresa','admin','2017.031',1,0,100),('admin_home','Panel de control','admin',NULL,1,0,100),('admin_info','Información del sistema','admin','2017.031',1,0,100),('admin_orden_menu','Ordenar menú','admin','2017.031',1,0,100),('admin_paises','Paises','admin','2017.903',1,0,100),('admin_rol','Editar rol','admin','2017.031',0,0,100),('admin_transportes','Agencias de transporte','admin','2017.904',1,0,100),('admin_user','Usuario','admin','2017.031',0,0,100),('admin_users','Usuarios','admin','2017.031',1,0,100),('articulo_subcuentas','Subcuentas','ventas','2017.031',0,0,100),('articulo_trazabilidad','','ventas','2017.903',0,0,100),('backup_restore','Copias de seguridad','admin','2017.904',1,0,100),('base_wizard','Asistente de instalación','admin','2017.903',0,0,100),('compras_actualiza_arts','Artículos documento','compras','2017.903',0,0,100),('compras_agrupar_albaranes','Agrupar remitos','compras','2017.903',0,0,100),('compras_albaran','remito de proveedor','compras','2017.903',0,0,100),('compras_albaranes','Remitos','compras','2017.903',1,0,100),('compras_factura','Factura de proveedor','compras','2017.903',0,0,100),('compras_factura_devolucion','Devoluciones de factura de compra','compras','2017.903',0,0,100),('compras_facturas','Facturas','compras','2017.031',1,0,100),('compras_imprimir','imprimir','compras','2017.031',0,0,100),('compras_proveedor','Proveedor','compras','2017.031',0,0,100),('compras_proveedores','Proveedores / Acreedores','compras','2017.031',1,0,100),('compras_trazabilidad','Trazabilidad','compras','2017.903',0,0,100),('contabilidad_asiento','Asiento','contabilidad','2017.903',0,0,100),('contabilidad_asientos','Asientos','contabilidad','2017.031',1,0,100),('contabilidad_cuenta','Cuenta','contabilidad','2017.903',0,0,100),('contabilidad_cuentas','Cuentas','contabilidad','2017.031',1,0,100),('contabilidad_ejercicio','Ejercicio','contabilidad','2017.031',0,0,100),('contabilidad_ejercicios','Ejercicios','contabilidad','2017.031',1,0,100),('contabilidad_epigrafes','Grupos y epígrafes','contabilidad','2017.903',1,0,100),('contabilidad_formas_pago','Formas de Pago','contabilidad','2017.031',1,0,100),('contabilidad_impuestos','Impuestos','contabilidad','2017.031',1,0,100),('contabilidad_nuevo_asiento','Nuevo asiento','contabilidad','2017.903',0,1,100),('contabilidad_series','Series','contabilidad','2017.031',1,0,100),('contabilidad_subcuenta','Subcuenta','contabilidad','2017.903',0,0,100),('cuentas_especiales','Cuentas Especiales','contabilidad','2017.903',0,0,100),('dashboard','Dashboard','informes','2017.031',1,1,100),('editar_balances','Editar balances','informes','2017.903',0,0,100),('editar_transferencia_stock','Editar transferencia','ventas','2017.903',0,0,100),('fsdk_home','FSDK','admin','2017.904',1,0,100),('fsdk_plan_contable','Plan contable','admin','2017.904',0,0,100),('fsdk_tabla','Tabla','admin','2017.904',0,0,100),('informe_albaranes','Remitos','informes','2017.031',1,0,100),('informe_articulos','Artículos','informes','2017.031',1,0,100),('informe_contabilidad','Contabilidad','informes','2017.031',1,0,100),('informe_errores','Errores','informes','2017.031',1,0,100),('informe_facturas','Facturas','informes','2017.031',1,0,100),('nueva_compra','Nueva compra...','compras','2017.031',0,1,100),('nueva_venta','Nueva venta...','ventas','2017.031',0,1,100),('subcuenta_asociada','Asignar subcuenta...','contabilidad','2017.031',0,0,100),('tpv_caja','Arqueos y terminales','TPV','2017.903',1,0,100),('tpv_recambios','TPV Genérico','TPV','2017.903',1,0,100),('ventas_agrupar_albaranes','Agrupar remitos','ventas','2017.903',0,0,100),('ventas_albaran','remito de cliente','ventas','2017.903',0,0,100),('ventas_albaranes','Remitos','ventas','2017.903',1,0,100),('ventas_alumno','alumno','ventas','2017.903',0,0,100),('ventas_alumnos','Alumnos','ventas','2017.903',1,0,100),('ventas_articulo','Articulo','ventas','2017.031',0,0,100),('ventas_articulos','Artículos','ventas','2017.031',1,0,100),('ventas_atributos','Atributos de artículos','ventas','2017.031',0,0,100),('ventas_cliente','Cliente','ventas','2017.031',0,0,100),('ventas_cliente_articulos','Articulos vendidos al cliente','ventas','2017.031',0,0,100),('ventas_clientes','Clientes','ventas','2017.031',1,0,100),('ventas_clientes_opciones','Opciones','clientes','2017.031',0,0,100),('ventas_fabricante','Familia','ventas','2017.904',0,0,100),('ventas_fabricantes','Fabricantes','ventas','2017.903',0,0,100),('ventas_factura','Factura de cliente','ventas','2017.031',0,0,100),('ventas_factura_devolucion','Devoluciones de factura de venta','ventas','2017.031',0,0,100),('ventas_facturas','Facturas','ventas','2017.031',1,0,100),('ventas_familia','Familia','ventas','2017.031',0,0,100),('ventas_familias','Familias','ventas','2017.031',0,0,100),('ventas_grupo','Grupo','ventas','2017.031',0,0,100),('ventas_imprimir','imprimir','ventas','2017.031',0,0,100),('ventas_maquetar','Maquetar','ventas','2017.903',0,0,100),('ventas_trazabilidad','Trazabilidad','ventas','2017.031',0,0,100),('ventas_tutores','Tutores','ventas','2017.904',1,0,100);
/*!40000 ALTER TABLE `fs_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_roles`
--

DROP TABLE IF EXISTS `fs_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_roles` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codrol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_roles`
--

LOCK TABLES `fs_roles` WRITE;
/*!40000 ALTER TABLE `fs_roles` DISABLE KEYS */;
INSERT INTO `fs_roles` VALUES ('001','usuario con permisos para afcturar');
/*!40000 ALTER TABLE `fs_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_roles_access`
--

DROP TABLE IF EXISTS `fs_roles_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_roles_access` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin NOT NULL,
  `allow_delete` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`codrol`,`fs_page`),
  KEY `fs_roles_access_page` (`fs_page`),
  CONSTRAINT `fs_roles_access_page` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fs_roles_access_roles` FOREIGN KEY (`codrol`) REFERENCES `fs_roles` (`codrol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_roles_access`
--

LOCK TABLES `fs_roles_access` WRITE;
/*!40000 ALTER TABLE `fs_roles_access` DISABLE KEYS */;
INSERT INTO `fs_roles_access` VALUES ('001','ventas_facturas',0);
/*!40000 ALTER TABLE `fs_roles_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_roles_users`
--

DROP TABLE IF EXISTS `fs_roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_roles_users` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `fs_user` varchar(12) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codrol`,`fs_user`),
  KEY `fs_roles_users_user` (`fs_user`),
  CONSTRAINT `fs_roles_users_roles` FOREIGN KEY (`codrol`) REFERENCES `fs_roles` (`codrol`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fs_roles_users_user` FOREIGN KEY (`fs_user`) REFERENCES `fs_users` (`nick`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_roles_users`
--

LOCK TABLES `fs_roles_users` WRITE;
/*!40000 ALTER TABLE `fs_roles_users` DISABLE KEYS */;
INSERT INTO `fs_roles_users` VALUES ('001','cliente1');
/*!40000 ALTER TABLE `fs_roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_users`
--

DROP TABLE IF EXISTS `fs_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_users` (
  `nick` varchar(12) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL,
  `log_key` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `last_login_time` time DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `last_browser` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `css` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`nick`),
  KEY `ca_fs_users_pages` (`fs_page`),
  CONSTRAINT `ca_fs_users_pages` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_users`
--

LOCK TABLES `fs_users` WRITE;
/*!40000 ALTER TABLE `fs_users` DISABLE KEYS */;
INSERT INTO `fs_users` VALUES ('admin','229101b8f872656c7c9b24421bdd46f2a167046a','025bc0f05aa8e18da795c5168b00067d3839e1eb',1,1,'2','2018-08-27','15:33:27','172.68.211.159','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',NULL,'view/css/bootstrap-cosmo.min.css','cburgosster@gmail.com'),('cliente1','d94019fd760a71edf11844bb5c601a4de95aacaf',NULL,0,1,'3',NULL,NULL,NULL,'',NULL,'view/css/bootstrap-simplex.min.css','acme@gmail.com'),('tito','f5276fb0b29741f04c2acaa55e40da5b45c2dacf','88547be1130859cf095ec35f890a1a53eafa9ac2',1,1,NULL,'2018-08-04','15:31:08','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36','ventas_facturas','view/css/bootstrap-spacelab.min.css','cburgosster@gmail.com'),('tito-emplead','293abb6b76d7791c0732cc517d38c4b5c734b87f','ebed9c8f2abc8e5c320859c5fcb528734599d269',0,1,'3','2018-07-11','18:26:39','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36','ventas_clientes','view/css/bootstrap-yeti.min.css','cburgosster@gmail.com'),('usuario1','b665e217b51994789b02b1838e730d6b93baa30f','2c995d097a80369df69e7a06ed84710d9bae0ffa',0,1,'4','2018-08-14','16:49:07','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36','ventas_albaranes','view/css/bootstrap-yeti.min.css','cburgosster@gmail.com');
/*!40000 ALTER TABLE `fs_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_vars`
--

DROP TABLE IF EXISTS `fs_vars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_vars` (
  `name` varchar(35) COLLATE utf8_bin NOT NULL,
  `varchar` text COLLATE utf8_bin,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_vars`
--

LOCK TABLES `fs_vars` WRITE;
/*!40000 ALTER TABLE `fs_vars` DISABLE KEYS */;
INSERT INTO `fs_vars` VALUES ('backup_comando','\"/usr/bin/mysqldump\"'),('f_detallada_agrupa_albaranes','1'),('f_detallada_color','azul'),('f_detallada_color_b','0'),('f_detallada_color_g','0'),('f_detallada_color_r','192'),('f_detallada_imprime_albaran','1'),('f_detallada_maquetar_negrita','1'),('f_detallada_print_may_min','1'),('google_divisas_cron','1'),('install_step','5'),('mail_albaran','Buenos días, le adjunto su #DOCUMENTO#.\r\n#FIRMA#'),('mail_bcc','Si'),('mail_enc','ssl'),('mail_factura','Buenos días, le adjunto su #DOCUMENTO#.\r\n#FIRMA#'),('mail_firma','---\r\nEnviado con Facturas-Coopevic Ltda'),('mail_host','smtp.gmail.com'),('mail_low_security','1'),('mail_mailer','smtp'),('mail_password','ayNgXrlfN3HJZ9PUXa'),('mail_pedido','Buenos días, le adjunto su #DOCUMENTO#.\n#FIRMA#'),('mail_port','465'),('mail_presupuesto','Buenos días, le adjunto su #DOCUMENTO#.\n#FIRMA#'),('mail_user','cburgosster@gmail.com'),('nuevocli_cifnif_req','1'),('nuevocli_ciudad','1'),('nuevocli_ciudad_req','0'),('nuevocli_codgrupo','000002'),('nuevocli_codpostal','1'),('nuevocli_codpostal_req','0'),('nuevocli_direccion','1'),('nuevocli_direccion_req','1'),('nuevocli_email','1'),('nuevocli_email_req','0'),('nuevocli_pais','0'),('nuevocli_pais_req','0'),('nuevocli_provincia','1'),('nuevocli_provincia_req','0'),('nuevocli_telefono1','1'),('nuevocli_telefono1_req','0'),('nuevocli_telefono2','1'),('nuevocli_telefono2_req','0'),('numeracion_personalizada','1'),('print_alb','0'),('print_dto','1'),('print_formapago','1'),('print_job_terminal','1'),('print_job_text',''),('print_ref','1'),('restore_comando','\"/usr/bin/mysql\"'),('restore_comando_data','\"/usr/bin/mysqlimport\"');
/*!40000 ALTER TABLE `fs_vars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gruposclientes`
--

DROP TABLE IF EXISTS `gruposclientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gruposclientes` (
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codgrupo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gruposclientes`
--

LOCK TABLES `gruposclientes` WRITE;
/*!40000 ALTER TABLE `gruposclientes` DISABLE KEYS */;
INSERT INTO `gruposclientes` VALUES ('000001','JFK-Primaria',NULL),('000002','JFK_Secundaria',NULL),('000003','JFK_Jardines',NULL);
/*!40000 ALTER TABLE `gruposclientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `idiomas_fac_det`
--

DROP TABLE IF EXISTS `idiomas_fac_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `idiomas_fac_det` (
  `codidioma` varchar(10) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `telefono` varchar(100) COLLATE utf8_bin DEFAULT 'teléfono',
  `fax` varchar(100) COLLATE utf8_bin DEFAULT 'fax',
  `email` varchar(100) COLLATE utf8_bin DEFAULT 'email',
  `web` varchar(100) COLLATE utf8_bin DEFAULT 'web',
  `factura` varchar(100) COLLATE utf8_bin DEFAULT 'factura',
  `albaran` varchar(100) COLLATE utf8_bin DEFAULT 'albarán',
  `pedido` varchar(100) COLLATE utf8_bin DEFAULT 'pedido',
  `pagina` varchar(100) COLLATE utf8_bin DEFAULT 'página',
  `fecha` varchar(100) COLLATE utf8_bin DEFAULT 'fecha',
  `num_cliente` varchar(100) COLLATE utf8_bin DEFAULT 'nº de cliente',
  `cliente` varchar(100) COLLATE utf8_bin DEFAULT 'cliente',
  `forma_pago` varchar(100) COLLATE utf8_bin DEFAULT 'forma de pago',
  `vencimiento` varchar(100) COLLATE utf8_bin DEFAULT 'vencimiento',
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT 'descripción',
  `cant` varchar(100) COLLATE utf8_bin DEFAULT 'cant',
  `precio` varchar(100) COLLATE utf8_bin DEFAULT 'precio',
  `dto` varchar(100) COLLATE utf8_bin DEFAULT 'dto',
  `iva` varchar(100) COLLATE utf8_bin DEFAULT 'iva',
  `importe` varchar(100) COLLATE utf8_bin DEFAULT 'importe',
  `importes` varchar(100) COLLATE utf8_bin DEFAULT 'importes',
  `neto` varchar(100) COLLATE utf8_bin DEFAULT 'neto',
  `rec_equiv` varchar(100) COLLATE utf8_bin DEFAULT 'rec. equiv.',
  `irpf` varchar(100) COLLATE utf8_bin DEFAULT 'irpf',
  `total` varchar(100) COLLATE utf8_bin DEFAULT 'total',
  `suma_sigue` varchar(100) COLLATE utf8_bin DEFAULT 'suma y sigue',
  `observaciones` varchar(100) COLLATE utf8_bin DEFAULT 'observaciones',
  PRIMARY KEY (`codidioma`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idiomas_fac_det`
--

LOCK TABLES `idiomas_fac_det` WRITE;
/*!40000 ALTER TABLE `idiomas_fac_det` DISABLE KEYS */;
INSERT INTO `idiomas_fac_det` VALUES ('es_ES','Español',1,'teléfono','fax','email','web','factura','Remito','pedido','página','fecha','nº de cliente','cliente','forma de pago','vencimiento','descripción','cant','precio','dto','iva','importe','importes','neto','rec. equiv.','irpf','total','suma y sigue','observaciones');
/*!40000 ALTER TABLE `idiomas_fac_det` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impuestos`
--

DROP TABLE IF EXISTS `impuestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impuestos` (
  `codimpuesto` varchar(10) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadedadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadevadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadeventue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepre` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopagra` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopimp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentarep` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentasop` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `idsubcuentaivadedadue` int(11) DEFAULT NULL,
  `idsubcuentaivadevadue` int(11) DEFAULT NULL,
  `idsubcuentaivadeventue` int(11) DEFAULT NULL,
  `idsubcuentaivarepexe` int(11) DEFAULT NULL,
  `idsubcuentaivarepexp` int(11) DEFAULT NULL,
  `idsubcuentaivarepre` int(11) DEFAULT NULL,
  `idsubcuentaivasopagra` int(11) DEFAULT NULL,
  `idsubcuentaivasopexe` int(11) DEFAULT NULL,
  `idsubcuentaivasopimp` int(11) DEFAULT NULL,
  `idsubcuentarep` int(11) DEFAULT NULL,
  `idsubcuentasop` int(11) DEFAULT NULL,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  PRIMARY KEY (`codimpuesto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impuestos`
--

LOCK TABLES `impuestos` WRITE;
/*!40000 ALTER TABLE `impuestos` DISABLE KEYS */;
INSERT INTO `impuestos` VALUES ('AR0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AR 0%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),('AR105',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AR 10,5%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10.5,0),('AR21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AR 21%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,21,0),('AR27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AR 27%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,27,0),('AR5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AR 5%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,0);
/*!40000 ALTER TABLE `impuestos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kdb`
--

DROP TABLE IF EXISTS `kdb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kdb` (
  `idkdb` int(11) NOT NULL,
  `sintoma` varchar(255) COLLATE utf8_bin NOT NULL,
  `causa` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `solucion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idkdb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kdb`
--

LOCK TABLES `kdb` WRITE;
/*!40000 ALTER TABLE `kdb` DISABLE KEYS */;
INSERT INTO `kdb` VALUES (1,'','','','');
/*!40000 ALTER TABLE `kdb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasalbaranescli`
--

DROP TABLE IF EXISTS `lineasalbaranescli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasalbaranescli` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineapedido` int(11) DEFAULT NULL,
  `idpedido` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `orden` int(11) DEFAULT '0',
  `mostrar_cantidad` tinyint(1) DEFAULT '1',
  `mostrar_precio` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineasalbaranescli_albaranescli2` (`idalbaran`),
  CONSTRAINT `ca_lineasalbaranescli_albaranescli2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranescli` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasalbaranescli`
--

LOCK TABLES `lineasalbaranescli` WRITE;
/*!40000 ALTER TABLE `lineasalbaranescli` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineasalbaranescli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasalbaranesprov`
--

DROP TABLE IF EXISTS `lineasalbaranesprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasalbaranesprov` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineapedido` int(11) DEFAULT NULL,
  `idpedido` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineasalbaranesprov_albaranesprov2` (`idalbaran`),
  CONSTRAINT `ca_lineasalbaranesprov_albaranesprov2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranesprov` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasalbaranesprov`
--

LOCK TABLES `lineasalbaranesprov` WRITE;
/*!40000 ALTER TABLE `lineasalbaranesprov` DISABLE KEYS */;
INSERT INTO `lineasalbaranesprov` VALUES (2,'AR21','Alumno',0,0,1,1,NULL,NULL,0,21,300,300,150,0,'3',NULL);
/*!40000 ALTER TABLE `lineasalbaranesprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasfacturascli`
--

DROP TABLE IF EXISTS `lineasfacturascli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasfacturascli` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineaalbaran` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double NOT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `orden` int(11) DEFAULT '0',
  `mostrar_cantidad` tinyint(1) DEFAULT '1',
  `mostrar_precio` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`idlinea`),
  KEY `ca_linea_facturascli2` (`idfactura`),
  CONSTRAINT `ca_linea_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasfacturascli`
--

LOCK TABLES `lineasfacturascli` WRITE;
/*!40000 ALTER TABLE `lineasfacturascli` DISABLE KEYS */;
INSERT INTO `lineasfacturascli` VALUES (3,'AR21','cuota mes agosto',0,0,5,7,10,NULL,1,1,NULL,0,21,NULL,174,138.3561,58,0,NULL,NULL,0,1,1),(1,'AR0','Juan Perez Jr.',0,0,0,0,0,NULL,2,2,NULL,0,0,NULL,120,120,120,0,'1',NULL,0,1,1);
/*!40000 ALTER TABLE `lineasfacturascli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasfacturasprov`
--

DROP TABLE IF EXISTS `lineasfacturasprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasfacturasprov` (
  `cantidad` double NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL,
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineaalbaran` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double DEFAULT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_linea_facturasprov2` (`idfactura`),
  CONSTRAINT `ca_linea_facturasprov2` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasfacturasprov`
--

LOCK TABLES `lineasfacturasprov` WRITE;
/*!40000 ALTER TABLE `lineasfacturasprov` DISABLE KEYS */;
INSERT INTO `lineasfacturasprov` VALUES (3,'AR27',NULL,'Alumno',0,0,NULL,1,1,NULL,NULL,0,27,450,450,150,0,'3',NULL);
/*!40000 ALTER TABLE `lineasfacturasprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasivafactcli`
--

DROP TABLE IF EXISTS `lineasivafactcli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasivafactcli` (
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `iva` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `recargo` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totallinea` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineaiva_facturascli2` (`idfactura`),
  CONSTRAINT `ca_lineaiva_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasivafactcli`
--

LOCK TABLES `lineasivafactcli` WRITE;
/*!40000 ALTER TABLE `lineasivafactcli` DISABLE KEYS */;
INSERT INTO `lineasivafactcli` VALUES ('AR21',1,1,21,138.36,0,29.05,167.41,0);
/*!40000 ALTER TABLE `lineasivafactcli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasivafactprov`
--

DROP TABLE IF EXISTS `lineasivafactprov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasivafactprov` (
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `iva` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `recargo` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totallinea` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineaiva_facturasprov2` (`idfactura`),
  CONSTRAINT `ca_lineaiva_facturasprov2` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasivafactprov`
--

LOCK TABLES `lineasivafactprov` WRITE;
/*!40000 ALTER TABLE `lineasivafactprov` DISABLE KEYS */;
INSERT INTO `lineasivafactprov` VALUES ('AR27',1,1,27,450,0,121.5,571.5,0);
/*!40000 ALTER TABLE `lineasivafactprov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineasregstocks`
--

DROP TABLE IF EXISTS `lineasregstocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineasregstocks` (
  `cantidadfin` double NOT NULL DEFAULT '0',
  `cantidadini` double NOT NULL DEFAULT '0',
  `codalmacendest` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idstock` int(11) NOT NULL,
  `motivo` text COLLATE utf8_bin,
  `nick` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_lineasregstocks_stocks` (`idstock`),
  CONSTRAINT `ca_lineasregstocks_stocks` FOREIGN KEY (`idstock`) REFERENCES `stocks` (`idstock`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineasregstocks`
--

LOCK TABLES `lineasregstocks` WRITE;
/*!40000 ALTER TABLE `lineasregstocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineasregstocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineastransstock`
--

DROP TABLE IF EXISTS `lineastransstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineastransstock` (
  `cantidad` double NOT NULL,
  `descripcion` text COLLATE utf8_bin,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idtrans` int(11) NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idlinea`),
  UNIQUE KEY `uniq_referencia_transferencia` (`idtrans`,`referencia`),
  KEY `ca_linea_transstock_articulos` (`referencia`),
  CONSTRAINT `ca_linea_transstock` FOREIGN KEY (`idtrans`) REFERENCES `transstock` (`idtrans`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_linea_transstock_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineastransstock`
--

LOCK TABLES `lineastransstock` WRITE;
/*!40000 ALTER TABLE `lineastransstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineastransstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paises` (
  `validarprov` tinyint(1) DEFAULT NULL,
  `codiso` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `bandera` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codpais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises`
--

LOCK TABLES `paises` WRITE;
/*!40000 ALTER TABLE `paises` DISABLE KEYS */;
INSERT INTO `paises` VALUES (NULL,'AW',NULL,'Aruba','ABW'),(NULL,'AX',NULL,'Islas Gland','ALA'),(NULL,'AE',NULL,'Emiratos Árabes Unidos','ARE'),(NULL,'AR',NULL,'Argentina','ARG'),(NULL,'AM',NULL,'Armenia','ARM'),(NULL,'AS',NULL,'Samoa Americana','ASM'),(NULL,'TF',NULL,'Territorios Australes Franceses','ATF'),(NULL,'AU',NULL,'Australia','AUS'),(NULL,'AT',NULL,'Austria','AUT'),(NULL,'AZ',NULL,'Azerbaiyán','AZE'),(NULL,'BI',NULL,'Burundi','BDI'),(NULL,'BE',NULL,'Bélgica','BEL'),(NULL,'BJ',NULL,'Benín','BEN'),(NULL,'BF',NULL,'Burkina Faso','BFA'),(NULL,'BD',NULL,'Bangladesh','BGD'),(NULL,'BG',NULL,'Bulgaria','BGR'),(NULL,'BH',NULL,'Bahréin','BHR'),(NULL,'BS',NULL,'Bahamas','BHS'),(NULL,'BA',NULL,'Bosnia y Herzegovina','BIH'),(NULL,'BY',NULL,'Bielorrusia','BLR'),(NULL,'BZ',NULL,'Belice','BLZ'),(NULL,'BM',NULL,'Bermudas','BMU'),(NULL,'BO',NULL,'Bolivia','BOL'),(NULL,'BR',NULL,'Brasil','BRA'),(NULL,'BB',NULL,'Barbados','BRB'),(NULL,'BN',NULL,'Brunéi','BRN'),(NULL,'BT',NULL,'Bhután','BTN'),(NULL,'BV',NULL,'Isla Bouvet','BVT'),(NULL,'BW',NULL,'Botsuana','BWA'),(NULL,'CF',NULL,'República Centroafricana','CAF'),(NULL,'CA',NULL,'Canadá','CAN'),(NULL,'CC',NULL,'Islas Cocos','CCK'),(NULL,'CH',NULL,'Suiza','CHE'),(NULL,'CL',NULL,'Chile','CHL'),(NULL,'CN',NULL,'China','CHN'),(NULL,'CI',NULL,'Costa de Marfil','CIV'),(NULL,'CM',NULL,'Camerún','CMR'),(NULL,'CD',NULL,'República Democrática del Congo','COD'),(NULL,'CG',NULL,'Congo','COG'),(NULL,'CK',NULL,'Islas Cook','COK'),(NULL,'CO',NULL,'Colombia','COL'),(NULL,'KM',NULL,'Comoras','COM'),(NULL,'CV',NULL,'Cabo Verde','CPV'),(NULL,'CR',NULL,'Costa Rica','CRI'),(NULL,'CU',NULL,'Cuba','CUB'),(NULL,'CX',NULL,'Isla de Navidad','CXR'),(NULL,'KY',NULL,'Islas Caimán','CYM'),(NULL,'CY',NULL,'Chipre','CYP'),(NULL,'CZ',NULL,'República Checa','CZE'),(NULL,'DJ',NULL,'Yibuti','DJI'),(NULL,'DM',NULL,'Dominica','DMA'),(NULL,'DK',NULL,'Dinamarca','DNK'),(NULL,'DO',NULL,'República Dominicana','DOM'),(NULL,'EC',NULL,'Ecuador','ECU'),(NULL,'EG',NULL,'Egipto','EGY'),(NULL,'ER',NULL,'Eritrea','ERI'),(NULL,'EH',NULL,'Sahara Occidental','ESH'),(NULL,'ES',NULL,'España','ESP'),(NULL,'EE',NULL,'Estonia','EST'),(NULL,'ET',NULL,'Etiopía','ETH'),(NULL,'FI',NULL,'Finlandia','FIN'),(NULL,'FJ',NULL,'Fiyi','FJI'),(NULL,'FK',NULL,'Islas Malvinas','FLK'),(NULL,'FR',NULL,'Francia','FRA'),(NULL,'FO',NULL,'Islas Feroe','FRO'),(NULL,'FM',NULL,'Micronesia','FSM'),(NULL,'GA',NULL,'Gabón','GAB'),(NULL,'GB',NULL,'Reino Unido','GBR'),(NULL,'GE',NULL,'Georgia','GEO'),(NULL,'GH',NULL,'Ghana','GHA'),(NULL,'GI',NULL,'Gibraltar','GIB'),(NULL,'GN',NULL,'Guinea','GIN'),(NULL,'GP',NULL,'Guadalupe','GLP'),(NULL,'GM',NULL,'Gambia','GMB'),(NULL,'GW',NULL,'Guinea-Bissau','GNB'),(NULL,'GQ',NULL,'Guinea Ecuatorial','GNQ'),(NULL,'GR',NULL,'Grecia','GRC'),(NULL,'GD',NULL,'Granada','GRD'),(NULL,'GL',NULL,'Groenlandia','GRL'),(NULL,'GT',NULL,'Guatemala','GTM'),(NULL,'GF',NULL,'Guayana Francesa','GUF'),(NULL,'GU',NULL,'Guam','GUM'),(NULL,'GY',NULL,'Guyana','GUY'),(NULL,'HK',NULL,'Hong Kong','HKG'),(NULL,'HM',NULL,'Islas Heard y McDonald','HMD'),(NULL,'HN',NULL,'Honduras','HND'),(NULL,'HR',NULL,'Croacia','HRV'),(NULL,'HT',NULL,'Haití','HTI'),(NULL,'HU',NULL,'Hungría','HUN'),(NULL,'ID',NULL,'Indonesia','IDN'),(NULL,'IN',NULL,'India','IND'),(NULL,'IO',NULL,'Territorio Británico del Océano Índico','IOT'),(NULL,'IE',NULL,'Irlanda','IRL'),(NULL,'IR',NULL,'Irán','IRN'),(NULL,'IQ',NULL,'Iraq','IRQ'),(NULL,'IS',NULL,'Islandia','ISL'),(NULL,'IL',NULL,'Israel','ISR'),(NULL,'IT',NULL,'Italia','ITA'),(NULL,'JM',NULL,'Jamaica','JAM'),(NULL,'JO',NULL,'Jordania','JOR'),(NULL,'JP',NULL,'Japón','JPN'),(NULL,'KZ',NULL,'Kazajstán','KAZ'),(NULL,'KE',NULL,'Kenia','KEN'),(NULL,'KG',NULL,'Kirguistán','KGZ'),(NULL,'KH',NULL,'Camboya','KHM'),(NULL,'KI',NULL,'Kiribati','KIR'),(NULL,'KN',NULL,'San Cristóbal y Nieves','KNA'),(NULL,'KR',NULL,'Corea del Sur','KOR'),(NULL,'KW',NULL,'Kuwait','KWT'),(NULL,'LA',NULL,'Laos','LAO'),(NULL,'LB',NULL,'Líbano','LBN'),(NULL,'LR',NULL,'Liberia','LBR'),(NULL,'LY',NULL,'Libia','LBY'),(NULL,'LC',NULL,'Santa Lucía','LCA'),(NULL,'LI',NULL,'Liechtenstein','LIE'),(NULL,'LK',NULL,'Sri Lanka','LKA'),(NULL,'LS',NULL,'Lesotho','LSO'),(NULL,'LT',NULL,'Lituania','LTU'),(NULL,'LU',NULL,'Luxemburgo','LUX'),(NULL,'LV',NULL,'Letonia','LVA'),(NULL,'MO',NULL,'Macao','MAC'),(NULL,'MA',NULL,'Marruecos','MAR'),(NULL,'MC',NULL,'Mónaco','MCO'),(NULL,'MD',NULL,'Moldavia','MDA'),(NULL,'MG',NULL,'Madagascar','MDG'),(NULL,'MV',NULL,'Maldivas','MDV'),(NULL,'MX',NULL,'México','MEX'),(NULL,'MH',NULL,'Islas Marshall','MHL'),(NULL,'MK',NULL,'Macedonia','MKD'),(NULL,'ML',NULL,'Malí','MLI'),(NULL,'MT',NULL,'Malta','MLT'),(NULL,'MM',NULL,'Myanmar','MMR'),(NULL,'ME',NULL,'Montenegro','MNE'),(NULL,'MN',NULL,'Mongolia','MNG'),(NULL,'MP',NULL,'Islas Marianas del Norte','MNP'),(NULL,'MZ',NULL,'Mozambique','MOZ'),(NULL,'MR',NULL,'Mauritania','MRT'),(NULL,'MS',NULL,'Montserrat','MSR'),(NULL,'MQ',NULL,'Martinica','MTQ'),(NULL,'MU',NULL,'Mauricio','MUS'),(NULL,'MW',NULL,'Malaui','MWI'),(NULL,'MY',NULL,'Malasia','MYS'),(NULL,'YT',NULL,'Mayotte','MYT'),(NULL,'NA',NULL,'Namibia','NAM'),(NULL,'NC',NULL,'Nueva Caledonia','NCL'),(NULL,'NE',NULL,'Níger','NER'),(NULL,'NF',NULL,'Isla Norfolk','NFK'),(NULL,'NG',NULL,'Nigeria','NGA'),(NULL,'NI',NULL,'Nicaragua','NIC'),(NULL,'NU',NULL,'Niue','NIU'),(NULL,'NL',NULL,'Países Bajos','NLD'),(NULL,'NO',NULL,'Noruega','NOR'),(NULL,'NP',NULL,'Nepal','NPL'),(NULL,'NR',NULL,'Nauru','NRU'),(NULL,'NZ',NULL,'Nueva Zelanda','NZL'),(NULL,'OM',NULL,'Omán','OMN'),(NULL,'PK',NULL,'Pakistán','PAK'),(NULL,'PA',NULL,'Panamá','PAN'),(NULL,'PN',NULL,'Islas Pitcairn','PCN'),(NULL,'PE',NULL,'Perú','PER'),(NULL,'PH',NULL,'Filipinas','PHL'),(NULL,'PW',NULL,'Palaos','PLW'),(NULL,'PG',NULL,'Papúa Nueva Guinea','PNG'),(NULL,'PL',NULL,'Polonia','POL'),(NULL,'PR',NULL,'Puerto Rico','PRI'),(NULL,'KP',NULL,'Corea del Norte','PRK'),(NULL,'PT',NULL,'Portugal','PRT'),(NULL,'PY',NULL,'Paraguay','PRY'),(NULL,'PS',NULL,'Palestina','PSE'),(NULL,'PF',NULL,'Polinesia Francesa','PYF'),(NULL,'QA',NULL,'Qatar','QAT'),(NULL,'RE',NULL,'Reunión','REU'),(NULL,'RO',NULL,'Rumania','ROU'),(NULL,'RU',NULL,'Rusia','RUS'),(NULL,'RW',NULL,'Ruanda','RWA'),(NULL,'SD',NULL,'Sudán','SDN'),(NULL,'SN',NULL,'Senegal','SEN'),(NULL,'SG',NULL,'Singapur','SGP'),(NULL,'GS',NULL,'Islas Georgias del Sur y Sandwich del Sur','SGS'),(NULL,'SH',NULL,'Santa Helena','SHN'),(NULL,'SJ',NULL,'Svalbard y Jan Mayen','SJM'),(NULL,'SB',NULL,'Islas Salomón','SLB'),(NULL,'SL',NULL,'Sierra Leona','SLE'),(NULL,'SV',NULL,'El Salvador','SLV'),(NULL,'SM',NULL,'San Marino','SMR'),(NULL,'SO',NULL,'Somalia','SOM'),(NULL,'PM',NULL,'San Pedro y Miquelón','SPM'),(NULL,'RS',NULL,'Serbia','SRB'),(NULL,'ST',NULL,'Santo Tomé y Príncipe','STP'),(NULL,'SR',NULL,'Surinam','SUR'),(NULL,'SK',NULL,'Eslovaquia','SVK'),(NULL,'SI',NULL,'Eslovenia','SVN'),(NULL,'SE',NULL,'Suecia','SWE'),(NULL,'SZ',NULL,'Suazilandia','SWZ'),(NULL,'SC',NULL,'Seychelles','SYC'),(NULL,'SY',NULL,'Siria','SYR'),(NULL,'TC',NULL,'Islas Turcas y Caicos','TCA'),(NULL,'TD',NULL,'Chad','TCD'),(NULL,'TG',NULL,'Togo','TGO'),(NULL,'TH',NULL,'Tailandia','THA'),(NULL,'TJ',NULL,'Tayikistán','TJK'),(NULL,'TK',NULL,'Tokelau','TKL'),(NULL,'TM',NULL,'Turkmenistán','TKM'),(NULL,'TL',NULL,'Timor Oriental','TLS'),(NULL,'TO',NULL,'Tonga','TON'),(NULL,'TT',NULL,'Trinidad y Tobago','TTO'),(NULL,'TN',NULL,'Túnez','TUN'),(NULL,'TR',NULL,'Turquía','TUR'),(NULL,'TV',NULL,'Tuvalu','TUV'),(NULL,'TW',NULL,'Taiwán','TWN'),(NULL,'TZ',NULL,'Tanzania','TZA'),(NULL,'UG',NULL,'Uganda','UGA'),(NULL,'UA',NULL,'Ucrania','UKR'),(NULL,'UM',NULL,'Islas Ultramarinas de Estados Unidos','UMI'),(NULL,'UY',NULL,'Uruguay','URY'),(NULL,'US',NULL,'Estados Unidos','USA'),(NULL,'UZ',NULL,'Uzbekistán','UZB'),(NULL,'VA',NULL,'Ciudad del Vaticano','VAT'),(NULL,'VC',NULL,'San Vicente y las Granadinas','VCT'),(NULL,'VE',NULL,'Venezuela','VEN'),(NULL,'VG',NULL,'Islas Vírgenes Británicas','VGB'),(NULL,'VI',NULL,'Islas Vírgenes de los Estados Unidos','VIR'),(NULL,'VN',NULL,'Vietnam','VNM'),(NULL,'VU',NULL,'Vanuatu','VUT'),(NULL,'WF',NULL,'Wallis y Futuna','WLF'),(NULL,'WS',NULL,'Samoa','WSM'),(NULL,'YE',NULL,'Yemen','YEM'),(NULL,'ZA',NULL,'Sudáfrica','ZAF'),(NULL,'ZM',NULL,'Zambia','ZMB'),(NULL,'ZW',NULL,'Zimbabue','ZWE');
/*!40000 ALTER TABLE `paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentapago` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaportes` double DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recfinanciero` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `acreedor` tinyint(1) DEFAULT '0',
  `personafisica` tinyint(1) DEFAULT '1',
  `debaja` tinyint(1) DEFAULT '0',
  `fechabaja` date DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES ('302221231',NULL,NULL,NULL,'ARS','CONT','000001',NULL,NULL,NULL,'','',NULL,NULL,'Escuela JFK','Escuela JFK','',NULL,'General','','','CUIT','',0,0,0,'2018-08-01','000002');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secuencias`
--

DROP TABLE IF EXISTS `secuencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secuencias` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `idsec` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsec`),
  KEY `ca_secuencias_secuenciasejercicios` (`id`),
  CONSTRAINT `ca_secuencias_secuenciasejercicios` FOREIGN KEY (`id`) REFERENCES `secuenciasejercicios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secuencias`
--

LOCK TABLES `secuencias` WRITE;
/*!40000 ALTER TABLE `secuencias` DISABLE KEYS */;
INSERT INTO `secuencias` VALUES ('Secuencia del ejercicio 2018 y la serie A',1,1,'nfacturacli',1,3),('Secuencia del ejercicio 2018 y la serie B',3,2,'nfacturacli',1,2),('Secuencia del ejercicio 2018 y la serie A',1,3,'nfacturaprov',1,2);
/*!40000 ALTER TABLE `secuencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secuenciasejercicios`
--

DROP TABLE IF EXISTS `secuenciasejercicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secuenciasejercicios` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nalbarancli` int(11) NOT NULL,
  `nalbaranprov` int(11) NOT NULL,
  `nfacturacli` int(11) NOT NULL,
  `nfacturaprov` int(11) NOT NULL,
  `npedidocli` int(11) NOT NULL,
  `npedidoprov` int(11) NOT NULL,
  `npresupuestocli` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_secuenciasejercicios_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_secuenciasejercicios_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secuenciasejercicios`
--

LOCK TABLES `secuenciasejercicios` WRITE;
/*!40000 ALTER TABLE `secuenciasejercicios` DISABLE KEYS */;
INSERT INTO `secuenciasejercicios` VALUES ('2018','A',1,1,1,1,1,1,1,1),('2018','R',2,1,1,1,1,1,1,1),('2018','B',3,1,1,1,1,1,1,1),('2018','C',4,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `secuenciasejercicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `series`
--

DROP TABLE IF EXISTS `series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `series` (
  `irpf` double DEFAULT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `siniva` tinyint(1) DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `numfactura` int(11) DEFAULT '1',
  PRIMARY KEY (`codserie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `series`
--

LOCK TABLES `series` WRITE;
/*!40000 ALTER TABLE `series` DISABLE KEYS */;
INSERT INTO `series` VALUES (0,NULL,'A','SERIE A',0,NULL,NULL,1),(0,NULL,'B','SERIE B',0,NULL,NULL,1),(0,NULL,'C','SERIE C',0,NULL,NULL,1),(0,NULL,'R','RECTIFICATIVAS',0,NULL,NULL,1);
/*!40000 ALTER TABLE `series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stocks` (
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `disponible` double NOT NULL,
  `stockmin` double NOT NULL DEFAULT '0',
  `reservada` double NOT NULL,
  `horaultreg` time DEFAULT '00:00:00',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `pterecibir` double NOT NULL,
  `fechaultreg` date DEFAULT '2018-08-25',
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `cantidadultreg` double NOT NULL DEFAULT '0',
  `idstock` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` double NOT NULL DEFAULT '0',
  `stockmax` double NOT NULL DEFAULT '0',
  `ubicacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idstock`),
  UNIQUE KEY `uniq_stocks_almacen_referencia` (`codalmacen`,`referencia`),
  KEY `ca_stocks_articulos2` (`referencia`),
  CONSTRAINT `ca_stocks_almacenes3` FOREIGN KEY (`codalmacen`) REFERENCES `almacenes` (`codalmacen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_stocks_articulos2` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifas`
--

DROP TABLE IF EXISTS `tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tarifas` (
  `incporcentual` double NOT NULL,
  `inclineal` double NOT NULL,
  `aplicar_a` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `mincoste` tinyint(1) DEFAULT '0',
  `maxpvp` tinyint(1) DEFAULT '0',
  `codtarifa` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codtarifa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifas`
--

LOCK TABLES `tarifas` WRITE;
/*!40000 ALTER TABLE `tarifas` DISABLE KEYS */;
INSERT INTO `tarifas` VALUES (0,0,'pvp','100',0,0,'000001'),(0,-120,'pvp','Preescolar',0,0,'000002'),(0,-120,'pvp','Primaria',0,0,'000003'),(0,-150,'pvp','Secundaria',0,0,'000004');
/*!40000 ALTER TABLE `tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketprintjob`
--

DROP TABLE IF EXISTS `ticketprintjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketprintjob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `texto` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketprintjob`
--

LOCK TABLES `ticketprintjob` WRITE;
/*!40000 ALTER TABLE `ticketprintjob` DISABLE KEYS */;
INSERT INTO `ticketprintjob` VALUES (1,'factura','\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n           CUIT: CUIT: 30-54050846-8          \n=============================================\n\n               FACTURA FAC2018A1              \n              01-07-2018 20:29:01             \nCLIENTE: tito\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\n                                            3\ncuota mes agosto\nPVP:                                    58.00\nIMPORTE:                               138.36\n=============================================\nIVA                                     29.05\nTOTAL DEL DOCUMENT:                    167.41\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n           CUIT: CUIT: 30-54050846-8          \n=============================================\n\n               FACTURA FAC2018A1              \n              01-07-2018 20:29:01             \nCLIENTE: tito\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\n                                            3\ncuota mes agosto\nPVP:                                    58.00\nIMPORTE:                               138.36\n=============================================\nIVA                                     29.05\nTOTAL DEL DOCUMENT:                    167.41\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n        CUIT/CUIL: CUIT: 30-54050846-8        \n=============================================\n\n               FACTURA FAC2018B1              \n              11-08-2018 13:07:35             \nCLIENTE: Perez Juan\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\nIVA                                      0.00\nTOTAL DEL DOCUMENT:                      0.00\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018B1\0\n\n\n\ni\n\n----------------------------------------\n           Instituto JFKennedy          \n            AV CONGRESO 1816            \n               TEL: 422222              \n\nINSTITUTO PRIVADO JOHN FITTZGERALD KENNE\n     CUIT/CUIL: CUIT: 30-54050846-8     \n========================================\n\n            FACTURA FAC2018A1           \n           01-07-2018 20:29:01          \nCLIENTE: tito\n========================================\nREFERENCIA                      CANTIDAD\n========================================\n                                       3\ncuota mes agosto\nPVP:                               58.00\nIMPORTE:                          138.36\n========================================\nIVA                                29.05\nTOTAL DEL DOCUMENT:               167.41\n\n\n               acme.com.ar              \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n----------------------------------------\n           Instituto JFKennedy          \n            AV CONGRESO 1816            \n               TEL: 422222              \n\nINSTITUTO PRIVADO JOHN FITTZGERALD KENNE\n     CUIT/CUIL: CUIT: 30-54050846-8     \n========================================\n\n            FACTURA FAC2018A1           \n           01-07-2018 20:29:01          \nCLIENTE: tito\n========================================\nREFERENCIA                      CANTIDAD\n========================================\n                                       3\ncuota mes agosto\nPVP:                               58.00\nIMPORTE:                          138.36\n========================================\nIVA                                29.05\nTOTAL DEL DOCUMENT:               167.41\n\n\n               acme.com.ar              \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n');
/*!40000 ALTER TABLE `ticketprintjob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transstock`
--

DROP TABLE IF EXISTS `transstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transstock` (
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `codalmadestino` varchar(4) COLLATE utf8_bin NOT NULL,
  `codalmaorigen` varchar(4) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `idtrans` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idtrans`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transstock`
--

LOCK TABLES `transstock` WRITE;
/*!40000 ALTER TABLE `transstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `transstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tutores`
--

DROP TABLE IF EXISTS `tutores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tutores` (
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `nombre` text COLLATE utf8_bin NOT NULL,
  `apellido` text COLLATE utf8_bin NOT NULL,
  `documento` text COLLATE utf8_bin NOT NULL,
  `direccion` text COLLATE utf8_bin NOT NULL,
  `habilitado` tinyint(1) DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `fechacreado` date NOT NULL,
  `fechaactualizado` date DEFAULT NULL,
  PRIMARY KEY (`referencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutores`
--

LOCK TABLES `tutores` WRITE;
/*!40000 ALTER TABLE `tutores` DISABLE KEYS */;
INSERT INTO `tutores` VALUES ('1','a','s','d','f',NULL,'g','2018-08-25','2018-08-25'),('2','a','b','c','d',NULL,'e','2018-08-25','2018-08-25'),('3','q','w','e','r',NULL,'t','2018-08-25','2018-08-25');
/*!40000 ALTER TABLE `tutores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-27 20:36:57
SET FOREIGN_KEY_CHECKS=1;
COMMIT;
SET AUTOCOMMIT=1;

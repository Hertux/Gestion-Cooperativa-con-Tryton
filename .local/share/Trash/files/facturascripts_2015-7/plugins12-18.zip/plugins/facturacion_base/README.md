# facturacion_base
Plugin para FacturaScripts con las funciones básicas de facturación, contabilidad e informes simples.

https://www.facturascripts.com/plugin/facturacion_base
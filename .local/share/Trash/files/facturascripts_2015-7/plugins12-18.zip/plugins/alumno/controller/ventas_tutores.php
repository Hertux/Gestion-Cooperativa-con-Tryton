<?php
require_once 'plugins/facturacion_base/extras/fbase_controller.php';
/// la clase se debe llamar igual que el archivo
class ventas_tutores extends fbase_controller
{
  public $resultados;
  public $b_bloqueados;
  public $tutor;
  public $total_resultados;

  public function __construct()
  {
    parent::__construct(__CLASS__, 'Tutores', 'ventas');
    /// se crea una entrada 'Mi controlador' dentro del menú 'Mio'
    // parent::__construct(__CLASS__, 'tutor', 'ventas', FALSE, FALSE);
  }
  
  protected function private_core()
  {
    /// tu código php lo pondrás aquí
    parent::private_core();
    $this->resultados = array();
    
    // Solo mostrar los tutores habilitados si el checkbox está seleccionado.
    if (isset($_POST['b_bloqueados'])) {
      $this->b_bloqueados = 1;
    }
    else {
      $this->b_bloqueados = 0;
    }
    
    // Armado de consulta.
    $consulta = "SELECT * FROM tutores";
    if (!$this->b_bloqueados) {
      $consulta = $consulta . " WHERE habilitado = 1";
    }
    $consulta = $consulta . ";";
    
    // Seleccionar todos los tutores.
    $data2 = $this->db->select($consulta);
    
    if($data2) {
	  foreach($data2 as $tutor_data) {
		$this->resultados[] = new tutor($tutor_data);
	  }
  }
    $this->total_resultados = count($this->resultados);
    $this->tutor = new tutor();
    
    $this->check_extensions();
    // logica en caso de post
    if (isset($_POST['referencia'])) {
      //isset('') da 1
      if (isset($_POST['referencia']) && isset($_POST['nombre']) && isset($_POST['apellido'])) {
        $this->new_tutor($this->tutor);
      } else {
        $this->tutor = $this->tutor->get($_POST['referencia']);
        if($this->tutor) {
          if (!$this->tutor->habilitado) {
            $this->new_advice("Este item está bloqueado / obsoleto.");
          } else {
            $this->modificar();
            $this->page->title = $this->tutor->referencia;
          }
        }
      }
    } else if (isset($_GET['delete'])) {
      $this->delete_tutor($this->tutor);
    } else if (isset($_GET['ref'])) {
      $this->tutor= $this->tutor->get($_GET['ref']);
      // TODO: VISTA DE EDICION PARA UN SOLO ITEM
      $this->new_error_msg("Tutor no encontrado.", 'error', FALSE, FALSE);
    }
    
/*
      $this->tutor = $tutor->get($_POST['referencia']);
      $this->modificar(); /// todas las modificaciones van aquí
      $this->page->title = $this->tutor->referencia;
    }  else if (isset($_GET['delete'])) {
      $this->delete_tutor($tutor);
    } else if (isset($_GET['ref'])) {
      $this->tutor= $tutor->get($_GET['ref']);
    } else {
      $this->tutor = FALSE;
    }
    if ($this->tutor) {
     
      if (!$this->tutor->habilitado) {
        $this->new_advice("Este item está bloqueado / obsoleto.");
      }
    } else {
      // $this->new_error_msg("Tutor no encontrado.", 'error', FALSE, FALSE);
    }
*/
  }

  private function new_tutor(&$tutor)
  {
    if ($_POST['referencia'] == '') {
      $referencia = $tutor->get_new_referencia();
    } else {
      $referencia = $_POST['referencia'];
    }
    $art0 = $tutor->get($referencia);
    if ($art0) {
      $this->new_error_msg('Ya existe el tutor <a href="' . $art0->url() . '">' . $art0->referencia . '</a>');
    } else {
      $tutor->referencia = $referencia;
      $tutor->nombre = $_POST['nombre'];
      $tutor->apellido = $_POST['apellido'];
      if ($_POST['documento'] != '') {
        $tutor->documento = $_POST['documento'];
      }
      if ($_POST['direccion'] != '') {
        $tutor->direccion = $_POST['direccion'];
      }
      if ($_POST['telefono'] != '') {
        $tutor->telefono = $_POST['telefono'];
      }
      if ($_POST['descripcion'] != '') {
        $tutor->descripcion = $_POST['descripcion'];
      }
      $tutor->habilitado = 1;
      if ($tutor->save()) {
        header('location: ' . $tutor->url());
      } else {
        $this->new_error_msg("¡Error al crear el alumno!");
      }
    }
  }

  private function delete_tutor(&$tutor)
  {
    $art = $tutor->get($_GET['delete']);
    if ($art) {
      if (!$this->allow_delete) {
        $this->new_error_msg('No tienes permiso para eliminar en esta página.');
      } else if ($art->delete()) {
        $this->new_message("tutor " . $art->referencia . " eliminado correctamente.", TRUE);
      } else {
        $this->new_error_msg("¡Error al eliminarl el tutor!");
      }
    } else {
      $this->new_error_msg("tutor no encontrado.");
    }
  }
  
  public function url()
  {
    if ($this->tutor) {
      return $this->tutor->url();
    }
    return $this->page->url();
  }
    private function check_extensions()
  {
    /**
     * Si hay alguna extensión de tipo config y texto no_button_publicar,
     * desactivamos el botón publicar.
     */
    $this->mostrar_boton_publicar = TRUE;
    foreach ($this->extensions as $ext) {
      if ($ext->type == 'config' && $ext->text == 'no_button_publicar') {
        $this->mostrar_boton_publicar = FALSE;
        break;
      }
    }
  }
  /**
   * Decide qué modificación hacer en función de los parametros del formulario.
   */
  private function modificar()
  {
    if (isset($_POST['referencia'])) {
      $this->modificar_tutor();
    }
  }

  private function modificar_tutor()
  {
    $this->tutor->descripcion = $_POST['descripcion'];
    $this->tutor->descripcion = NULL;
    if ($_POST['descripcion'] != '') {
      $this->tutor->descripcion = $_POST['descripcion'];
    }
    $this->tutor->nombre = $_POST['nombre'];
    $this->tutor->apellido = $_POST['apellido'];
    $this->tutor->documento = $_POST['documento'];
    $this->tutor->direccion = $_POST['direccion'];
    $this->tutor->telefono = $_POST['telefono'];
    $this->tutor->habilitado = isset($_POST['habilitado']);
    if ($this->alumno->save()) {
      $this->new_message("Datos del tutor modificados correctamente");
    } else {
      $this->new_error_msg("¡Error al guardar el tutor!");
    }
  }
}

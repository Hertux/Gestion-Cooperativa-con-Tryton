<?php
namespace FacturaScripts\alumno\model;
/// la clase se debe llamar igual que el archivo
class tutor extends \fs_model
{
  // Clave primaria
  public $referencia;
  public $nombre;
  public $apellido;
  public $documento;
  public $direccion;
  public $telefono;
  public $habilitado;
  public $descripcion;
  public $fechacreado;
  public $fechaactualizado;
  private $exists;
  private static $column_list;
  
  // public $columna1;

    public function __construct($data = FALSE)
    {
        parent::__construct('tutores', $data); /// aquí indicamos el NOMBRE DE LA TABLA
        self::$column_list = 'referencia,nombre,apellido,documento,direccion,telefono,habilitado,' .
                'descripcion,fechacreado,fechaactualizado';
        
        if($data) {
		        $this->referencia = $data['referencia'];
	          $this->nombre = $data['nombre'];
            $this->apellido = $data['apellido'];
            $this->documento = $data['documento'];
            $this->direccion = $data['direccion'];
            $this->telefono = $data['telefono'];
            $this->habilitado = $data['habilitado'];
            $this->descripcion = $data['descripcion'];
            $this->fechacreado = $data['fechacreado'];
            $this->fechaactualizado = $data['fechaactualizado'];
		}
    }
    
    /**
     * Devuelve una nueva referencia, la siguiente a la última de la base de datos.
     * @return string
     */
    public function get_new_referencia()
    {
      if (strtolower(FS_DB_TYPE) == 'postgresql') {
        $sql = "SELECT referencia from " . $this->table_name . " where referencia ~ '^\d+$'"
        . " ORDER BY referencia::bigint DESC";
      } else {
        $sql = "SELECT referencia from " . $this->table_name . " where referencia REGEXP '^[0-9]+$'"
        . " ORDER BY ABS(referencia) DESC";
      }
      $ref = 1;
      $data = $this->db->select_limit($sql, 1, 0);
      if ($data) {
        $ref = sprintf(1 + intval($data[0]['referencia']));
      }
      $this->exists = FALSE;
      return (string) $ref;
    }
    
    /**
     * Devuelve el listado de tutores desde el resultado $offset hasta $offset+$limit.
     * @param integer $offset desde
     * @param integer $limit nº de elementos devuelto
     * @return \tutor
     */
    public function all($offset = 0, $limit = FS_ITEM_LIMIT)
    {
      $sql = "SELECT " . self::$column_list . " FROM " . $this->table_name
      . " ORDER BY lower(referencia) ASC";
      return $this->all_from($sql, $offset, $limit);
    }
    
    private function all_from($sql, $offset = 0, $limit = FS_ITEM_LIMIT)
    {
      $artilist = array();
      $data = $this->db->select_limit($sql, $limit, $offset);
      if ($data) {
        foreach ($data as $a) {
          $artilist[] = new \alumno($a);
        }
      }
      return $artilist;
    }
    
    /**
     * Devuelve un array con los tutores encontrados en base a la búsqueda.
     * @param string $query
     * @param integer $offset
     * @param string $apellido
     * @param string $nombre
     * @param string $documento
     * @param boolean $habilitado
     * @return \tutor
     */
    public function search($query = '', $offset = 0, $apellido = '', $nombre = '', $documento = '', $telefono = '', $habilitado = FALSE)
    {
      $artilist = array();
      $query = $this->no_html(mb_strtolower($query, 'UTF8'));
      if (count($artilist) <= 1) {
        $sql = "SELECT " . self::$column_list . " FROM " . $this->table_name;
        $separador = ' WHERE';
        if ($query == '') {
          /// nada
        } else if (is_numeric($query)) {
          $sql .= $separador . " (referencia = " . $this->var2str($query)
          . " OR referencia LIKE '%" . $query . "%')";
          $separador = ' AND';
        } else {
          /// ¿La búsqueda son varias palabras?
          $palabras = explode(' ', $query);
          if (count($palabras) > 1) {
            $sql .= $separador . " (lower(referencia) = " . $this->var2str($query)
            . " OR lower(referencia) LIKE '%" . $query . "%'"
            . " OR (";
            foreach ($palabras as $i => $pal) {
              if ($i == 0) {
                $sql .= "lower(descripcion) LIKE '%" . $pal . "%'";
              } else {
                $sql .= " AND lower(descripcion) LIKE '%" . $pal . "%'";
              }
            }
            $sql .= "))";
          } else {
            $sql .= $separador . " (lower(referencia) = " . $this->var2str($query)
            . " OR lower(referencia) LIKE '%" . $query . "%'"
            . " OR lower(descripcion) LIKE '%" . $query . "%')";
          }
        }
        if (strtolower(FS_DB_TYPE) == 'mysql') {
          $sql .= " ORDER BY lower(referencia) ASC";
        } else {
          $sql .= " ORDER BY referencia ASC";
        }
        $artilist = $this->all_from($sql, $offset);
      }
      return $artilist;
    }
    
    /**
     * Elimina el tutor de la base de datos.
     * @return boolean
     */
    public function delete()
    {
        $this->clean_cache();
        $sql .= "DELETE FROM " . $this->table_name . " WHERE referencia = " . $this->var2str($this->referencia) . ";";
        if ($this->db->exec($sql)) {
            $this->exists = FALSE;
            return TRUE;
        }
        return FALSE;
    }
    
    /**
     * Guarda en la base de datos los datos del tutor.
     * @return boolean
     */
    public function save()
    {
        if ($this->test()) {
            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET descripcion = " . $this->var2str($this->descripcion) .
                    ", nombre = " . $this->var2str($this->nombre) .
                    ", apellido = " . $this->var2str($this->apellido) .
                    ", documento = " . $this->var2str($this->documento) .
                    ", direccion = " . $this->var2str($this->direccion) . 
                    ", telefono = " . $this->var2str($this->telefono) .
                    ", habilitado = " . $this->var2str($this->habilitado) .
                    "  WHERE referencia = " . $this->var2str($this->referencia) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (" . self::$column_list . ") VALUES (" .
                    $this->var2str($this->referencia) . "," .
                    $this->var2str($this->nombre) . "," .
                    $this->var2str($this->apellido) . "," .
                    $this->var2str($this->documento) . "," .
                    $this->var2str($this->direccion) . "," .
                    $this->var2str($this->telefono) . "," .
                    $this->var2str($this->habilitado) . "," .
                    $this->var2str($this->descripcion) . ",NOW(),NOW());";
            }
            if ($this->db->exec($sql)) {
                $this->exists = TRUE;
                return TRUE;
            }
        }
        return FALSE;
    }
    
    /**
     * Devuelve TRUE  si los datos del artículo son correctos.
     * @return boolean
     */
    public function test()
    {
        $status = FALSE;

        $this->descripcion = $this->no_html($this->descripcion);

        if (is_null($this->referencia) || strlen($this->referencia) < 1 || strlen($this->referencia) > 18) {
            $this->new_error_msg("Referencia de tutor no válida: " . $this->referencia . ". Debe tener entre 1 y 18 caracteres.");
        } else {
            $status = TRUE;
        }

        return $status;
    }
    
    /**
     * Devuelve la url donde ver/modificar estos datos
     * @return string
     */
    public function url()
    {
        if (is_null($this->referencia)) {
            return "index.php?page=ventas_tutores";
        }

        return "index.php?page=ventas_tutores&ref=" . urlencode($this->referencia);
    }
    
    /**
     * Devuelve un artículo a partir de su referencia
     * @param string $ref
     * @return boolean|\tutor
     */
    public function get($ref)
    {
        $data = $this->db->select("SELECT " . self::$column_list . " FROM " . $this->table_name . " WHERE referencia = " . $this->var2str($ref) . ";");
        if ($data) {
            return new \tutor($data[0]);
        }

        return FALSE;
    }
    
    /**
     * Cambia la referencia del artículo.
     * Lo hace en el momento, no hace falta hacer save().
     * @param string $ref
     */
    public function set_referencia($ref)
    {
        $ref = trim($ref);
        if (is_null($ref) || strlen($ref) < 1 || strlen($ref) > 18) {
            $this->new_error_msg("¡Referencia de tutor no válida! Debe tener entre 1 y 18 caracteres.");
        } else if ($ref != $this->referencia && ! is_null($this->referencia)) {
            $sql = "UPDATE " . $this->table_name . " SET referencia = " . $this->var2str($ref)
                . " WHERE referencia = " . $this->var2str($this->referencia) . ";";
            if ($this->db->exec($sql)) {
                $this->referencia = $ref;
            } else {
                $this->new_error_msg('Imposible modificar la referencia.');
            }
        }
        $this->exists = FALSE;
    }
    
     /**
     * Esta función devuelve TRUE si el tutor ya existe en la base de datos.
     * Por motivos de rendimiento y al ser esta una clase de uso intensivo,
     * se utiliza la variable $this->exists para almacenar el resultado.
     * @return boolean
     */
    public function exists()
    {
        if (!$this->exists) {
            if ($this->db->select("SELECT referencia FROM " . $this->table_name . " WHERE referencia = " . $this->var2str($this->referencia) . ";")) {
                $this->exists = TRUE;
            }
        }
        return $this->exists;
    }
    
    public function model_class_name()
    {
        return 'mi_modelo';
    }

    public function primary_column()
    {
        return 'id';
    }
}

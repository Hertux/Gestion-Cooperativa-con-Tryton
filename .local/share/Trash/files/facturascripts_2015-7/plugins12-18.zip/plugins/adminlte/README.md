__adminlte__ es un plugins que modifica el estilo visual de FacturaScripts aportando un menú lateral y mayor variedad de iconos.
Licencia Affero GPL 3.

https://www.facturascripts.com/plugin/adminlte
-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-11-2018 a las 23:31:32
-- Versión del servidor: 10.1.13-MariaDB
-- Versión de PHP: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `facturas1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agenciastrans`
--

CREATE TABLE `agenciastrans` (
  `codtrans` varchar(8) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agentes`
--

CREATE TABLE `agentes` (
  `apellidos` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `coddepartamento` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dnicif` varchar(15) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `idusuario` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `nombreap` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `seg_social` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banco` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `f_alta` date DEFAULT NULL,
  `f_baja` date DEFAULT NULL,
  `f_nacimiento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `agentes`
--

INSERT INTO `agentes` (`apellidos`, `ciudad`, `codagente`, `coddepartamento`, `codpais`, `codpostal`, `direccion`, `dnicif`, `email`, `fax`, `idprovincia`, `idusuario`, `irpf`, `nombre`, `nombreap`, `porcomision`, `provincia`, `telefono`, `seg_social`, `cargo`, `banco`, `f_alta`, `f_baja`, `f_nacimiento`) VALUES
('Pepe', 'Victoria', '1', NULL, NULL, '', '', '00000014Z', '', NULL, NULL, NULL, NULL, 'Paco', NULL, 0, 'Entre Ríos', '', '', '', '', NULL, NULL, NULL),
('Ferrari', 'Victoria', '2', NULL, NULL, '', '', '12312312', 'nuni@acme.com', NULL, NULL, NULL, NULL, 'Nuni', NULL, 0, 'Entre Ríos', '422222', '', '', '', '2018-07-01', NULL, '2018-07-01'),
('Ferrari', 'Victoria', '3', NULL, NULL, '', '', '22123123', 'acme@acme.com', NULL, NULL, NULL, NULL, 'Jose', NULL, 0, 'Entre Ríos', '423213', '', '', '', '2018-07-11', NULL, '2018-07-11'),
('b', 'Victoria', '4', NULL, NULL, '', '', '20221221224', 'acme@acme.com', NULL, NULL, NULL, NULL, 'tito', NULL, 0, 'Entre Ríos', '422222', '', '', '', '2018-08-04', NULL, '2018-08-04'),
('Secretaria', '', '5', NULL, NULL, '', '', 'si', '0', NULL, NULL, NULL, NULL, 'Secretaria', NULL, 0, '', '0', '', '', '', '2018-08-28', NULL, '2018-08-28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `albaranescli`
--

CREATE TABLE `albaranescli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time DEFAULT '00:00:00',
  `femail` date DEFAULT NULL,
  `idalbaran` int(11) NOT NULL,
  `idfactura` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `netosindto` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombrecliente` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `apartadoenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpaisenv` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0',
  `dtopor1` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `dtopor5` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `albaranescli`
--

INSERT INTO `albaranescli` (`apartado`, `cifnif`, `ciudad`, `codagente`, `codalmacen`, `codcliente`, `coddir`, `coddivisa`, `codejercicio`, `codigo`, `codpago`, `codpais`, `codpostal`, `codserie`, `direccion`, `fecha`, `hora`, `femail`, `idalbaran`, `idfactura`, `idprovincia`, `irpf`, `netosindto`, `neto`, `nombrecliente`, `numero`, `numero2`, `observaciones`, `porcomision`, `provincia`, `ptefactura`, `recfinanciero`, `tasaconv`, `total`, `totaleuros`, `totalirpf`, `totaliva`, `totalrecargo`, `codtrans`, `codigoenv`, `nombreenv`, `apellidosenv`, `direccionenv`, `codpostalenv`, `ciudadenv`, `provinciaenv`, `apartadoenv`, `codpaisenv`, `numdocs`, `dtopor1`, `dtopor2`, `dtopor3`, `dtopor4`, `dtopor5`) VALUES
('', '15575757', 'Victoria', NULL, 'ALG', '000007', NULL, 'ARS', '2013', 'REC2013A1', 'CONT', 'ARG', '3153', 'A', 'Larrea 867', '2013-02-04', '14:39:38', NULL, 1, 6, NULL, 0, 2310.54, 2310.54, 'Mario Carrizo', '1', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 2754.57, 78.64304, 0, 444.03, 0, NULL, NULL, 'Petra', 'Tumor Trump', 'Larrea 867', '3153', 'Victoria', 'Entre Ríos', '', 'ARG', 0, 0, 0, 0, 0, 0),
('25', '302221231', 'Victoria', '2', 'ALG', '000002', NULL, 'ARS', '2017', 'REC2017A1', 'CONT', 'ARG', '3153', 'A', 'Matanza', '2017-12-15', '13:10:50', NULL, 2, 8, NULL, 0, 1985.35, 1985.35, 'Escuela JFK', '1', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 2342.21, 66.87015, 0, 356.86, 0, NULL, NULL, 'Cristiano', 'Trump D&#39;Ambrosio', 'Matanza', '3153', 'Victoria', 'Entre Ríos', '25', 'ARG', 0, 0, 0, 0, 0, 0),
('', '22222222', 'Victoria', '2', 'ALG', '000001', NULL, 'ARS', '2014', 'REC2014A1', 'CONT', 'ARG', '', 'A', '', '2014-02-08', '19:22:33', NULL, 3, 6, NULL, 0, 0, -2085.6, 'tito', '1', '', '', 0, 'Victoria', 0, 0, 35.026239, -2443.44, -69.76027, 0, -357.84, 0, NULL, NULL, 'Petra', 'Wilson Lanister', '', '', 'Victoria', 'Victoria', '', 'ARG', 0, 0, 0, 0, 0, 0),
('', '1234', 'Victoria', '2', 'ALG', '000004', NULL, 'ARS', '2013', 'REC2013A2', 'CONT', 'ARG', '3153', 'A', 'test', '2013-09-13', '17:53:19', NULL, 4, 6, NULL, 0, 22130.06, 22130.06, 'cliente1', '2', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 26705.97, 762.45611, 0, 4575.91, 0, NULL, NULL, '&quot;El puto amo&quot;', 'Lanister Ronaldo', 'test', '3153', 'Victoria', 'Entre Ríos', '', 'ARG', 0, 0, 0, 0, 0, 0),
('', '201221224', 'Victoria', NULL, 'ALG', '000006', NULL, 'ARS', '2018', 'REC2018A1', 'CONT', 'ARG', '', 'A', 'Chacabuco 138', '2018-03-06', '11:46:37', NULL, 5, 8, NULL, 0, 0, -9891, 'Gómez Pedro', '1', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, -11926.37, -340.49816, 0, -2035.37, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '201221231235', 'Victoria', '2', 'ALG', '000005', NULL, 'ARS', '2013', 'REC2013A3', 'CONT', 'ARG', '3153', 'A', 'Basualdo 177', '2013-06-01', '13:44:23', NULL, 6, 6, NULL, 0, 8437.17, 8437.17, 'Carlos Tomattis', '3', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 10163.71, 290.17417, 0, 1726.54, 0, NULL, NULL, 'Cecilia', 'Mendoza Ñostromo', 'Basualdo 177', '3153', 'Victoria', 'Entre Ríos', '', 'ARG', 0, 0, 0, 0, 0, 0),
('', '20222123', 'Victoria', NULL, 'ALG', '000003', NULL, 'ARS', '2018', 'REC2018A2', 'CONT', 'ARG', '3153', 'A', 'Basualdo y Bvard. Moreno', '2018-09-05', '15:40:10', NULL, 7, NULL, NULL, 0, 0, 0, 'Perez Juan', '2', '38528', 'Nunca tendré compasión por los que no supieron morir a tiempo\n      \n      \n        \n      \n    \n    \n        \n          Rodrigo Díaz de Vivar, el Cid CampeadorCaballero español (n. ¿Vivar, Burgos?; c. 1050 – m. Valencia; ¿10 de julio? de 1099).', 0, 'Entre Ríos', 1, 0, 35.026239, 0, 0, 0, 0, 0, NULL, NULL, 'Mia', 'Errejón Obama', 'Basualdo y Bvard. Moreno', '3153', 'Victoria', 'Entre Ríos', '', 'ARG', 0, 0, 0, 0, 0, 0),
(NULL, '226016356J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A2', 'CONT', NULL, '', 'A', '', '2017-02-20', '16:32:47', NULL, 8, NULL, NULL, 0, 0, 0, 'Pepe Lanister Aznar', '2', '', '', 0, '', 1, 0, 35.026239, 0, 0, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '872580160J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A3', 'CONT', NULL, '', 'A', '', '2018-06-20', '17:31:40', NULL, 9, NULL, NULL, 0, 0, 27481.34, 'Riola Smith Maximiliano', '3', '', '', 0, '', 1, 0, 35.026239, 27481.34, 784.59294, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '201221224', 'Victoria', '4', 'ALG', '000006', NULL, 'ARS', '2016', 'REC2016A1', 'TRANS', 'ARG', '', 'A', 'Chacabuco 138', '2016-09-07', '13:51:49', NULL, 10, 7, NULL, 0, 3199.8, 3199.8, 'Gómez Pedro', '1', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 3635.59, 103.79619, 0, 435.79, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('25', '302221231', 'Victoria', '4', 'ALG', '000002', NULL, 'ARS', '2018', 'REC2018A4', 'TRANS', 'ARG', '3153', 'A', 'Matanza', '2018-07-16', '17:22:41', NULL, 11, NULL, NULL, 0, 0, 5620.99, 'Escuela JFK', '4', '', '', 0, 'Entre Ríos', 1, 0, 35.026239, 6193.47, 176.82372, 0, 572.48, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '22222222', 'Victoria', '4', 'ALG', '000001', NULL, 'ARS', '2016', 'REC2016A2', 'TRANS', 'ARG', '', 'A', '', '2016-02-25', '10:27:39', NULL, 12, 7, NULL, 0, 1913.59, 1913.59, 'tito', '2', '', '', 0, 'Victoria', 0, 0, 35.026239, 2179.15, 62.21479, 0, 265.56, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '15575757', 'Victoria', '4', 'ALG', '000007', NULL, 'ARS', '2018', 'REC2018A5', 'TRANS', 'ARG', '3153', 'A', 'Larrea 867', '2018-11-10', '19:54:37', NULL, 13, NULL, NULL, 0, 0, -3604, 'Mario Carrizo', '5', '', '', 0, 'Entre Ríos', 1, 0, 35.026239, -3831.22, -109.38143, 0, -227.22, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '236992444J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A6', 'CONT', NULL, '', 'A', '', '2018-07-01', '15:36:37', NULL, 14, NULL, NULL, 0, 0, 1332.22, '&quot;El nota&quot; Gómez Snow', '6', '21689', 'Pagado', 0, '', 1, 0, 35.026239, 1332.22, 38.03491, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '1234', 'Victoria', NULL, 'ALG', '000004', NULL, 'ARS', '2018', 'REC2018A7', 'TRANS', 'ARG', '3153', 'A', 'test', '2018-08-08', '19:23:58', NULL, 15, NULL, NULL, 0, 0, 1800.96, 'cliente1', '7', '', '', 0, 'Entre Ríos', 1, 0, 35.026239, 2106.43, 60.13863, 0, 305.47, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '983561728J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A8', 'CONT', NULL, '', 'A', '', '2018-02-10', '10:40:46', NULL, 16, 8, NULL, 0, 5235.43, 5235.43, 'Wilson Petrov Pacheco', '8', '', '', 0, '', 0, 0, 35.026239, 5235.43, 149.47166, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '24820353J', '', '2', 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A3', 'CONT', NULL, '', 'A', '', '2016-10-10', '13:56:58', NULL, 17, 7, NULL, 0, 1873.56, 1873.56, 'Pedro Tumor Stark', '3', '', '', 0, '', 0, 0, 35.026239, 1873.56, 53.49018, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '201221231235', 'Victoria', '4', 'ALG', '000005', NULL, 'ARS', '2015', 'REC2015A1', 'TRANS', 'ARG', '3153', 'A', 'Basualdo 177', '2015-08-13', '13:17:29', NULL, 18, 7, NULL, 0, 2436.3, 2436.3, 'Carlos Tomattis', '1', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 2748.39, 78.4666, 0, 312.09, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '922485068J', '', '2', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A2', 'CONT', NULL, '', 'A', '', '2014-04-01', '14:33:24', NULL, 19, 6, NULL, 0, 0, -1870.76, 'Emiliana Tumor García', '2', '', '', 0, '', 0, 0, 35.026239, -1870.76, -53.41024, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '20222123', 'Victoria', NULL, 'ALG', '000003', NULL, 'ARS', '2018', 'REC2018A9', 'TRANS', 'ARG', '3153', 'A', 'Basualdo y Bvard. Moreno', '2018-09-08', '10:42:32', NULL, 20, NULL, NULL, 0, 0, 1940, 'Perez Juan', '9', '', '', 0, 'Entre Ríos', 1, 0, 35.026239, 2255, 64.38031, 0, 315, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '509303529J', '', '2', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A3', 'CONT', NULL, '', 'A', '', '2017-03-04', '11:22:20', NULL, 21, 8, NULL, 0, 3177.46, 3177.46, 'Mia Stark Mendoza', '3', '', '', 0, '', 0, 0, 35.026239, 3177.46, 90.71656, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '728738890J', '', '4', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A4', 'TRANS', NULL, '', 'A', '', '2017-05-05', '13:57:32', NULL, 22, 8, NULL, 0, 1800.61, 1800.61, 'Carlos Rajoy Botella', '4', '', '', 0, '', 0, 0, 35.026239, 1800.61, 51.40746, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '541395337J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A2', 'CONT', NULL, '', 'A', '', '2015-08-07', '11:55:39', NULL, 23, 7, NULL, 0, 0, -20153.73, 'Gorka Suarez Errejón', '2', '', '', 0, '', 0, 0, 35.026239, -20153.73, -575.3895, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '591790622J', '', '4', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A3', 'TRANS', NULL, '', 'A', '', '2014-04-21', '11:54:48', NULL, 24, 6, NULL, 0, 2064.39, 2064.39, 'Pastor Obama Rivera', '3', '', '', 0, '', 0, 0, 35.026239, 2064.39, 58.93839, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '183473476J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A5', 'TRANS', NULL, '', 'A', '', '2017-03-27', '11:17:42', NULL, 25, 8, NULL, 0, 2256.5, 2256.5, 'Madonna Petrov Gómez', '5', '13934', 'La parte contratante de la primera parte será la parte contratante de la primera parte.', 0, '', 0, 0, 35.026239, 2256.5, 64.42313, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '271691891J', '', '4', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A6', 'TRANS', NULL, '', 'A', '', '2017-11-02', '11:44:40', NULL, 26, 8, NULL, 0, 0, -1414.8, 'Madonna Ñostromo Tumor', '6', '46888', 'La mejor vida no es la más larga, sino la más rica en buenas acciones\n      \n      \n        \n      \n    \n    \n        \n          Marja Skłodowska, Marie CurieCientífica polaca nacionalizada francesa (n. Varsovia; 7 de noviembre de 1867 - f. Sancellemoz, Francia; 4 de julio de 1934).', 0, '', 0, 0, 35.026239, -1414.8, -40.39258, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '236880461J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A4', 'TRANS', NULL, '', 'A', '', '2016-05-18', '16:57:36', NULL, 27, 7, NULL, 0, 300, 300, 'Wynona Maximiliano Gómez', '4', '', '', 0, '', 0, 0, 35.026239, 300, 8.56501, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '256101919J', '', '4', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A4', 'TRANS', NULL, '', 'A', '', '2014-02-03', '16:21:49', NULL, 28, 6, NULL, 0, 0, -830.28, 'Carlos Aznar Ronaldo', '4', '', '', 0, '', 0, 0, 35.026239, -830.28, -23.70451, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '332431547J', '', '4', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A7', 'TRANS', NULL, '', 'A', '', '2017-04-17', '20:22:19', NULL, 29, 8, NULL, 0, 1169.37, 1169.37, 'Cecilia Ali Cruz', '7', '', '', 0, '', 0, 0, 35.026239, 1169.37, 33.38554, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '140473217J', '', '4', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A8', 'TRANS', NULL, '', 'A', '', '2017-11-21', '15:44:14', NULL, 30, 8, NULL, 0, 5953.83, 5953.83, 'Cristiano Trump Mendoza', '8', '', '', 0, '', 0, 0, 35.026239, 5953.83, 169.982, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '418613684J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A5', 'CONT', NULL, '', 'A', '', '2016-06-18', '11:58:31', NULL, 31, 7, NULL, 0, 3474.33, 3474.33, 'Alicia Gómez Snow', '5', '', '', 0, '', 0, 0, 35.026239, 3474.33, 99.19221, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '732311710J', '', '2', 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A6', 'CONT', NULL, '', 'A', '', '2016-05-22', '12:38:45', NULL, 32, 7, NULL, 0, 1866.61, 1866.61, 'Jorge Suarez Wilson', '6', '', '', 0, '', 0, 0, 35.026239, 1866.61, 53.29176, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '916761790J', '', '4', 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A7', 'TRANS', NULL, '', 'A', '', '2016-10-08', '19:11:51', NULL, 33, 7, NULL, 0, 2501.09, 2501.09, 'Wilson Ali Humilde', '7', '92069', 'Si tienes que preguntarlo [¿qué es el jazz?], nunca lo sabrás\n      \n      \n        \n      \n    \n    \n        \n          Louis Armstrong, PopsTrompetista de jazz estadounidense (n. Nueva Orleans; 4 de agosto de 1901 – m. Nueva York; 6 de julio de 1971).', 0, '', 0, 0, 35.026239, 2501.09, 71.40618, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '374600128J', '', '2', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A3', 'CONT', NULL, '', 'A', '', '2015-01-14', '11:10:32', NULL, 34, NULL, NULL, 0, 0, 0, 'Madonna Iglesias Nieve', '3', '92303', 'Muy caro', 0, '', 1, 0, 35.026239, 0, 0, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '5672977J', '', '2', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A9', 'CONT', NULL, '', 'A', '', '2017-09-19', '12:17:30', NULL, 35, 8, NULL, 0, 2336, 2336, 'Cristiano Gómez Tumor', '9', '', '', 0, '', 0, 0, 35.026239, 2336, 66.69286, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '413403975J', '', '2', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A4', 'CONT', NULL, '', 'A', '', '2013-10-26', '20:12:38', NULL, 36, 6, NULL, 0, 0, -596.22, 'Justin Aznar Trump', '4', '', '', 0, '', 0, 0, 35.026239, -596.22, -17.0221, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '421836833J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A10', 'CONT', NULL, '', 'A', '', '2018-10-18', '18:57:25', NULL, 37, NULL, NULL, 0, 0, 1290.66, 'Wilson D&#39;Ambrosio Cruz', '10', '56558', 'Muy caro', 0, '', 1, 0, 35.026239, 1290.66, 36.84838, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '290023930J', '', '2', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A4', 'CONT', NULL, '', 'A', '', '2015-03-09', '18:19:36', NULL, 38, 7, NULL, 0, 1798, 1798, 'Petra García Gómez', '4', '82199', 'Muy barato', 0, '', 0, 0, 35.026239, 1798, 51.33294, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '340436919J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A11', 'CONT', NULL, '', 'A', '', '2018-06-23', '17:19:45', NULL, 39, NULL, NULL, 0, 0, 7654.29, 'Donald Nieve Stark', '11', '', '', 0, '', 1, 0, 35.026239, 7654.29, 218.53017, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '240856692J', '', '4', 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A8', 'TRANS', NULL, '', 'A', '', '2016-04-16', '19:55:22', NULL, 40, 7, NULL, 0, 2136.78, 2136.78, 'Pepe Pacheco Trump', '8', '63418', 'Si tienes que preguntarlo [¿qué es el jazz?], nunca lo sabrás\n      \n      \n        \n      \n    \n    \n        \n          Louis Armstrong, PopsTrompetista de jazz estadounidense (n. Nueva Orleans; 4 de agosto de 1901 – m. Nueva York; 6 de julio de 1971).', 0, '', 0, 0, 35.026239, 2136.78, 61.00512, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '676571048J', '', '2', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A5', 'CONT', NULL, '', 'A', '', '2014-01-05', '20:31:22', NULL, 41, 6, NULL, 0, 474.33, 474.33, 'Pastor Escobar Obama', '5', '', '', 0, '', 0, 0, 35.026239, 474.33, 13.54213, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '186244305J', '', '4', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A5', 'TRANS', NULL, '', 'A', '', '2015-09-12', '12:12:58', NULL, 42, 7, NULL, 0, 0, -1909.51, 'Wilson Obama Stark', '5', '', '', 0, '', 0, 0, 35.026239, -1909.51, -54.51656, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '368661320J', '', '2', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A6', 'CONT', NULL, '', 'A', '', '2015-01-27', '20:42:35', NULL, 43, 7, NULL, 0, 2199.43, 2199.43, 'Pedro Suarez Humilde', '6', '', '', 0, '', 0, 0, 35.026239, 2199.43, 62.79378, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '290758819J', '', '4', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A5', 'TRANS', NULL, '', 'A', '', '2013-10-05', '19:41:11', NULL, 44, 6, NULL, 0, 0, -2259, 'Barak Lee Sanz', '5', '', '', 0, '', 0, 0, 35.026239, -2259, -64.49451, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '975030485J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A10', 'TRANS', NULL, '', 'A', '', '2017-11-09', '20:19:42', NULL, 45, 8, NULL, 0, 3423.83, 3423.83, 'Mia Stark Mendoza', '10', '', '', 0, '', 0, 0, 35.026239, 3423.83, 97.75043, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '258984464J', '', '4', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A6', 'TRANS', NULL, '', 'A', '', '2013-11-25', '17:42:57', NULL, 46, 6, NULL, 0, 0, -2454.83, 'Riola Iglesias Pacheco', '6', '32335', 'La peor vejez es la del espíritu\n      \n      \n        \n      \n    \n    \n        \n          Henry Stuart HazlittFilósofo libertario estadounidense (n. Filadelfia, Pensilvania; 28 de noviembre de 1894 - m. Nueva York; 8 de julio de 1993).', 0, '', 0, 0, 35.026239, -2454.83, -70.08546, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '605781038J', '', '4', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A12', 'TRANS', NULL, '', 'A', '', '2018-08-01', '10:57:35', NULL, 47, NULL, NULL, 0, 0, 1798.76, 'Wilson Cruz Lee', '12', '', '', 0, '', 1, 0, 35.026239, 1798.76, 51.35464, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '665797695J', '', '4', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A7', 'TRANS', NULL, '', 'A', '', '2013-11-09', '17:12:16', NULL, 48, 6, NULL, 0, 1036.22, 1036.22, 'Emiliana Humilde Mendoza', '7', '', '', 0, '', 0, 0, 35.026239, 1036.22, 29.58411, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '263098362J', '', '4', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A8', 'TRANS', NULL, '', 'A', '', '2013-09-05', '20:48:19', NULL, 49, 6, NULL, 0, 779.87, 779.87, 'Mohamed Gómez Mendoza', '8', '84257', 'La mejor vida no es la más larga, sino la más rica en buenas acciones\n      \n      \n        \n      \n    \n    \n        \n          Marja Skłodowska, Marie CurieCientífica polaca nacionalizada francesa (n. Varsovia; 7 de noviembre de 1867 - f. Sancellemoz, Francia; 4 de julio de 1934).', 0, '', 0, 0, 35.026239, 779.87, 22.26531, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '335803714J', '', '4', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A13', 'TRANS', NULL, '', 'A', '', '2018-04-02', '17:28:44', NULL, 50, 8, NULL, 0, 7708.45, 7708.45, 'Joel Rajoy D&#39;Ambrosio', '13', '52439', 'La peor vejez es la del espíritu\n      \n      \n        \n      \n    \n    \n        \n          Henry Stuart HazlittFilósofo libertario estadounidense (n. Filadelfia, Pensilvania; 28 de noviembre de 1894 - m. Nueva York; 8 de julio de 1993).', 0, '', 0, 0, 35.026239, 7708.45, 220.07644, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('25', '302221231', 'Victoria', '2', 'ALG', '000002', NULL, 'ARS', '2015', 'REC2015A7', 'TRANS', 'ARG', '3153', 'A', 'Matanza', '2015-07-24', '18:56:50', NULL, 51, 7, NULL, 0, 1791.36, 1791.36, 'Escuela JFK', '7', '', '', 0, 'Entre Ríos', 0, 0, 35.026239, 2035.02, 58.09987, 0, 243.66, 0, NULL, NULL, 'Jo', 'Suarez Errejón', 'Matanza', '3153', 'Victoria', 'Entre Ríos', '25', 'ARG', 0, 0, 0, 0, 0, 0),
(NULL, '460044838J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A14', 'TRANS', NULL, '', 'A', '', '2018-01-24', '14:32:55', NULL, 52, 8, NULL, 0, 1355.65, 1355.65, 'Wilson Hijo de Dios Snow', '14', '', '', 0, '', 0, 0, 35.026239, 1355.65, 38.70384, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '201221224', 'Victoria', '2', 'ALG', '000006', NULL, 'ARS', '2018', 'REC2018A15', 'TRANS', 'ARG', '', 'A', 'Chacabuco 138', '2018-03-27', '18:58:48', NULL, 53, 8, NULL, 0, 1349.24, 1349.24, 'Gómez Pedro', '15', '43445', 'Pagado', 0, 'Entre Ríos', 0, 0, 35.026239, 1571.93, 44.87864, 0, 222.69, 0, NULL, NULL, 'Albert', 'Rivera Maximiliano', 'Chacabuco 138', '', 'Victoria', 'Entre Ríos', '', 'ARG', 0, 0, 0, 0, 0, 0),
('', '15575757', 'Victoria', NULL, 'ALG', '000007', NULL, 'ARS', '2014', 'REC2014A6', 'TRANS', 'ARG', '3153', 'A', 'Larrea 867', '2014-11-11', '15:54:25', NULL, 54, 6, NULL, 0, 1730.32, 1730.32, 'Mario Carrizo', '6', '40654', 'Agradar cuando se recaudan impuestos y ser sabio cuando se ama son virtudes que no han sido concedidas a los hombres\n      \n      \n        \n      \n    \n    \n        \n          Edmund BurkeEscritor irlandés (n. Dublín; 12 de enero 1729 - m. Beaconsfield; 9 de julio 1797).', 0, 'Entre Ríos', 0, 0, 35.026239, 1951.9, 55.72679, 0, 221.58, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '1234', 'Victoria', '2', 'ALG', '000004', NULL, 'ARS', '2017', 'REC2017A11', 'TRANS', 'ARG', '3153', 'A', 'test', '2017-10-21', '18:17:10', NULL, 55, 8, NULL, 0, 2450.01, 2450.01, 'cliente1', '11', '4669', 'Faltan piezas', 0, 'Entre Ríos', 0, 0, 35.026239, 2648.46, 75.6136, 0, 198.45, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '581906218J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A16', 'TRANS', NULL, '', 'A', '', '2018-03-16', '10:21:30', NULL, 56, 8, NULL, 0, 1655.64, 1655.64, '&quot;El nota&quot; Lee Smith', '16', '', '', 0, '', 0, 0, 35.026239, 1655.64, 47.26856, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '22222222', 'Victoria', NULL, 'ALG', '000001', NULL, 'ARS', '2014', 'REC2014A7', 'TRANS', 'ARG', '', 'A', '', '2014-12-11', '11:36:48', NULL, 57, 6, NULL, 0, 1278.44, 1278.44, 'tito', '7', '', '', 0, 'Victoria', 0, 0, 35.026239, 1411.61, 40.3015, 0, 133.17, 0, NULL, NULL, 'Pedro', 'Botella Maximiliano', '', '', 'Victoria', 'Victoria', '', 'ARG', 0, 0, 0, 0, 0, 0),
(NULL, '765871465J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A17', 'TRANS', NULL, '', 'A', '', '2018-03-04', '11:19:47', NULL, 58, 8, NULL, 0, 0, -2006.93, 'Donald Lee Mendoza', '17', '32523', 'Por San Fermín, el calor no tiene fin\n      \n      \n        \n      \n    \n    \n        \n          Refrán españolHoy es 7 de julio, San Fermín.', 0, '', 0, 0, 35.026239, -2006.93, -57.2979, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '678447404J', '', '2', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A9', 'TRANS', NULL, '', 'A', '', '2013-12-20', '20:57:21', NULL, 59, 6, NULL, 0, 599.22, 599.22, 'Pepe Maximiliano Ñostromo', '9', '', '', 0, '', 0, 0, 35.026239, 599.22, 17.10775, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '247368296J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A18', 'TRANS', NULL, '', 'A', '', '2018-05-09', '16:25:45', NULL, 60, NULL, NULL, 0, 0, -2194.15, 'David Pérez Snow', '18', '', '', 0, '', 1, 0, 35.026239, -2194.15, -62.64304, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '2277780J', '', '2', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A8', 'TRANS', NULL, '', 'A', '', '2015-10-21', '10:34:42', NULL, 61, 7, NULL, 0, 1252.06, 1252.06, 'Laura Sánchez Stark', '8', '52561', 'Faltan piezas', 0, '', 0, 0, 35.026239, 1252.06, 35.74634, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '985095374J', '', '2', 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A10', 'TRANS', NULL, '', 'A', '', '2013-05-04', '16:26:26', NULL, 62, 6, NULL, 0, 1620, 1620, 'Barak Hijo de Dios Ñostromo', '10', '', '', 0, '', 0, 0, 35.026239, 1620, 46.25104, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '862967618J', '', '2', 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A12', 'TRANS', NULL, '', 'A', '', '2017-12-24', '16:16:13', NULL, 63, 8, NULL, 0, 854.33, 854.33, 'Pedro Ñostromo Sánchez', '12', '58837', 'Por San Fermín, el calor no tiene fin\n      \n      \n        \n      \n    \n    \n        \n          Refrán españolHoy es 7 de julio, San Fermín.', 0, '', 0, 0, 35.026239, 854.33, 24.39114, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '260738310J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A9', 'TRANS', NULL, '', 'A', '', '2015-02-10', '13:10:21', NULL, 64, 7, NULL, 0, 1360.99, 1360.99, 'Antonio Ñostromo Cruz', '9', '', '', 0, '', 0, 0, 35.026239, 1360.99, 38.8563, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '708760820J', '', '2', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A8', 'TRANS', NULL, '', 'A', '', '2014-12-12', '19:55:28', NULL, 65, 7, NULL, 0, 1693.67, 1693.67, 'Carlos García Pacheco', '8', '', '', 0, '', 0, 0, 35.026239, 1693.67, 48.35432, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '61856968J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2013', 'REC2013A11', 'TRANS', NULL, '', 'A', '', '2013-01-11', '18:38:29', NULL, 66, 6, NULL, 0, 7986.47, 7986.47, 'Joel Botella Stark', '11', '', '', 0, '', 0, 0, 35.026239, 7986.47, 228.01392, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '306013060J', '', '2', 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A9', 'TRANS', NULL, '', 'A', '', '2016-08-04', '18:14:28', NULL, 67, 7, NULL, 0, 1916.22, 1916.22, 'Laura Sánchez D&#39;Ambrosio', '9', '68156', 'La mejor vida no es la más larga, sino la más rica en buenas acciones\n      \n      \n        \n      \n    \n    \n        \n          Marja Skłodowska, Marie CurieCientífica polaca nacionalizada francesa (n. Varsovia; 7 de noviembre de 1867 - f. Sancellemoz, Francia; 4 de julio de 1934).', 0, '', 0, 0, 35.026239, 1916.22, 54.70813, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '426083867J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A13', 'TRANS', NULL, '', 'A', '', '2017-02-04', '12:48:42', NULL, 68, 8, NULL, 0, 0, -1127.43, 'Joe Trump Obama', '13', '', '', 0, '', 0, 0, 35.026239, -1127.43, -32.18815, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '629924454J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A9', 'TRANS', NULL, '', 'A', '', '2014-11-08', '18:16:40', NULL, 69, 6, NULL, 0, 1802.22, 1802.22, 'Carmena Lanister Maximiliano', '9', '', '', 0, '', 0, 0, 35.026239, 1802.22, 51.45343, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '684879331J', '', '2', 'ALG', NULL, NULL, 'ARS', '2015', 'REC2015A10', 'TRANS', NULL, '', 'A', '', '2015-07-09', '16:24:13', NULL, 70, 7, NULL, 0, 892.33, 892.33, 'Gorka Wilson Obama', '10', '35494', 'Bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla.', 0, '', 0, 0, 35.026239, 892.33, 25.47604, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '897622952J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2017', 'REC2017A14', 'TRANS', NULL, '', 'A', '', '2017-05-26', '13:53:40', NULL, 71, 8, NULL, 0, 0, -2069.43, 'Barak Cruz Gómez', '14', '', '', 0, '', 0, 0, 35.026239, -2069.43, -59.08228, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '308082985J', '', '2', 'ALG', NULL, NULL, 'ARS', '2014', 'REC2014A10', 'TRANS', NULL, '', 'A', '', '2014-09-04', '14:19:37', NULL, 72, 6, NULL, 0, 2135.28, 2135.28, '&quot;El nota&quot; Suarez Mendoza', '10', '', '', 0, '', 0, 0, 35.026239, 2135.28, 60.9623, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '360430898J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A19', 'TRANS', NULL, '', 'A', '', '2018-09-10', '18:20:47', NULL, 73, NULL, NULL, 0, 0, -8764.71, 'Barak Trump Sanz', '19', '', '', 0, '', 1, 0, 35.026239, -8764.71, -250.23269, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '528248591J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'REC2018A20', 'TRANS', NULL, '', 'A', '', '2018-08-14', '11:37:51', NULL, 74, NULL, NULL, 0, 0, 1609.84, 'Wynona D&#39;Ambrosio García', '20', '', '', 0, '', 1, 0, 35.026239, 1609.84, 45.96097, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, '602216283J', '', NULL, 'ALG', NULL, NULL, 'ARS', '2016', 'REC2016A10', 'TRANS', NULL, '', 'A', '', '2016-02-12', '20:20:45', NULL, 75, 7, NULL, 0, 8014.72, 8014.72, 'Barak García Rivera', '10', '99978', 'Bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla, bla.', 0, '', 0, 0, 35.026239, 8014.72, 228.82046, 0, 0, 0, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0),
('', '201221231235', 'Victoria', '2', 'ALG', '000005', 5, 'ARS', '2018', 'REC2018C1', 'RAPIPAGO', 'ARG', '3153', 'C', 'Basualdo 177', '2018-09-19', '20:15:29', NULL, 76, NULL, NULL, 0, 150, 150, 'Carlos Tomattis', '1', '', '', 0, 'Entre Ríos', 1, 0, 35.026239, 150, 4.2825, 0, 0, 0, NULL, '', '', '', '', '', '', '', '', 'ARG', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `albaranesprov`
--

CREATE TABLE `albaranesprov` (
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idalbaran` int(11) NOT NULL,
  `idfactura` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `numdocs` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `albaranesprov`
--

INSERT INTO `albaranesprov` (`cifnif`, `codagente`, `codalmacen`, `coddivisa`, `codejercicio`, `codigo`, `codpago`, `codproveedor`, `codserie`, `fecha`, `hora`, `idalbaran`, `idfactura`, `irpf`, `neto`, `nombre`, `numero`, `numproveedor`, `observaciones`, `ptefactura`, `recfinanciero`, `tasaconv`, `total`, `totaleuros`, `totalirpf`, `totaliva`, `totalrecargo`, `numdocs`) VALUES
('302221231', '2', 'ALG', 'ARS', '2018', 'REM2018A1C', 'RAPIPAGO', '000001', 'A', '2018-08-22', '19:30:34', 1, NULL, 0, 300, 'Escuela JFK', '1', '1557', '', 1, 0, 33.255547, 363, 10.91547, 0, 63, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacenes`
--

CREATE TABLE `almacenes` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `observaciones` text COLLATE utf8_bin,
  `poblacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `porpvp` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipovaloracion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `altura` varchar(10) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `almacenes`
--

INSERT INTO `almacenes` (`apartado`, `codalmacen`, `codpais`, `codpostal`, `contacto`, `direccion`, `fax`, `idprovincia`, `nombre`, `observaciones`, `poblacion`, `porpvp`, `provincia`, `telefono`, `tipovaloracion`, `altura`) VALUES
(NULL, 'ALG', 'ARG', '3153', 'juan perez', 'Matanza25', '123123', NULL, 'COLEGIO PRIVADO JFK', NULL, 'Victoria', NULL, 'Entre Ríos', '123123', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `factualizado` date DEFAULT NULL,
  `bloqueado` tinyint(1),
  `equivalencia` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentairpfcom` int(11) DEFAULT NULL,
  `idsubcuentacom` int(11) DEFAULT NULL,
  `stockmin` double,
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stockfis` double,
  `stockmax` double,
  `costemedio` double,
  `preciocoste` double,
  `tipocodbarras` varchar(8) COLLATE utf8_bin,
  `nostock` tinyint(1),
  `codsubcuentacom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `codsubcuentairpfcom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `secompra` tinyint(1),
  `codfamilia` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `controlstock` tinyint(1),
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `pvp` double,
  `sevende` tinyint(1),
  `publico` tinyint(1),
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  `trazabilidad` tinyint(1),
  `codtutores` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `codfabricante`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `trazabilidad`, `codtutores`) VALUES
('2018-08-27', 0, NULL, NULL, NULL, 0, '', '', NULL, 0, 0, 0, 0, 'Code39', 0, NULL, 'si', NULL, 1, '001', 'OEM', NULL, 1, '1', NULL, 150, 1, 0, NULL, 0, 0),
('2018-10-03', NULL, NULL, NULL, NULL, 0, '', '', 'AR0', 0, 0, 0, 0, NULL, 0, NULL, 'Juan Perez', NULL, 1, '001', NULL, NULL, 1, '2', NULL, 120, 1, 0, NULL, 0, 0),
('2018-10-03', NULL, NULL, NULL, NULL, 0, '', '', 'AR0', 0, 0, 0, 0, NULL, 0, NULL, 'perez juan', NULL, 1, '002', NULL, NULL, 1, '3', NULL, 0, 1, 0, NULL, 0, 0),
('2018-10-03', NULL, NULL, NULL, NULL, 0, '', '', 'AR0', 0, 0, 0, 0, NULL, 1, NULL, 'perez juan', NULL, 1, '002', NULL, NULL, 1, '4', NULL, 0, 1, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `factualizado` date DEFAULT NULL,
  `bloqueado` tinyint(1) DEFAULT '0',
  `equivalencia` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentairpfcom` int(11) DEFAULT NULL,
  `idsubcuentacom` int(11) DEFAULT NULL,
  `stockmin` double DEFAULT '0',
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stockfis` double DEFAULT '0',
  `stockmax` double DEFAULT '0',
  `costemedio` double DEFAULT '0',
  `preciocoste` double DEFAULT '0',
  `tipocodbarras` varchar(8) COLLATE utf8_bin DEFAULT 'Code39',
  `nostock` tinyint(1) DEFAULT '0',
  `codsubcuentacom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `codsubcuentairpfcom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `secompra` tinyint(1) DEFAULT '1',
  `codfamilia` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `controlstock` tinyint(1) DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `pvp` double DEFAULT '0',
  `sevende` tinyint(1) DEFAULT '1',
  `publico` tinyint(1) DEFAULT '0',
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  `trazabilidad` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `codfabricante`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `trazabilidad`) VALUES
('2018-08-03', 0, NULL, NULL, NULL, 0, '', '12345', NULL, -71.66, 0, 0, 0, 'Code39', 0, NULL, 'Juan Perez Jr.', NULL, 1, '002', NULL, NULL, 1, '1', NULL, 120, 1, 0, '', 1),
('2018-08-11', 0, NULL, NULL, NULL, 0, '', '', NULL, -58.2, 0, 0, 0, 'Code39', 0, NULL, 'jose ferrari jr', NULL, 1, '011', NULL, NULL, 1, '2', NULL, 100, 1, 0, NULL, 0),
('2018-08-22', 0, NULL, NULL, NULL, 0, '', '12345', NULL, 0, 0, 150, 0, 'Code39', 1, NULL, 'Alumno', NULL, 1, '004', 'OEM', NULL, 1, '3', NULL, 118.11, 1, 0, '', 0),
('2018-08-28', 0, NULL, NULL, NULL, 0, '', '', NULL, -109.28, 0, 0, 0, 'Code39', 0, NULL, 'Matias Carrizo', NULL, 1, '003', 'OEM', NULL, 1, '4', NULL, 500, 1, 0, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulosprov`
--

CREATE TABLE `articulosprov` (
  `id` int(11) NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `refproveedor` varchar(25) COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin,
  `precio` double DEFAULT '0',
  `dto` double DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stock` double DEFAULT '0',
  `nostock` tinyint(1) DEFAULT '1',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `articulosprov`
--

INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
(1, '3', '000001', '3', '', 150, 0, 'AR27', 0, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo_propiedades`
--

CREATE TABLE `articulo_propiedades` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `text` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo_trazas`
--

CREATE TABLE `articulo_trazas` (
  `id` int(11) NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `numserie` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `lote` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fecha_entrada` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `idlalbventa` int(11) DEFAULT NULL,
  `idlfacventa` int(11) DEFAULT NULL,
  `idlalbcompra` int(11) DEFAULT NULL,
  `idlfaccompra` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atributos`
--

CREATE TABLE `atributos` (
  `codatributo` varchar(20) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE `cajas` (
  `id` int(11) NOT NULL,
  `fs_id` int(11) NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `f_inicio` timestamp NOT NULL DEFAULT '2018-09-12 03:00:00',
  `d_inicio` double NOT NULL DEFAULT '0',
  `f_fin` timestamp NULL DEFAULT NULL,
  `d_fin` double DEFAULT NULL,
  `tickets` int(11) DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `cajas`
--

INSERT INTO `cajas` (`id`, `fs_id`, `codagente`, `f_inicio`, `d_inicio`, `f_fin`, `d_fin`, `tickets`, `ip`) VALUES
(1, 1, '2', '2018-08-12 12:33:19', 50, NULL, 50, 0, '::1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas_terminales`
--

CREATE TABLE `cajas_terminales` (
  `id` int(11) NOT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `tickets` text COLLATE utf8_bin,
  `anchopapel` int(11) DEFAULT NULL,
  `comandocorte` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `comandoapertura` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `num_tickets` int(11) DEFAULT NULL,
  `sin_comandos` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `cajas_terminales`
--

INSERT INTO `cajas_terminales` (`id`, `codalmacen`, `codserie`, `codcliente`, `tickets`, `anchopapel`, `comandocorte`, `comandoapertura`, `num_tickets`, `sin_comandos`) VALUES
(1, 'ALG', 'A', NULL, 'p0\n', 40, '27.105', '27.112.48', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `capitalimpagado` double DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codtiporappel` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `copiasfactura` int(11) DEFAULT NULL,
  `debaja` tinyint(1) DEFAULT '0',
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `fechabaja` date DEFAULT NULL,
  `fechaalta` date DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaincluido` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recargo` tinyint(1) DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `riesgoalcanzado` double DEFAULT NULL,
  `riesgomax` double DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `personafisica` tinyint(1) DEFAULT '1',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `diaspago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`capitalimpagado`, `cifnif`, `codagente`, `codcliente`, `codcontacto`, `codcuentadom`, `codcuentarem`, `coddivisa`, `codedi`, `codgrupo`, `codpago`, `codserie`, `codsubcuenta`, `codtiporappel`, `contacto`, `copiasfactura`, `debaja`, `email`, `fax`, `fechabaja`, `fechaalta`, `idsubcuenta`, `ivaincluido`, `nombre`, `razonsocial`, `observaciones`, `recargo`, `regimeniva`, `riesgoalcanzado`, `riesgomax`, `telefono1`, `telefono2`, `tipoidfiscal`, `personafisica`, `web`, `diaspago`, `codproveedor`, `codtarifa`) VALUES
(NULL, '22222222', NULL, '000001', NULL, NULL, NULL, 'ARS', NULL, NULL, 'CONT', NULL, NULL, NULL, NULL, NULL, 0, '', '', NULL, '2018-07-01', NULL, NULL, 'tito', 'tito', '', 0, 'General', NULL, NULL, '', '', 'DNI', 1, '', NULL, NULL, NULL),
(NULL, '302221231', NULL, '000002', NULL, NULL, NULL, 'ARS', NULL, NULL, 'CONT', NULL, NULL, NULL, NULL, NULL, 0, '', '', NULL, '2018-08-01', NULL, NULL, 'Escuela JFK', 'Escuela JFK', '', 0, 'General', NULL, NULL, '', '', 'CUIT', 0, '', NULL, '000001', NULL),
(NULL, '20222123', '3', '000003', NULL, NULL, NULL, 'ARS', NULL, '000001', 'CONT', NULL, NULL, NULL, NULL, NULL, 0, 'juanperez@acme.com', '', NULL, '2018-08-03', NULL, NULL, 'Perez Juan', 'Perez Juan', '', 0, 'General', NULL, NULL, '15615615', '424242', 'DNI', 1, '', NULL, NULL, '000003'),
(NULL, '1234', '1', '000004', NULL, NULL, NULL, 'ARS', NULL, '000001', 'TRANS', NULL, NULL, NULL, NULL, NULL, 0, 'acme@gmail.com', '', NULL, '2018-08-03', NULL, NULL, 'cliente1', 'cliente1', '', 0, 'General', NULL, NULL, '1234', '', 'CUIT', 1, 'http://localhost/facturascripts_2015-master/index.php?page=ventas_clientes', NULL, NULL, NULL),
(NULL, '201221231235', NULL, '000005', NULL, NULL, NULL, 'ARS', NULL, '000001', 'CONT', NULL, NULL, NULL, NULL, NULL, 0, 'ctomattis@acme.com', '', NULL, '2018-08-11', NULL, NULL, 'Carlos Tomattis', 'Carlos Tomattis', '', 0, 'General', NULL, NULL, '422222', '', 'CUIT', 1, '', NULL, NULL, NULL),
(NULL, '201221224', NULL, '000006', NULL, NULL, NULL, 'ARS', NULL, '000002', 'RAPIPAGO', NULL, NULL, NULL, NULL, NULL, 0, 'pgomez@acme.com', '', NULL, '2018-08-11', NULL, NULL, 'Gómez Pedro', 'Gómez Pedro', '', 0, 'General', NULL, NULL, '15615623', '424242', 'CUIT/CUIL', 1, '', NULL, NULL, NULL),
(NULL, '15575757', NULL, '000007', NULL, NULL, NULL, 'ARS', NULL, '000002', 'RAPIPAGO', NULL, NULL, NULL, NULL, NULL, 0, '', '', NULL, '2018-08-28', NULL, NULL, 'Mario Carrizo', 'Mario Carrizo', '', 0, 'General', NULL, NULL, '15575757', '', 'DNI', 1, '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente_propiedades`
--

CREATE TABLE `cliente_propiedades` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `text` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `cliente_propiedades`
--

INSERT INTO `cliente_propiedades` (`name`, `codcliente`, `text`) VALUES
('logkey', '000005', 'dT7EUtmA1gNp3aBP60JuyWwbLeRniv'),
('password', '000005', '7dd9b33881225c7ac41dce30c1447db47c41d4af');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_asientos`
--

CREATE TABLE `co_asientos` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codplanasiento` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `editable` tinyint(1) NOT NULL,
  `fecha` date NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_codbalances08`
--

CREATE TABLE `co_codbalances08` (
  `descripcion4ba` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `descripcion4` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel4` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion3` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orden3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `nivel3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel2` int(11) DEFAULT NULL,
  `descripcion1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel1` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `naturaleza` varchar(15) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_conceptospar`
--

CREATE TABLE `co_conceptospar` (
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idconceptopar` varchar(4) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_cuentas`
--

CREATE TABLE `co_cuentas` (
  `codbalance` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuenta` int(11) NOT NULL,
  `idcuentaesp` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_cuentascbba`
--

CREATE TABLE `co_cuentascbba` (
  `desccuenta` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_cuentasesp`
--

CREATE TABLE `co_cuentasesp` (
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuentaesp` varchar(6) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `co_cuentasesp`
--

INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
(NULL, NULL, 'Cuentas de acreedores', 'ACREED'),
(NULL, NULL, 'Cuentas de caja', 'CAJA'),
(NULL, NULL, 'Cuentas de diferencias negativas de cambio', 'CAMNEG'),
(NULL, NULL, 'Cuentas de diferencias positivas de cambio', 'CAMPOS'),
(NULL, NULL, 'Cuentas de clientes', 'CLIENT'),
(NULL, NULL, 'Cuentas de compras', 'COMPRA'),
(NULL, NULL, 'Devoluciones de compras', 'DEVCOM'),
(NULL, NULL, 'Devoluciones de ventas', 'DEVVEN'),
(NULL, NULL, 'Cuentas por diferencias positivas en divisa extranjera', 'DIVPOS'),
(NULL, NULL, 'Cuentas por diferencias negativas de conversión a la moneda local', 'EURNEG'),
(NULL, NULL, 'Cuentas por diferencias positivas de conversión a la moneda local', 'EURPOS'),
(NULL, NULL, 'Gastos por recargo financiero', 'GTORF'),
(NULL, NULL, 'Ingresos por recargo financiero', 'INGRF'),
(NULL, NULL, 'Cuentas de retenciones IRPF', 'IRPF'),
(NULL, NULL, 'Cuentas de retenciones para proveedores IRPFPR', 'IRPFPR'),
(NULL, NULL, 'Cuentas acreedoras de IVA en la regularización', 'IVAACR'),
(NULL, NULL, 'Cuentas deudoras de IVA en la regularización', 'IVADEU'),
(NULL, NULL, 'IVA en entregas intracomunitarias U.E.', 'IVAEUE'),
(NULL, NULL, 'Cuentas de IVA repercutido', 'IVAREP'),
(NULL, NULL, 'Cuentas de IVA repercutido para clientes exentos de IVA', 'IVAREX'),
(NULL, NULL, 'Cuentas de IVA soportado UE', 'IVARUE'),
(NULL, NULL, 'Cuentas de IVA repercutido en exportaciones', 'IVARXP'),
(NULL, NULL, 'Cuentas de IVA soportado en importaciones', 'IVASIM'),
(NULL, NULL, 'Cuentas de IVA soportado', 'IVASOP'),
(NULL, NULL, 'Cuentas de IVA soportado UE', 'IVASUE'),
(NULL, NULL, 'Cuentas relativas al ejercicio previo', 'PREVIO'),
(NULL, NULL, 'Cuentas de proveedores', 'PROVEE'),
(NULL, NULL, 'Pérdidas y ganancias', 'PYG'),
(NULL, NULL, 'Cuentas de ventas', 'VENTAS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_epigrafes`
--

CREATE TABLE `co_epigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL,
  `idgrupo` int(11) DEFAULT NULL,
  `idpadre` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_gruposepigrafes`
--

CREATE TABLE `co_gruposepigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idgrupo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_partidas`
--

CREATE TABLE `co_partidas` (
  `baseimponible` double NOT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `codcontrapartida` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `debe` double NOT NULL DEFAULT '0',
  `debeme` double NOT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `factura` double DEFAULT NULL,
  `haber` double NOT NULL DEFAULT '0',
  `haberme` double NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `idcontrapartida` int(11) DEFAULT NULL,
  `idpartida` int(11) NOT NULL,
  `idsubcuenta` int(11) NOT NULL,
  `iva` double NOT NULL,
  `punteada` tinyint(1) NOT NULL DEFAULT '0',
  `recargo` double NOT NULL,
  `tasaconv` double NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_regiva`
--

CREATE TABLE `co_regiva` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `fechaasiento` date NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idregiva` int(11) NOT NULL,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `periodo` varchar(8) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_secuencias`
--

CREATE TABLE `co_secuencias` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `idsecuencia` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_subcuentas`
--

CREATE TABLE `co_subcuentas` (
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `debe` double NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `haber` double NOT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) NOT NULL,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  `saldo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_subcuentascli`
--

CREATE TABLE `co_subcuentascli` (
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL,
  `idsubcuenta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `co_subcuentasprov`
--

CREATE TABLE `co_subcuentasprov` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL,
  `idsubcuenta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentasbanco`
--

CREATE TABLE `cuentasbanco` (
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentasbcocli`
--

CREATE TABLE `cuentasbcocli` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  `fmandato` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentasbcopro`
--

CREATE TABLE `cuentasbcopro` (
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `cuentasbcopro`
--

INSERT INTO `cuentasbcopro` (`agencia`, `codcuenta`, `codproveedor`, `ctaagencia`, `ctaentidad`, `cuenta`, `descripcion`, `entidad`, `iban`, `swift`, `principal`) VALUES
(NULL, '1', '000001', NULL, NULL, NULL, 'banco x', NULL, '', 'ksejfikmed', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dirclientes`
--

CREATE TABLE `dirclientes` (
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `domenvio` tinyint(1) DEFAULT NULL,
  `domfacturacion` tinyint(1) DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `dirclientes`
--

INSERT INTO `dirclientes` (`codcliente`, `codpais`, `apartado`, `idprovincia`, `provincia`, `ciudad`, `codpostal`, `direccion`, `domenvio`, `domfacturacion`, `descripcion`, `id`, `fecha`) VALUES
('000001', 'ARG', '', NULL, 'Victoria', 'Victoria', '', '', 1, 1, 'Principal', 1, '2018-07-01'),
('000002', 'ARG', '25', NULL, 'Entre Ríos', 'Victoria', '3153', 'Matanza', 1, 1, 'Principal', 2, '2018-08-01'),
('000003', 'ARG', '', NULL, 'Entre Ríos', 'Victoria', '3153', 'Basualdo y Bvard. Moreno', 1, 1, 'Principal', 3, '2018-08-03'),
('000004', 'ARG', '', NULL, 'Entre Ríos', 'Victoria', '3153', 'test', 1, 1, 'Principal', 4, '2018-08-03'),
('000005', 'ARG', '', NULL, 'Entre Ríos', 'Victoria', '3153', 'Basualdo 177', 1, 1, 'Principal', 5, '2018-08-11'),
('000006', 'ARG', '', NULL, 'Entre Ríos', 'Victoria', '', 'Chacabuco 138', 1, 1, 'Principal', 6, '2018-08-11'),
('000007', 'ARG', '', NULL, 'Entre Ríos', 'Victoria', '3153', 'Larrea 867', 1, 1, 'Principal', 7, '2018-08-28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dirproveedores`
--

CREATE TABLE `dirproveedores` (
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `direccionppal` tinyint(1) DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `dirproveedores`
--

INSERT INTO `dirproveedores` (`codproveedor`, `codpais`, `apartado`, `idprovincia`, `provincia`, `ciudad`, `codpostal`, `direccion`, `direccionppal`, `descripcion`, `id`, `fecha`) VALUES
('000001', 'ARG', '25', NULL, 'Entre Ríos', 'Victoria', '3153', 'Matanza', 1, 'Principal', 1, '2018-08-01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `divisas`
--

CREATE TABLE `divisas` (
  `bandera` text COLLATE utf8_bin,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codiso` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `simbolo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `tasaconv_compra` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `divisas`
--

INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
(NULL, 'ARS', '32', 'PESOS (ARG)', NULL, 'AR$', 35.026239, 35.026239);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ejercicios`
--

CREATE TABLE `ejercicios` (
  `idasientocierre` int(11) DEFAULT NULL,
  `idasientopyg` int(11) DEFAULT NULL,
  `idasientoapertura` int(11) DEFAULT NULL,
  `plancontable` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `longsubcuenta` int(11) DEFAULT NULL,
  `estado` varchar(15) COLLATE utf8_bin NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `ejercicios`
--

INSERT INTO `ejercicios` (`idasientocierre`, `idasientopyg`, `idasientoapertura`, `plancontable`, `longsubcuenta`, `estado`, `fechafin`, `fechainicio`, `nombre`, `codejercicio`) VALUES
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2013-12-31', '2013-01-01', '2013', '2013'),
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2014-12-31', '2014-01-01', '2014', '2014'),
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2015-12-31', '2015-01-01', '2015', '2015'),
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2016-12-31', '2016-01-01', '2016', '2016'),
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2017-12-31', '2017-01-01', '2017', '2017'),
(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2018-12-31', '2018-01-01', '2018', '2018');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `administrador` varchar(100) COLLATE utf8_bin NOT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `contintegrada` tinyint(1) DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `horario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `xid` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `lema` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `logo` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecorto` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `pie_factura` text COLLATE utf8_bin,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recequivalencia` tinyint(1) DEFAULT NULL,
  `stockpedidos` tinyint(1) DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `inicioact` date DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `altura` varchar(10) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`administrador`, `apartado`, `cifnif`, `ciudad`, `codalmacen`, `codcuentarem`, `coddivisa`, `codedi`, `codejercicio`, `codpago`, `codpais`, `codpostal`, `codserie`, `contintegrada`, `direccion`, `email`, `fax`, `horario`, `id`, `idprovincia`, `xid`, `lema`, `logo`, `nombre`, `nombrecorto`, `pie_factura`, `provincia`, `recequivalencia`, `stockpedidos`, `telefono`, `web`, `inicioact`, `regimeniva`, `altura`) VALUES
('Sobrero Juan Jorge', '222', 'CUIT: 30-54050846-8', 'Victoria', 'ALG', NULL, 'ARS', NULL, '2018', 'CONT', 'ARG', '3153', 'A', 1, 'Avenida Congreso de 1816', 'test@test.com', '03436 - 422057', '8 a 18 Horas', 1, NULL, 'fiS6Z4myghnCTxbUA1jqt5VHFLROMe', 'Sigamos  contruyendo entre todxs', NULL, 'INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY', 'Instituto JFKennedy', 'Gracias por estar al día', 'Entre Ríos', 0, 0, '03436 - 422057', 'https://www.institutojfk.com.ar', '1970-01-01', NULL, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fabricantes`
--

CREATE TABLE `fabricantes` (
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fabricantes`
--

INSERT INTO `fabricantes` (`nombre`, `codfabricante`) VALUES
('OEM', 'OEM');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturascli`
--

CREATE TABLE `facturascli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `vencimiento` date DEFAULT NULL,
  `femail` date DEFAULT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `netosindto` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombrecliente` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double DEFAULT NULL,
  `tpv` tinyint(1) DEFAULT NULL,
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `apartadoenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpaisenv` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idimprenta` int(11) DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0',
  `dtopor1` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `dtopor5` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `facturascli`
--

INSERT INTO `facturascli` (`apartado`, `automatica`, `cifnif`, `ciudad`, `codagente`, `codalmacen`, `codcliente`, `coddir`, `coddivisa`, `codejercicio`, `codigo`, `codigorect`, `codpago`, `codpais`, `codpostal`, `codserie`, `deabono`, `direccion`, `editable`, `fecha`, `vencimiento`, `femail`, `hora`, `idasiento`, `idasientop`, `idfactura`, `idfacturarect`, `idpagodevol`, `idprovincia`, `irpf`, `netosindto`, `neto`, `nogenerarasiento`, `nombrecliente`, `numero`, `numero2`, `observaciones`, `pagada`, `anulada`, `porcomision`, `provincia`, `recfinanciero`, `tasaconv`, `total`, `totaleuros`, `totalirpf`, `totaliva`, `totalrecargo`, `tpv`, `codtrans`, `codigoenv`, `nombreenv`, `apellidosenv`, `direccionenv`, `codpostalenv`, `ciudadenv`, `provinciaenv`, `apartadoenv`, `codpaisenv`, `idimprenta`, `numdocs`, `dtopor1`, `dtopor2`, `dtopor3`, `dtopor4`, `dtopor5`) VALUES
('', NULL, '22222222', 'Victoria', '1', 'ALG', '000001', 1, 'ARS', '2018', 'FAC2018A1', NULL, 'CONT', 'ARG', '', 'A', 0, '', 0, '2018-07-01', '2018-07-01', NULL, '20:29:01', NULL, NULL, 1, NULL, NULL, NULL, 0, 138.36, 138.36, NULL, 'tito', '1', '', 'factura corespondiente a mes agosto-2018', 1, 0, 0, 'Victoria', NULL, 16.684, 167.41, 10.03416, 0, 29.05, 0, NULL, NULL, '', '', '', '', '', '', '', '', 'ARG', NULL, 0, 0, 0, 0, 0, 0),
('', NULL, '20222123', 'Victoria', '2', 'ALG', '000003', 3, 'ARS', '2018', 'FAC2018A2', NULL, 'TRANS', 'ARG', '3153', 'A', 0, 'Basualdo y Bvard. Moreno', 0, '2018-08-03', '2018-09-03', NULL, '16:55:06', NULL, NULL, 2, NULL, NULL, NULL, 0, 120, 120, NULL, 'Perez Juan', '2', '', '', 0, 0, 0, 'Entre Ríos', NULL, 16.684, 120, 7.19252, 0, 0, 0, NULL, NULL, '', '', '', '', '', '', '', '', 'ARG', NULL, 0, 0, 0, 0, 0, 0),
('', NULL, '20222123', 'Victoria', '2', 'ALG', '000003', 3, 'ARS', '2018', 'FAC2018B1', NULL, 'RAPIPAGO', 'ARG', '3153', 'B', 0, 'Basualdo y Bvard. Moreno', 0, '2018-08-11', '2018-08-18', NULL, '13:07:35', NULL, NULL, 3, NULL, NULL, NULL, 0, 0, 0, NULL, 'Perez Juan', '1', '', '', 0, 0, 0, 'Entre Ríos', NULL, 16.684, 0, 0, 0, 0, 0, NULL, NULL, '', '', '', '', '', '', '', '', 'ARG', NULL, 0, 0, 0, 0, 0, 0),
('', NULL, '1234', 'Victoria', '5', 'ALG', '000004', 4, 'ARS', '2018', 'FAC2018A3', NULL, 'RAPIPAGO', 'ARG', '3153', 'A', 0, 'test', 0, '2018-08-28', '2018-09-04', NULL, '01:53:38', NULL, NULL, 4, NULL, NULL, NULL, 0, 300, 300, NULL, 'cliente1', '3', '', '', 0, 0, 0, 'Entre Ríos', NULL, 35.026239, 381, 10.87756, 0, 81, 0, NULL, NULL, '', '', '', '', '', '', '', '', 'ARG', NULL, 0, 0, 0, 0, 0, 0),
('', NULL, '15575757', 'Victoria', '5', 'ALG', '000007', 7, 'ARS', '2018', 'FAC2018A4', NULL, 'RAPIPAGO', 'ARG', '3153', 'A', 0, 'Larrea 867', 0, '2018-08-28', '2018-09-04', NULL, '01:59:06', NULL, NULL, 5, NULL, NULL, NULL, 0, 500, 500, NULL, 'Mario Carrizo', '4', '', '', 1, 0, 0, 'Entre Ríos', NULL, 35.026239, 605, 17.27277, 0, 105, 0, NULL, NULL, '', '', '', '', '', '', '', '', 'ARG', NULL, 0, 0, 0, 0, 0, 0),
(NULL, NULL, '61856968J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'FAC2018A5', NULL, 'TRANS', NULL, '', 'A', 0, '', 0, '2018-09-20', '2018-10-20', NULL, '18:20:53', NULL, NULL, 6, NULL, NULL, NULL, 0, 44287.85, 44287.85, NULL, 'Joel Botella Stark', '5', '', '', 0, 0, 0, '', NULL, 35.026239, 51031.23, 1456.94289, 0, 6743.38, 0, NULL, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, NULL, '708760820J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'FAC2018A6', NULL, 'TRANS', NULL, '', 'A', 0, '', 0, '2018-10-03', '2018-11-03', NULL, '18:38:40', NULL, NULL, 7, NULL, NULL, NULL, 0, 18557.61, 18557.61, NULL, 'Carlos García Pacheco', '6', '', '', 0, 0, 0, '', NULL, 35.026239, 19814.71, 565.71047, 0, 1257.1, 0, NULL, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, NULL, 0, 0, 0, 0, 0, 0),
(NULL, NULL, '426083867J', '', '2', 'ALG', NULL, NULL, 'ARS', '2018', 'FAC2018A7', NULL, 'TRANS', NULL, '', 'A', 0, '', 0, '2018-10-03', '2018-11-03', NULL, '21:41:16', NULL, NULL, 8, NULL, NULL, NULL, 0, 26202.11, 26202.11, NULL, 'Joe Trump Obama', '7', '', '', 0, 0, 0, '', NULL, 35.026239, 24944.74, 712.17295, 0, -1257.37, 0, NULL, NULL, NULL, '', '', '', NULL, '', '', NULL, NULL, NULL, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturasprov`
--

CREATE TABLE `facturasprov` (
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `neto` double DEFAULT NULL,
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `total` double DEFAULT NULL,
  `totaleuros` double DEFAULT NULL,
  `totalirpf` double DEFAULT NULL,
  `totaliva` double DEFAULT NULL,
  `totalrecargo` double DEFAULT NULL,
  `numdocs` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `facturasprov`
--

INSERT INTO `facturasprov` (`automatica`, `cifnif`, `codagente`, `codalmacen`, `coddivisa`, `codejercicio`, `codigo`, `codigorect`, `codpago`, `codproveedor`, `codserie`, `deabono`, `editable`, `fecha`, `hora`, `idasiento`, `idasientop`, `idfactura`, `idfacturarect`, `idpagodevol`, `irpf`, `neto`, `nogenerarasiento`, `nombre`, `numero`, `numproveedor`, `observaciones`, `pagada`, `anulada`, `recfinanciero`, `tasaconv`, `total`, `totaleuros`, `totalirpf`, `totaliva`, `totalrecargo`, `numdocs`) VALUES
(NULL, '302221231', '2', 'ALG', 'ARS', '2018', 'FAC2018A1C', NULL, 'RAPIPAGO', '000001', 'A', 0, 0, '2018-08-22', '19:26:52', NULL, NULL, 1, NULL, NULL, 0, 450, NULL, 'Escuela JFK', '1', '1557', '', 0, 0, NULL, 33.255547, 571.5, 17.1851, 0, 121.5, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familias`
--

CREATE TABLE `familias` (
  `descripcion` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfamilia` varchar(8) COLLATE utf8_bin NOT NULL,
  `madre` varchar(8) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `familias`
--

INSERT INTO `familias` (`descripcion`, `codfamilia`, `madre`) VALUES
('Estudiantes de pre-escolar', '001', NULL),
('Estudiantes Primaria', '002', NULL),
('Estudiantes Secundaria', '003', NULL),
('Estudiantes', '004', NULL),
('Preescolar cuatro años', '010', '001'),
('Preescolar cinco años', '011', '001'),
('VARIOS', 'VARI', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formaspago`
--

CREATE TABLE `formaspago` (
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `genrecibos` varchar(10) COLLATE utf8_bin NOT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `domiciliado` tinyint(1) DEFAULT NULL,
  `imprimir` tinyint(1) DEFAULT '1',
  `vencimiento` varchar(20) COLLATE utf8_bin DEFAULT '+1month'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `formaspago`
--

INSERT INTO `formaspago` (`codpago`, `descripcion`, `genrecibos`, `codcuenta`, `domiciliado`, `imprimir`, `vencimiento`) VALUES
('CONT', 'Al contado', 'Pagados', NULL, 0, 1, '+0day'),
('RAPIPAGO', 'Rapipago', 'Emitidos', NULL, 0, 1, '+1week'),
('TARJETA', 'Tarjeta de crédito', 'Pagados', NULL, 0, 1, '+0day'),
('TRANS', 'Transferencia bancaria', 'Emitidos', NULL, 0, 1, '+1month');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_access`
--

CREATE TABLE `fs_access` (
  `fs_user` varchar(12) COLLATE utf8_bin NOT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin NOT NULL,
  `allow_delete` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_access`
--

INSERT INTO `fs_access` (`fs_user`, `fs_page`, `allow_delete`) VALUES
('cliente1', 'nueva_compra', 0),
('secretaria', 'nueva_venta', 1),
('secretaria', 'ventas_articulo', 1),
('secretaria', 'ventas_articulos', 1),
('secretaria', 'ventas_cliente', 1),
('secretaria', 'ventas_cliente_articulos', 1),
('secretaria', 'ventas_clientes', 1),
('secretaria', 'ventas_factura', 1),
('secretaria', 'ventas_facturas', 1),
('secretaria', 'ventas_familia', 1),
('secretaria', 'ventas_familias', 1),
('secretaria', 'ventas_grupo', 1),
('secretaria', 'ventas_imprimir', 1),
('secretaria', 'ventas_trazabilidad', 1),
('tito-emplead', 'nueva_venta', 1),
('tito-emplead', 'ventas_clientes', 1),
('tito-emplead', 'ventas_clientes_opciones', 1),
('tito-emplead', 'ventas_factura', 1),
('tito-emplead', 'ventas_factura_devolucion', 1),
('tito-emplead', 'ventas_facturas', 1),
('usuario1', 'ventas_agrupar_albaranes', 1),
('usuario1', 'ventas_albaran', 1),
('usuario1', 'ventas_albaranes', 1),
('usuario1', 'ventas_articulo', 1),
('usuario1', 'ventas_articulos', 1),
('usuario1', 'ventas_atributos', 1),
('usuario1', 'ventas_cliente', 1),
('usuario1', 'ventas_cliente_articulos', 1),
('usuario1', 'ventas_clientes', 1),
('usuario1', 'ventas_clientes_opciones', 1),
('usuario1', 'ventas_factura', 1),
('usuario1', 'ventas_factura_devolucion', 1),
('usuario1', 'ventas_facturas', 1),
('usuario1', 'ventas_familia', 1),
('usuario1', 'ventas_familias', 1),
('usuario1', 'ventas_grupo', 1),
('usuario1', 'ventas_trazabilidad', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_extensions2`
--

CREATE TABLE `fs_extensions2` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `page_from` varchar(30) COLLATE utf8_bin NOT NULL,
  `page_to` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `text` text COLLATE utf8_bin,
  `params` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_extensions2`
--

INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
('agrupar_albaranes', 'compras_agrupar_albaranes', 'compras_albaranes', 'button', '<span class="glyphicon glyphicon-duplicate"></span><span class="hidden-xs">&nbsp; Agrupar</span>', ''),
('agrupar_albaranes', 'ventas_agrupar_albaranes', 'ventas_albaranes', 'button', '<span class="glyphicon glyphicon-duplicate"></span><span class="hidden-xs">&nbsp; Agrupar</span>', ''),
('albaran_detallado_es_AR', 'albaran_detallado', 'ventas_albaran', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Remito detallado es_AR', '&codidioma=es_AR'),
('albaran_detallado_es_ES', 'albaran_detallado', 'ventas_albaran', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Remito detallado es_ES', '&codidioma=es_ES'),
('albaranes_agente', 'compras_albaranes', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Remitos de proveedor', ''),
('albaranes_agente', 'ventas_albaranes', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Recibos de cliente', ''),
('albaranes_articulo', 'compras_albaranes', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Remitos de proveedor', ''),
('albaranes_articulo', 'ventas_albaranes', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Recibos de cliente', ''),
('albaranes_cliente', 'ventas_albaranes', 'ventas_cliente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Recibos', ''),
('albaranes_proveedor', 'compras_albaranes', 'compras_proveedor', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Remitos', ''),
('api_remote_printer', 'tpv_recambios', NULL, 'api', 'remote_printer', NULL),
('articulo_subcuentas', 'articulo_subcuentas', 'ventas_articulo', 'tab', '<span class="glyphicon glyphicon-book" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Subcuentas</span>', NULL),
('btn_albaran', 'compras_actualiza_arts', 'compras_albaran', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Actualizar</span>', '&doc=albaran'),
('btn_atributos', 'ventas_atributos', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Atributos</span>', NULL),
('btn_balances', 'editar_balances', 'informe_contabilidad', 'button', '<span class="glyphicon glyphicon-wrench"></span><span class="hidden-xs">&nbsp; Balances</a>', NULL),
('btn_fabricantes', 'ventas_fabricantes', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span><span class="hidden-xs"> &nbsp; Fabricantes</span>', NULL),
('btn_familias', 'ventas_familias', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span><span class="hidden-xs"> &nbsp; Familias</span>', NULL),
('btn_pedido', 'compras_actualiza_arts', 'compras_pedido', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Actualizar</span>', '&doc=pedido'),
('cosmo', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-cosmo.min.css', ''),
('darkly', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-darkly.min.css', ''),
('email_albaran', 'ventas_imprimir', 'ventas_albaran', 'email', 'Remito simple', '&albaran=TRUE'),
('email_albaran_proveedor', 'compras_imprimir', 'compras_albaran', 'email', 'Remito simple', '&albaran=TRUE'),
('email_factura', 'ventas_imprimir', 'ventas_factura', 'email', 'Factura simple', '&factura=TRUE&tipo=simple'),
('enviar_factura_detallada_es_AR', 'factura_detallada', 'ventas_factura', 'email', 'Factura detallada es_AR', '&codidioma=es_AR'),
('enviar_factura_detallada_es_ES', 'factura_detallada', 'ventas_factura', 'email', 'Factura detallada es_ES', '&codidioma=es_ES'),
('factura_detallada_es_AR', 'factura_detallada', 'ventas_factura', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Factura detallada es_AR', '&codidioma=es_AR'),
('factura_detallada_es_ES', 'factura_detallada', 'ventas_factura', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Factura detallada es_ES', '&codidioma=es_ES'),
('facturas_agente', 'compras_facturas', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de proveedor', ''),
('facturas_agente', 'ventas_facturas', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de cliente', ''),
('facturas_articulo', 'compras_facturas', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de proveedor', ''),
('facturas_articulo', 'ventas_facturas', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de cliente', ''),
('facturas_cliente', 'ventas_facturas', 'ventas_cliente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas', ''),
('facturas_proveedor', 'compras_facturas', 'compras_proveedor', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas', ''),
('flatly', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-flatly.min.css', ''),
('imprimir_albaran', 'ventas_imprimir', 'ventas_albaran', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Remito simple', '&albaran=TRUE'),
('imprimir_albaran_noval', 'ventas_imprimir', 'ventas_albaran', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Remito sin valorar', '&albaran=TRUE&noval=TRUE'),
('imprimir_albaran_proveedor', 'compras_imprimir', 'compras_albaran', 'pdf', 'Remito simple', '&albaran=TRUE'),
('imprimir_factura', 'ventas_imprimir', 'ventas_factura', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Factura simple', '&factura=TRUE&tipo=simple'),
('imprimir_factura_carta', 'ventas_imprimir', 'ventas_factura', 'pdf', '<span class="glyphicon glyphicon-print"></span>&nbsp; Modelo carta', '&factura=TRUE&tipo=carta'),
('imprimir_factura_proveedor', 'compras_imprimir', 'compras_factura', 'pdf', 'Factura simple', '&factura=TRUE'),
('lumen', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-lumen.min.css', ''),
('maquetar_albaran', 'ventas_maquetar', 'ventas_albaran', 'pdf', '<i class="fa fa-magic"></i>&nbsp; Maquetar', '&albaran=TRUE'),
('maquetar_factura', 'ventas_maquetar', 'ventas_factura', 'pdf', '<i class="fa fa-magic"></i>&nbsp; Maquetar', '&factura=TRUE'),
('megafacturar_albcli', 'megafacturador', 'ventas_albaranes', 'button', '<i class="fa fa-check-square-o" aria-hidden="true"></i><span class="hidden-xs">&nbsp; megafacturador</span>', NULL),
('megafacturar_albpro', 'megafacturador', 'compras_albaranes', 'button', '<i class="fa fa-check-square-o" aria-hidden="true"></i><span class="hidden-xs">&nbsp; megafacturador</span>', NULL),
('opciones_clientes', 'ventas_clientes_opciones', 'ventas_clientes', 'button', '<span class="glyphicon glyphicon-wrench" aria-hidden="true" title="Opciones para nuevos clientes"></span><span class="hidden-xs">&nbsp; Opciones</span>', NULL),
('opciones_clientes', 'ventas_tutores_opciones', 'ventas_tutores', 'button', '<span class="glyphicon glyphicon-wrench" aria-hidden="true" title="Opciones para nuevos tutores"></span><span class="hidden-xs">&nbsp; Opciones</span>', NULL),
('opciones_fac_detallada', 'opciones_factura_detallada', 'admin_empresa', 'button', '<span class="glyphicon glyphicon-print" aria-hidden="true"></span> &nbsp; Factura Detallada', NULL),
('paper', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-paper.min.css', ''),
('sandstone', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-sandstone.min.css', ''),
('simplex', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-simplex.min.css', ''),
('spacelab', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-spacelab.min.css', ''),
('tab_devoluciones', 'compras_factura_devolucion', 'compras_factura', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Devoluciones</span>', NULL),
('tab_devoluciones', 'ventas_factura_devolucion', 'ventas_factura', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Devoluciones</span>', NULL),
('tab_editar_factura', 'compras_factura_devolucion', 'editar_factura_prov', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Devoluciones</span>', NULL),
('tab_editar_factura', 'ventas_factura_devolucion', 'editar_factura', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Devoluciones</span>', NULL),
('tab_ventas_cliente_articulos', 'ventas_cliente_articulos', 'ventas_cliente', 'tab', '<i class="fa fa-cubes" aria-hidden="true"></i>&nbsp; Artículos', NULL),
('tab_ventas_trazabilidad_alb', 'ventas_trazabilidad', 'ventas_albaran', 'tab', '<i class="fa fa-code-fork" aria-hidden="true"></i><span class="hidden-xs">&nbsp;Trazabilidad</span>', '&doc=albaran&tab=TRUE'),
('tab_ventas_trazabilidad_fac', 'ventas_trazabilidad', 'ventas_factura', 'tab', '<i class="fa fa-code-fork" aria-hidden="true"></i><span class="hidden-xs">&nbsp;Trazabilidad</span>', '&doc=factura&tab=TRUE'),
('united', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-united.min.css', ''),
('yeti', 'admin_user', 'admin_user', 'css', 'view/css/bootstrap-yeti.min.css', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_logs`
--

CREATE TABLE `fs_logs` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `detalle` text COLLATE utf8_bin NOT NULL,
  `fecha` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `alerta` tinyint(1) DEFAULT NULL,
  `controlador` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_logs`
--

INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`, `controlador`) VALUES
(382, 'msg', 'Historial borrado correctamente.', '2018-10-03 21:18:08', 'admin', '::1', 0, 'admin_info'),
(383, 'error', '¡Remito de cliente no encontrada!', '2018-11-11 20:24:27', 'admin', '::1', 0, 'albaran_detallado'),
(384, 'error', '¡Factura de cliente no encontrada!', '2018-11-11 20:25:32', 'admin', '::1', 0, 'factura_detallada'),
(385, 'login', 'Login correcto.', '2018-11-26 21:11:57', 'admin', '::1', 0, 'admin_home'),
(386, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 8', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(387, 'error', 'Error al convertir la tabla a InnoDB.', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(388, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(389, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 11', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(390, 'error', 'Error al comprobar la tabla stocks', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(391, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 20', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(392, 'error', 'Error al convertir la tabla a InnoDB.', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(393, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(394, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 23', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(395, 'error', 'Error al comprobar la tabla stocks', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(396, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(397, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:06', 'admin', '::1', 0, 'ventas_articulo'),
(398, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 8', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(399, 'error', 'Error al convertir la tabla a InnoDB.', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(400, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(401, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 11', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(402, 'error', 'Error al comprobar la tabla stocks', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(403, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 17', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(404, 'error', 'Error al convertir la tabla a InnoDB.', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(405, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(406, 'error', 'Error al ejecutar la consulta 0: Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;. La secuencia ocupa la posición 20', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(407, 'error', 'Error al comprobar la tabla stocks', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(408, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(409, 'error', 'Incorrect information in file: &#39;.\\facturas1\\stocks.frm&#39;', '2018-11-26 21:14:42', 'admin', '::1', 0, 'ventas_articulo'),
(410, 'login', 'El usuario ha cerrado la sesión.', '2018-11-26 22:29:40', NULL, '::1', 0, 'ventas_alumnos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_pages`
--

CREATE TABLE `fs_pages` (
  `name` varchar(30) COLLATE utf8_bin NOT NULL,
  `title` varchar(40) COLLATE utf8_bin NOT NULL,
  `folder` varchar(15) COLLATE utf8_bin NOT NULL,
  `version` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `show_on_menu` tinyint(1) NOT NULL DEFAULT '1',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  `orden` int(11) NOT NULL DEFAULT '100'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_pages`
--

INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`, `orden`) VALUES
('admin_agente', 'Empleado', 'admin', '2017.031', 0, 0, 100),
('admin_agentes', 'Empleados', 'admin', '2017.031', 1, 0, 100),
('admin_almacenes', 'Almacenes', 'admin', '2017.031', 1, 0, 100),
('admin_argentina', 'Argentina', 'admin', '2017.904', 1, 0, 100),
('admin_divisas', 'Divisas', 'admin', '2017.903', 1, 0, 100),
('admin_empresa', 'Empresa', 'admin', '2017.031', 1, 0, 100),
('admin_home', 'Panel de control', 'admin', NULL, 1, 0, 100),
('admin_info', 'Información del sistema', 'admin', '2017.031', 1, 0, 100),
('admin_orden_menu', 'Ordenar menú', 'admin', '2017.031', 1, 0, 100),
('admin_paises', 'Paises', 'admin', '2017.903', 1, 0, 100),
('admin_rol', 'Editar rol', 'admin', '2017.031', 0, 0, 100),
('admin_transportes', 'Agencias de transporte', 'admin', '2017.904', 1, 0, 100),
('admin_user', 'Usuario', 'admin', '2017.031', 0, 0, 100),
('admin_users', 'Usuarios', 'admin', '2017.031', 1, 0, 100),
('albaran_detallado', 'Remito Detallado', 'ventas', '2017.904', 0, 0, 100),
('articulo_subcuentas', 'Subcuentas', 'ventas', '2017.031', 0, 0, 100),
('articulo_trazabilidad', '', 'ventas', '2017.903', 0, 0, 100),
('backup_restore', 'Copias de seguridad', 'admin', '2017.904', 1, 0, 100),
('base_wizard', 'Asistente de instalación', 'admin', '2017.903', 0, 0, 100),
('compras_actualiza_arts', 'Artículos documento', 'compras', '2017.903', 0, 0, 100),
('compras_agrupar_albaranes', 'Agrupar remitos', 'compras', '2017.903', 0, 0, 100),
('compras_albaran', 'remito de proveedor', 'compras', '2017.903', 0, 0, 100),
('compras_albaranes', 'Remitos', 'compras', '2017.903', 1, 0, 100),
('compras_factura', 'Factura de proveedor', 'compras', '2017.903', 0, 0, 100),
('compras_factura_devolucion', 'Devoluciones de factura de compra', 'compras', '2017.903', 0, 0, 100),
('compras_facturas', 'Facturas', 'compras', '2017.031', 1, 0, 100),
('compras_imprimir', 'imprimir', 'compras', '2017.031', 0, 0, 100),
('compras_proveedor', 'Proveedor', 'compras', '2017.031', 0, 0, 100),
('compras_proveedores', 'Proveedores / Acreedores', 'compras', '2017.031', 1, 0, 100),
('compras_trazabilidad', 'Trazabilidad', 'compras', '2017.903', 0, 0, 100),
('contabilidad_asiento', 'Asiento', 'contabilidad', '2017.903', 0, 0, 100),
('contabilidad_asientos', 'Asientos', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_cuenta', 'Cuenta', 'contabilidad', '2017.903', 0, 0, 100),
('contabilidad_cuentas', 'Cuentas', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_ejercicio', 'Ejercicio', 'contabilidad', '2017.031', 0, 0, 100),
('contabilidad_ejercicios', 'Ejercicios', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_epigrafes', 'Grupos y epígrafes', 'contabilidad', '2017.903', 1, 0, 100),
('contabilidad_formas_pago', 'Formas de Pago', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_impuestos', 'Impuestos', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_nuevo_asiento', 'Nuevo asiento', 'contabilidad', '2017.903', 0, 1, 100),
('contabilidad_series', 'Series', 'contabilidad', '2017.031', 1, 0, 100),
('contabilidad_subcuenta', 'Subcuenta', 'contabilidad', '2017.903', 0, 0, 100),
('cuentas_especiales', 'Cuentas Especiales', 'contabilidad', '2017.903', 0, 0, 100),
('dashboard', 'Dashboard', 'informes', '2017.031', 1, 1, 100),
('editar_balances', 'Editar balances', 'informes', '2017.903', 0, 0, 100),
('editar_transferencia_stock', 'Editar transferencia', 'ventas', '2017.903', 0, 0, 100),
('factura_detallada', 'Factura Detallada', 'ventas', '2017.904', 0, 0, 100),
('fsdk_home', 'FSDK', 'admin', '2017.905', 1, 0, 100),
('fsdk_plan_contable', 'Plan contable', 'admin', '2017.905', 0, 0, 100),
('fsdk_tabla', 'Tabla', 'admin', '2017.905', 0, 0, 100),
('informe_albaranes', 'Remitos', 'informes', '2017.031', 1, 0, 100),
('informe_articulos', 'Artículos', 'informes', '2017.031', 1, 0, 100),
('informe_contabilidad', 'Contabilidad', 'informes', '2017.031', 1, 0, 100),
('informe_errores', 'Errores', 'informes', '2017.031', 1, 0, 100),
('informe_facturas', 'Facturas', 'informes', '2017.031', 1, 0, 100),
('megafacturador', 'MegaFacturador', 'ventas', '2017.905', 1, 1, 100),
('nueva_compra', 'Nueva compra...', 'compras', '2017.031', 0, 1, 100),
('nueva_venta', 'Nueva venta...', 'ventas', '2017.031', 0, 1, 100),
('opciones_factura_detallada', 'Factura Detallada', 'admin', '2017.904', 0, 0, 100),
('subcuenta_asociada', 'Asignar subcuenta...', 'contabilidad', '2017.031', 0, 0, 100),
('tpv_caja', 'Arqueos y terminales', 'TPV', '2017.903', 1, 0, 100),
('tpv_recambios', 'TPV Genérico', 'TPV', '2017.903', 1, 0, 100),
('ventas_agrupar_albaranes', 'Agrupar recibos', 'ventas', '2017.903', 0, 0, 100),
('ventas_albaran', 'recibo de cliente', 'ventas', '2017.903', 0, 0, 100),
('ventas_albaranes', 'Recibos', 'ventas', '2017.903', 1, 0, 100),
('ventas_alumno', 'alumno', 'ventas', '2017.905', 0, 0, 100),
('ventas_alumnos', 'Alumnos', 'ventas', '2017.905', 1, 0, 100),
('ventas_articulo', 'Articulo', 'ventas', '2017.031', 0, 0, 100),
('ventas_articulos', 'Artículos', 'ventas', '2017.031', 1, 0, 100),
('ventas_atributos', 'Atributos de artículos', 'ventas', '2017.031', 0, 0, 100),
('ventas_cliente', 'Cliente', 'ventas', '2017.031', 0, 0, 100),
('ventas_cliente_articulos', 'Articulos vendidos al cliente', 'ventas', '2017.031', 0, 0, 100),
('ventas_clientes', 'Clientes', 'ventas', '2017.031', 1, 0, 100),
('ventas_clientes_opciones', 'Opciones', 'clientes', '2017.031', 0, 0, 100),
('ventas_fabricante', 'Familia', 'ventas', '2017.904', 0, 0, 100),
('ventas_fabricantes', 'Fabricantes', 'ventas', '2017.904', 0, 0, 100),
('ventas_factura', 'Factura de cliente', 'ventas', '2017.031', 0, 0, 100),
('ventas_factura_devolucion', 'Devoluciones de factura de venta', 'ventas', '2017.031', 0, 0, 100),
('ventas_facturas', 'Facturas', 'ventas', '2017.031', 1, 0, 100),
('ventas_familia', 'Familia', 'ventas', '2017.031', 0, 0, 100),
('ventas_familias', 'Familias', 'ventas', '2017.031', 0, 0, 100),
('ventas_grupo', 'Grupo', 'ventas', '2017.031', 0, 0, 100),
('ventas_imprimir', 'imprimir', 'ventas', '2017.031', 0, 0, 100),
('ventas_maquetar', 'Maquetar', 'ventas', '2017.903', 0, 0, 100),
('ventas_trazabilidad', 'Trazabilidad', 'ventas', '2017.031', 0, 0, 100),
('ventas_tutores', 'Tutores', 'ventas', '2017.905', 1, 0, 100),
('ventas_tutores_opciones', 'Opciones', 'tutores', '2017.905', 0, 0, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_roles`
--

CREATE TABLE `fs_roles` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_roles`
--

INSERT INTO `fs_roles` (`codrol`, `descripcion`) VALUES
('001', 'usuario con permisos para afcturar'),
('secretaria', 'secretaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_roles_access`
--

CREATE TABLE `fs_roles_access` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin NOT NULL,
  `allow_delete` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_roles_access`
--

INSERT INTO `fs_roles_access` (`codrol`, `fs_page`, `allow_delete`) VALUES
('001', 'ventas_facturas', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_roles_users`
--

CREATE TABLE `fs_roles_users` (
  `codrol` varchar(20) COLLATE utf8_bin NOT NULL,
  `fs_user` varchar(12) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_roles_users`
--

INSERT INTO `fs_roles_users` (`codrol`, `fs_user`) VALUES
('001', 'cliente1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_users`
--

CREATE TABLE `fs_users` (
  `nick` varchar(12) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL,
  `log_key` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `last_login_time` time DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `last_browser` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `css` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_users`
--

INSERT INTO `fs_users` (`nick`, `password`, `log_key`, `admin`, `enabled`, `codagente`, `last_login`, `last_login_time`, `last_ip`, `last_browser`, `fs_page`, `css`, `email`) VALUES
('admin', '229101b8f872656c7c9b24421bdd46f2a167046a', '034616ebae099639aa038acfc276d68259c391f1', 1, 1, '2', '2018-11-26', '19:29:07', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36', NULL, 'view/css/bootstrap-cosmo.min.css', 'cburgosster@gmail.com'),
('cliente1', 'd94019fd760a71edf11844bb5c601a4de95aacaf', NULL, 0, 1, '3', NULL, NULL, NULL, '', NULL, 'view/css/bootstrap-simplex.min.css', 'acme@gmail.com'),
('secretaria', '31f686a25c1299a305dd34d1d56e121db8bca302', '469127d44327161d459a6b88d5d279a18152cb27', 0, 1, '5', '2018-08-30', '02:11:36', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 'ventas_articulos', 'view/css/bootstrap-yeti.min.css', ''),
('tito', 'f5276fb0b29741f04c2acaa55e40da5b45c2dacf', '88547be1130859cf095ec35f890a1a53eafa9ac2', 1, 1, NULL, '2018-08-04', '15:31:08', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36', 'ventas_facturas', 'view/css/bootstrap-spacelab.min.css', 'cburgosster@gmail.com'),
('tito-emplead', '293abb6b76d7791c0732cc517d38c4b5c734b87f', 'ebed9c8f2abc8e5c320859c5fcb528734599d269', 0, 1, '3', '2018-07-11', '18:26:39', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36', 'ventas_clientes', 'view/css/bootstrap-yeti.min.css', 'cburgosster@gmail.com'),
('usuario1', 'b665e217b51994789b02b1838e730d6b93baa30f', '2c995d097a80369df69e7a06ed84710d9bae0ffa', 0, 1, '4', '2018-08-14', '16:49:07', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 'ventas_albaranes', 'view/css/bootstrap-yeti.min.css', 'cburgosster@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fs_vars`
--

CREATE TABLE `fs_vars` (
  `name` varchar(35) COLLATE utf8_bin NOT NULL,
  `varchar` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fs_vars`
--

INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
('backup_comando', 'C:\\\\xampp\\mysql\\bin\\mysqldump'),
('f_detallada_agrupa_albaranes', '1'),
('f_detallada_color', 'blanco'),
('f_detallada_color_b', '0'),
('f_detallada_color_g', '0'),
('f_detallada_color_r', '192'),
('f_detallada_maquetar_negrita', '1'),
('f_detallada_print_may_min', '1'),
('google_divisas_cron', '1'),
('install_step', '5'),
('mail_albaran', 'Buenos días, le adjunto su #DOCUMENTO#.\r\n#FIRMA#'),
('mail_bcc', 'Si'),
('mail_enc', 'ssl'),
('mail_factura', 'Buenos días, le adjunto su #DOCUMENTO#.\r\n#FIRMA#'),
('mail_firma', '---\r\nEnviado con Sistema Facturas-Coopevic Ltda'),
('mail_host', 'smtp.gmail.com'),
('mail_low_security', '1'),
('mail_mailer', 'smtp'),
('mail_password', 'ayNgXrlfN3HJZ9PUXa'),
('mail_pedido', 'Buenos días, le adjunto su #DOCUMENTO#.\n#FIRMA#'),
('mail_port', '465'),
('mail_presupuesto', 'Buenos días, le adjunto su #DOCUMENTO#.\n#FIRMA#'),
('mail_user', 'cburgosster@gmail.com'),
('megafac_agrupar', '1'),
('megafac_codserie', ''),
('megafac_compras', '0'),
('megafac_email', '1'),
('megafac_fecha', 'hoy'),
('megafac_hasta', '2018-09-20'),
('megafac_ventas', '1'),
('nuevocli_cifnif_req', '1'),
('nuevocli_ciudad', '1'),
('nuevocli_ciudad_req', '1'),
('nuevocli_codgrupo', ''),
('nuevocli_codpostal', '1'),
('nuevocli_codpostal_req', '0'),
('nuevocli_direccion', '1'),
('nuevocli_direccion_req', '1'),
('nuevocli_email', '1'),
('nuevocli_email_req', '1'),
('nuevocli_pais', '0'),
('nuevocli_pais_req', '0'),
('nuevocli_provincia', '1'),
('nuevocli_provincia_req', '1'),
('nuevocli_telefono1', '1'),
('nuevocli_telefono1_req', '1'),
('nuevocli_telefono2', '1'),
('nuevocli_telefono2_req', '1'),
('numeracion_personalizada', '1'),
('print_alb', '0'),
('print_dto', '1'),
('print_formapago', '1'),
('print_job_terminal', '1'),
('print_job_text', ''),
('print_ref', '1'),
('restore_comando', 'C:\\\\xampp\\mysql\\bin\\mysql.exe'),
('restore_comando_data', 'C:\\\\xampp\\mysql\\bin\\mysqlimport');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gruposclientes`
--

CREATE TABLE `gruposclientes` (
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `gruposclientes`
--

INSERT INTO `gruposclientes` (`codgrupo`, `nombre`, `codtarifa`) VALUES
('000001', 'JFK-Primaria', NULL),
('000002', 'JFK_Secundaria', NULL),
('000003', 'JFK_Jardines', NULL),
('000004', '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `idiomas_fac_det`
--

CREATE TABLE `idiomas_fac_det` (
  `codidioma` varchar(10) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `telefono` varchar(100) COLLATE utf8_bin DEFAULT 'teléfono',
  `fax` varchar(100) COLLATE utf8_bin DEFAULT 'fax',
  `email` varchar(100) COLLATE utf8_bin DEFAULT 'email',
  `web` varchar(100) COLLATE utf8_bin DEFAULT 'web',
  `factura` varchar(100) COLLATE utf8_bin DEFAULT 'factura',
  `albaran` varchar(100) COLLATE utf8_bin DEFAULT 'albarán',
  `pedido` varchar(100) COLLATE utf8_bin DEFAULT 'pedido',
  `pagina` varchar(100) COLLATE utf8_bin DEFAULT 'página',
  `fecha` varchar(100) COLLATE utf8_bin DEFAULT 'fecha',
  `num_cliente` varchar(100) COLLATE utf8_bin DEFAULT 'nº de cliente',
  `cliente` varchar(100) COLLATE utf8_bin DEFAULT 'cliente',
  `forma_pago` varchar(100) COLLATE utf8_bin DEFAULT 'forma de pago',
  `vencimiento` varchar(100) COLLATE utf8_bin DEFAULT 'vencimiento',
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT 'descripción',
  `cant` varchar(100) COLLATE utf8_bin DEFAULT 'cant',
  `precio` varchar(100) COLLATE utf8_bin DEFAULT 'precio',
  `dto` varchar(100) COLLATE utf8_bin DEFAULT 'dto',
  `iva` varchar(100) COLLATE utf8_bin DEFAULT 'iva',
  `importe` varchar(100) COLLATE utf8_bin DEFAULT 'importe',
  `importes` varchar(100) COLLATE utf8_bin DEFAULT 'importes',
  `neto` varchar(100) COLLATE utf8_bin DEFAULT 'neto',
  `rec_equiv` varchar(100) COLLATE utf8_bin DEFAULT 'rec. equiv.',
  `irpf` varchar(100) COLLATE utf8_bin DEFAULT 'irpf',
  `total` varchar(100) COLLATE utf8_bin DEFAULT 'total',
  `suma_sigue` varchar(100) COLLATE utf8_bin DEFAULT 'suma y sigue',
  `observaciones` varchar(100) COLLATE utf8_bin DEFAULT 'observaciones'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `idiomas_fac_det`
--

INSERT INTO `idiomas_fac_det` (`codidioma`, `nombre`, `activo`, `telefono`, `fax`, `email`, `web`, `factura`, `albaran`, `pedido`, `pagina`, `fecha`, `num_cliente`, `cliente`, `forma_pago`, `vencimiento`, `descripcion`, `cant`, `precio`, `dto`, `iva`, `importe`, `importes`, `neto`, `rec_equiv`, `irpf`, `total`, `suma_sigue`, `observaciones`) VALUES
('es_AR', 'Español_Argentina', 1, 'teléfono', 'fax', 'email', 'web', 'factura', 'albarán', 'pedido', 'página', 'fecha', 'nº de cliente', 'cliente', 'forma de pago', 'vencimiento', 'descripción', 'cant', 'precio', 'dto', 'iva', 'importe', 'importes', 'neto', 'rec. equiv.', 'irpf', 'total', 'suma y sigue', 'observaciones'),
('es_ES', 'Español', 1, 'teléfono', 'fax', 'email', 'web', 'factura', 'Remito', 'pedido', 'página', 'fecha', 'nº de cliente', 'cliente', 'forma de pago', 'vencimiento', 'descripción', 'cant', 'precio', 'dto', 'iva', 'importe', 'importes', 'neto', 'rec. equiv.', 'irpf', 'total', 'suma y sigue', 'observaciones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impuestos`
--

CREATE TABLE `impuestos` (
  `codimpuesto` varchar(10) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadedadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadevadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadeventue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepre` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopagra` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopimp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentarep` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentasop` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `idsubcuentaivadedadue` int(11) DEFAULT NULL,
  `idsubcuentaivadevadue` int(11) DEFAULT NULL,
  `idsubcuentaivadeventue` int(11) DEFAULT NULL,
  `idsubcuentaivarepexe` int(11) DEFAULT NULL,
  `idsubcuentaivarepexp` int(11) DEFAULT NULL,
  `idsubcuentaivarepre` int(11) DEFAULT NULL,
  `idsubcuentaivasopagra` int(11) DEFAULT NULL,
  `idsubcuentaivasopexe` int(11) DEFAULT NULL,
  `idsubcuentaivasopimp` int(11) DEFAULT NULL,
  `idsubcuentarep` int(11) DEFAULT NULL,
  `idsubcuentasop` int(11) DEFAULT NULL,
  `iva` double NOT NULL,
  `recargo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `impuestos`
--

INSERT INTO `impuestos` (`codimpuesto`, `codsubcuentaacr`, `codsubcuentadeu`, `codsubcuentaivadedadue`, `codsubcuentaivadevadue`, `codsubcuentaivadeventue`, `codsubcuentaivarepexe`, `codsubcuentaivarepexp`, `codsubcuentaivarepre`, `codsubcuentaivasopagra`, `codsubcuentaivasopexe`, `codsubcuentaivasopimp`, `codsubcuentarep`, `codsubcuentasop`, `descripcion`, `idsubcuentaacr`, `idsubcuentadeu`, `idsubcuentaivadedadue`, `idsubcuentaivadevadue`, `idsubcuentaivadeventue`, `idsubcuentaivarepexe`, `idsubcuentaivarepexp`, `idsubcuentaivarepre`, `idsubcuentaivasopagra`, `idsubcuentaivasopexe`, `idsubcuentaivasopimp`, `idsubcuentarep`, `idsubcuentasop`, `iva`, `recargo`) VALUES
('AR0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AR 0%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
('AR105', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AR 10,5%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10.5, 0),
('AR21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AR 21%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 21, 0),
('AR27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AR 27%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, 0),
('AR5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AR 5%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kdb`
--

CREATE TABLE `kdb` (
  `idkdb` int(11) NOT NULL,
  `sintoma` varchar(255) COLLATE utf8_bin NOT NULL,
  `causa` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `solucion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `kdb`
--

INSERT INTO `kdb` (`idkdb`, `sintoma`, `causa`, `solucion`, `observaciones`) VALUES
(1, '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasalbaranescli`
--

CREATE TABLE `lineasalbaranescli` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `idlineapedido` int(11) DEFAULT NULL,
  `idpedido` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `orden` int(11) DEFAULT '0',
  `mostrar_cantidad` tinyint(1) DEFAULT '1',
  `mostrar_precio` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasalbaranescli`
--

INSERT INTO `lineasalbaranescli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(3, 'AR21', 'Hiper Box XL: Un objeto pequeño d&#39;or con malware, un ambientador de pino, un palo y 8 cilindros en V.', 0, 0, 0, 0, 0, 1, 1, NULL, NULL, 0, 21, NULL, 147, 147, 49, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Tool II: Un palo con 16 ejes.', 0, 0, 0, 0, 0, 1, 2, NULL, NULL, 0, 21, NULL, 22, 22, 11, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga GeForce OS: Un dispositivo tecnológico con:\n- malignas intenciones\n- 64 núcleos\n- taladro matricial\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 1, 3, NULL, NULL, 0, 21, NULL, 1270, 1270, 635, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool SE: &quot;La hostia&quot; con cuernos metálicos.', 0, 0, 0, 0, 0, 1, 4, NULL, NULL, 0, 21, NULL, 88, 88, 44, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 22, 0, 0, 0, 1, 5, NULL, NULL, 0, 21, NULL, 500, 390, 500, 0, '4', NULL, 0, 1, 1),
(1.3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 1, 6, NULL, NULL, 0, 27, NULL, 153.543, 153.543, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 1, 7, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(3, 'AR21', 'Broken Arkam GT: Un magnetofón con un ambientador de pino, cuernos metálicos y memoria HBM.', 0, 33, 0, 0, 0, 2, 8, NULL, NULL, 0, 21, NULL, 123, 82.41, 41, 0, NULL, NULL, 0, 1, 1),
(1, 'AR27', 'Alumno', 0, 23, 0, 0, 0, 2, 9, NULL, NULL, 0, 27, NULL, 118.11, 90.9447, 118.11, 0, '3', NULL, 0, 1, 1),
(3, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 2, 10, NULL, NULL, 0, 21, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(4, NULL, 'jose ferrari jr', 0, 22, 0, 0, 0, 2, 11, NULL, NULL, 0, 0, NULL, 400, 312, 100, 0, '2', NULL, 0, 1, 1),
(-1, 'AR21', 'Neo Radeon 3: Un procesador con:\n- taladro matricial\n- linux\n- 1024 stream processors\n- reproductor 4k.', 0, 0, 0, 0, 0, 3, 12, NULL, NULL, 0, 21, NULL, -126, -126, 126, 0, NULL, NULL, 0, 1, 1),
(-16, 'AR21', 'Maxi Arkam GTX: Un magnetofón con frenos de berilio.', 0, 0, 0, 0, 0, 3, 13, NULL, NULL, 0, 21, NULL, -768, -768, 48, 0, NULL, NULL, 0, 1, 1),
(-2, 'AR21', 'Sub GeForce OS: Un motor con malignas intenciones, un palo y linux.', 0, 0, 0, 0, 0, 3, 14, NULL, NULL, 0, 21, NULL, -60, -60, 30, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 3, 15, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-1, NULL, 'Juan Perez Jr.', 0, 32, 0, 0, 0, 3, 16, NULL, NULL, 0, 0, NULL, -120, -81.6, 120, 0, '1', NULL, 0, 1, 1),
(-2, 'AR21', 'Matias Carrizo', 0, 25, 0, 0, 0, 3, 17, NULL, NULL, 0, 21, NULL, -1000, -750, 500, 0, '4', NULL, 0, 1, 1),
(14, 'AR21', 'Giga Labtech Pro: Un procesador con reproductor 4k, un posavasos, 16 ejes y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 18, NULL, NULL, 0, 21, NULL, 84, 84, 6, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Fusion Oviode NX: Una targeta gráfica (GPU) con:\n- faros de xenon\n- 16 ejes\n- propiedades psicotrópicas\n- un ambientador de pino.', 0, 0, 0, 0, 0, 4, 19, NULL, NULL, 0, 21, NULL, 336, 336, 24, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Arco Pro: Un objeto pequeño d&#39;or con:\n- malware\n- faros de xenon\n- cuernos metálicos\n- 8 cilindros en V.', 0, 32, 0, 0, 0, 4, 20, NULL, NULL, 0, 21, NULL, 38.33, 26.0644, 38.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Hiper Station GTX: Un objeto pequeño d&#39;or con:\n- taladro matricial\n- 8 cilindros en V\n- malware\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 21, NULL, NULL, 0, 21, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Proton XL: un cubo de basura con malware.', 0, 0, 0, 0, 0, 4, 22, NULL, NULL, 0, 21, NULL, 78, 78, 26, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Arkam Pro: Un procesador con:\n- 32 pistones digitales\n- pantalla Super AMOLED\n- 8 cilindros en V\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 23, NULL, NULL, 0, 21, NULL, 41, 41, 41, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'FX Neutro 3: Un objeto pequeño d&#39;or con 8 cilindros en V.', 0, 6, 0, 0, 0, 4, 24, NULL, NULL, 0, 21, NULL, 93, 87.42, 31, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Proton Nitro', 0, 0, 0, 0, 0, 4, 25, NULL, NULL, 0, 21, NULL, 72.99, 72.99, 24.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Maxi Engine SE: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 26, NULL, NULL, 0, 21, NULL, 9, 9, 3, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jex Station Pro: un cubo de basura con malware, taladro matricial, Wifi 4G y frenos de berilio.', 0, 0, 0, 0, 0, 4, 27, NULL, NULL, 0, 21, NULL, 6, 6, 6, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Giga Labtech GTX: &quot;La hostia&quot; con malignas intenciones, reproductor 4k y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 28, NULL, NULL, 0, 21, NULL, 11, 11, 11, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Radeon XP: Un motor con:\n- pantalla Super AMOLED\n- un posavasos\n- malware\n- cuernos metálicos.', 0, 27, 0, 0, 0, 4, 29, NULL, NULL, 0, 21, NULL, 40, 29.2, 40, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Pro Box XP: un cubo de basura con:\n- linux\n- la virginidad intacta\n- cuernos metálicos\n- reproductor 4k.', 0, 0, 0, 0, 0, 4, 30, NULL, NULL, 0, 21, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator 3: Un palo con memoria HBM.', 0, 0, 0, 0, 0, 4, 31, NULL, NULL, 0, 21, NULL, 48.14, 48.14, 48.14, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Minga Labtech SE', 0, 20, 0, 0, 0, 4, 32, NULL, NULL, 0, 21, NULL, 4, 3.2, 4, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Mega Radeon XP: Un motor con linux.', 0, 16, 0, 0, 0, 4, 33, NULL, NULL, 0, 21, NULL, 62.16, 52.2144, 4.44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Minga Oviode Nitro', 0, 0, 0, 0, 0, 4, 34, NULL, NULL, 0, 21, NULL, 69.34, 69.34, 34.67, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Arco XL: Un coche con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 35, NULL, NULL, 0, 21, NULL, 24.8, 24.8, 12.4, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Station XXL: &quot;La hostia&quot; con Wifi 4G, taladro matricial y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 36, NULL, NULL, 0, 21, NULL, 46, 46, 23, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Neutro OS', 0, 30, 0, 0, 0, 4, 37, NULL, NULL, 0, 21, NULL, 92, 64.4, 46, 0, NULL, NULL, 0, 1, 1),
(8, 'AR21', 'Max Radeon Pro: &quot;La hostia&quot; con:\n- tecnología digitrónica 4.1\n- propiedades psicotrópicas\n- 16 ejes\n- taladro matricial.', 0, 0, 0, 0, 0, 4, 38, NULL, NULL, 0, 21, NULL, 392, 392, 49, 0, NULL, NULL, 0, 1, 1),
(1.4, 'AR21', 'Mega Arco Nitro: Un palo con 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 39, NULL, NULL, 0, 21, NULL, 63, 63, 45, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator 3: Un motor con:\n- taladro matricial\n- la virginidad intacta\n- un núcleo híbrido\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 40, NULL, NULL, 0, 21, NULL, 43, 43, 43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Sub Labtech OS', 0, 0, 0, 0, 0, 4, 41, NULL, NULL, 0, 21, NULL, 141, 141, 47, 0, NULL, NULL, 0, 1, 1),
(7, 'AR21', 'Fusion Engine XXL: Un magnetofón con Wifi 4G, un ambientador de pino y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 42, NULL, NULL, 0, 21, NULL, 14, 14, 2, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Minga Radeon II: Un coche con 1024 stream processors, spyware, cuernos metálicos y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 43, NULL, NULL, 0, 21, NULL, 6, 6, 2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Minga Tool Nitro: Un dispositivo tecnológico con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 44, NULL, NULL, 0, 21, NULL, 29.56, 29.56, 29.56, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Box NX: &quot;La hostia&quot; con la virginidad intacta, 16 ejes y 64 núcleos.', 0, 0, 0, 0, 0, 4, 45, NULL, NULL, 0, 21, NULL, 39.33, 39.33, 39.33, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Ultra Station OS: Un motor con un palo.', 0, 0, 0, 0, 0, 4, 46, NULL, NULL, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jet GeForce Nitro', 0, 6.667, 0, 0, 0, 4, 47, NULL, NULL, 0, 21, NULL, 80.49, 75.1237317, 26.83, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Engine 3: Una alcachofa con 8 cilindros en V.', 0, 5, 0, 0, 0, 4, 48, NULL, NULL, 0, 21, NULL, 54.66, 51.927, 27.33, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Motor OS: Un palo con malignas intenciones.', 0, 0, 0, 0, 0, 4, 49, NULL, NULL, 0, 21, NULL, 48, 48, 24, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Hiper Box GT: Un coche con 64 núcleos, 8 cilindros en V, la virginidad intacta y taladro matricial.', 0, 0, 0, 0, 0, 4, 50, NULL, NULL, 0, 21, NULL, 53.14, 53.14, 26.57, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Proton GTX: &quot;La hostia&quot; con cuernos metálicos, tecnología digitrónica 4.1, propiedades psicotrópicas y 1024 stream processors.', 0, 0, 0, 0, 0, 4, 51, NULL, NULL, 0, 21, NULL, 54.6, 54.6, 18.2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Fusion Motor GTX: Un procesador con spyware, cuernos metálicos, 16 ejes y 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 52, NULL, NULL, 0, 21, NULL, 68, 68, 34, 0, NULL, NULL, 0, 1, 1),
(11, 'AR21', 'Maxi Box Nitro: &quot;La hostia&quot; con malware.', 0, 0, 0, 0, 0, 4, 53, NULL, NULL, 0, 21, NULL, 539, 539, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jet Station XL: Un motor con pantalla Super AMOLED, la virginidad intacta, chasis de fibra de carbono y 16 ejes.', 0, 0, 0, 0, 0, 4, 54, NULL, NULL, 0, 21, NULL, 7.4, 7.4, 7.4, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Box XXL: Un objeto pequeño d&#39;or con reproductor 4k, 32 pistones digitales y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 55, NULL, NULL, 0, 21, NULL, 30, 30, 30, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Minga Box OS: Un motor con un ambientador de pino.', 0, 0, 0, 0, 0, 4, 56, NULL, NULL, 0, 21, NULL, 16, 16, 8, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator XP: Un coche con:\n- pantalla Super AMOLED\n- faros de xenon\n- 16 ejes\n- linux.', 0, 0, 0, 0, 0, 4, 57, NULL, NULL, 0, 21, NULL, 8, 8, 8, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Sub Generator OS', 0, 98, 0, 0, 0, 4, 58, NULL, NULL, 0, 21, NULL, 57.26, 1.1452, 28.63, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Box SE: un cubo de basura con:\n- 8 cilindros en V\n- un núcleo híbrido\n- reproductor 4k\n- Wifi 4G.', 0, 0, 0, 0, 0, 4, 59, NULL, NULL, 0, 21, NULL, 72.86, 72.86, 36.43, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme nForce Nitro: Un motor con Windows Vista.', 0, 0, 0, 0, 0, 4, 60, NULL, NULL, 0, 21, NULL, 14.25, 14.25, 14.25, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Jex Box Pro', 0, 9, 0, 0, 0, 4, 61, NULL, NULL, 0, 21, NULL, 460, 418.6, 230, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Arkam NX: Un coche con propiedades psicotrópicas, 8 cilindros en V, spyware y 64 núcleos.', 0, 23, 0, 0, 0, 4, 62, NULL, NULL, 0, 21, NULL, 1074, 826.98, 358, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX nForce Nitro: Un palo con chasis de fibra de carbono, pantalla Super AMOLED y un ambientador de pino.', 0, 0, 0, 0, 0, 4, 63, NULL, NULL, 0, 21, NULL, 68.86, 68.86, 34.43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Minga nForce XL', 0, 27, 0, 0, 0, 4, 64, NULL, NULL, 0, 21, NULL, 117.51, 85.7823, 39.17, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion nForce XL: Un palo con un ambientador de pino, linux, tecnología digitrónica 4.1 y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 65, NULL, NULL, 0, 21, NULL, 15.99, 15.99, 5.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Generator Pro', 0, 0, 0, 0, 0, 4, 66, NULL, NULL, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega Generator XL: Una targeta gráfica (GPU) con 16 ejes.', 0, 31, 0, 0, 0, 4, 67, NULL, NULL, 0, 21, NULL, 39, 26.91, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Max Tool Nitro', 0, 0, 0, 0, 0, 4, 68, NULL, NULL, 0, 21, NULL, 592, 592, 592, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Engine GT', 0, 0, 0, 0, 0, 4, 69, NULL, NULL, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool GTX: Un dispositivo tecnológico con chasis de fibra de carbono, faros de xenon y Windows Vista.', 0, 0, 0, 0, 0, 4, 70, NULL, NULL, 0, 21, NULL, 38, 38, 19, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi Arco 3', 0, 0, 0, 0, 0, 4, 71, NULL, NULL, 0, 21, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega nForce Nitro: Una alcachofa con:\n- Wifi 4G\n- frenos de berilio\n- 8 cilindros en V\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 72, NULL, NULL, 0, 21, NULL, 46, 46, 23, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi Proton GT: Un palo con Wifi 4G, 16 ejes y tecnología digitrónica 4.1.', 0, 10, 0, 0, 0, 4, 73, NULL, NULL, 0, 21, NULL, 410, 369, 410, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Generator GT: Un motor con:\n- spyware\n- malignas intenciones\n- 64 núcleos\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 74, NULL, NULL, 0, 21, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Neutro SE: Una alcachofa con un palo.', 0, 12, 0, 0, 0, 4, 75, NULL, NULL, 0, 21, NULL, 46, 40.48, 46, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Sub Tool Pro', 0, 0, 0, 0, 0, 4, 76, NULL, NULL, 0, 21, NULL, 43.8, 43.8, 14.6, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Neutro 3', 0, 0, 0, 0, 0, 4, 77, NULL, NULL, 0, 21, NULL, 111.87, 111.87, 37.29, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Generator XL', 0, 0, 0, 0, 0, 4, 78, NULL, NULL, 0, 21, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Tool Pro: Un objeto pequeño d&#39;or con:\n- taladro matricial\n- un palo\n- faros de xenon\n- Wifi 4G.', 0, 15, 0, 0, 0, 4, 79, NULL, NULL, 0, 21, NULL, 385, 327.25, 385, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Station 3: Un motor con:\n- pantalla Super AMOLED\n- faros de xenon\n- reproductor 4k\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 80, NULL, NULL, 0, 21, NULL, 6, 6, 2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi GeForce GTX: Un magnetofón con:\n- taladro matricial\n- 64 núcleos\n- un núcleo híbrido\n- la virginidad intacta.', 0, 0, 0, 0, 0, 4, 81, NULL, NULL, 0, 21, NULL, 8.5, 8.5, 4.25, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Tool Nitro: Una alcachofa con cuernos metálicos, memoria HBM, Windows Vista y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 82, NULL, NULL, 0, 21, NULL, 51, 51, 17, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega nForce Nitro: Un palo con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 83, NULL, NULL, 0, 21, NULL, 4, 4, 2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Neo Radeon GT: Un palo con 64 núcleos.', 0, 0, 0, 0, 0, 4, 84, NULL, NULL, 0, 21, NULL, 13, 13, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Max nForce II: un cubo de basura con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 85, NULL, NULL, 0, 21, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme GeForce NX: Un magnetofón con:\n- propiedades psicotrópicas\n- 16 ejes\n- linux\n- 64 núcleos.', 0, 0, 0, 0, 0, 4, 86, NULL, NULL, 0, 21, NULL, 20, 20, 20, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Box Nitro: Una alcachofa con Windows Vista, 32 pistones digitales, spyware y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 87, NULL, NULL, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Generator Pro: Un palo con 1024 stream processors, 8 cilindros en V, memoria HBM y reproductor 4k.', 0, 0, 0, 0, 0, 4, 88, NULL, NULL, 0, 21, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Oviode NX: Un dispositivo tecnológico con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 89, NULL, NULL, 0, 21, NULL, 94, 94, 47, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Super Arkam XXL: Una targeta gráfica (GPU) con Windows Vista.', 0, 22.29, 0, 0, 0, 4, 90, NULL, NULL, 0, 21, NULL, 15.57, 12.099447, 15.57, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Max GeForce 3: Un coche con cuernos metálicos.', 0, 0, 0, 0, 0, 4, 91, NULL, NULL, 0, 21, NULL, 392, 392, 28, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Station II: Un motor con 1024 stream processors, propiedades psicotrópicas, faros de xenon y memoria HBM.', 0, 0, 0, 0, 0, 4, 92, NULL, NULL, 0, 21, NULL, 3, 3, 3, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Motor NX: Un objeto pequeño d&#39;or con 16 ejes, taladro matricial, cuernos metálicos y malware.', 0, 0, 0, 0, 0, 4, 93, NULL, NULL, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Pro Radeon Nitro: Un dispositivo tecnológico con:\n- Wifi 4G\n- linux\n- 32 pistones digitales\n- chasis de fibra de carbono.', 0, 15, 0, 0, 0, 4, 94, NULL, NULL, 0, 21, NULL, 225, 191.25, 45, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool GTX: Un magnetofón con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 95, NULL, NULL, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Ultra Arkam OS: Un objeto pequeño d&#39;or con un ambientador de pino, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 4, 96, NULL, NULL, 0, 21, NULL, 40.1, 40.1, 40.1, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jet Oviode OS: &quot;La hostia&quot; con:\n- la virginidad intacta\n- frenos de berilio\n- 16 ejes\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 97, NULL, NULL, 0, 21, NULL, 129, 129, 43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Max Neutro II: Un dispositivo tecnológico con un posavasos.', 0, 0, 0, 0, 0, 4, 98, NULL, NULL, 0, 21, NULL, 66, 66, 22, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi GeForce XP: Un objeto pequeño d&#39;or con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 99, NULL, NULL, 0, 21, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jet Arco Pro: Una targeta gráfica (GPU) con 32 pistones digitales, un ambientador de pino, cuernos metálicos y faros de xenon.', 0, 0, 0, 0, 0, 4, 100, NULL, NULL, 0, 21, NULL, 20.8, 20.8, 20.8, 0, NULL, NULL, 0, 1, 1),
(19, 'AR21', 'Sub Motor SE', 0, 9, 0, 0, 0, 4, 101, NULL, NULL, 0, 21, NULL, 4940, 4495.4, 260, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Generator II: Un motor con:\n- cuernos metálicos\n- un palo\n- malignas intenciones\n- taladro matricial.', 0, 0, 0, 0, 0, 4, 102, NULL, NULL, 0, 21, NULL, 58.29, 58.29, 19.43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Station 3: Un procesador con reproductor 4k, malware, chasis de fibra de carbono y 64 núcleos.', 0, 0, 0, 0, 0, 4, 103, NULL, NULL, 0, 21, NULL, 21.75, 21.75, 7.25, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Arco GTX', 0, 17, 0, 0, 0, 4, 104, NULL, NULL, 0, 21, NULL, 1914, 1588.62, 638, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Neutro XL: Un procesador con reproductor 4k.', 0, 0, 0, 0, 0, 4, 105, NULL, NULL, 0, 21, NULL, 42, 42, 21, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Motor GTX: Un magnetofón con Wifi 4G, 8 cilindros en V y un núcleo híbrido.', 0, 34, 0, 0, 0, 4, 106, NULL, NULL, 0, 21, NULL, 94, 62.04, 47, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'FX Box GTX: Un objeto pequeño d&#39;or con frenos de berilio, pantalla Super AMOLED y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 107, NULL, NULL, 0, 21, NULL, 30, 30, 10, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Station Pro: Una targeta gráfica (GPU) con reproductor 4k, frenos de berilio y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 108, NULL, NULL, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Fusion Engine GT', 0, 0, 0, 0, 0, 4, 109, NULL, NULL, 0, 21, NULL, 42, 42, 21, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Hiper Box 3: Un procesador con malignas intenciones, Windows Vista y Wifi 4G.', 0, 0, 0, 0, 0, 4, 110, NULL, NULL, 0, 21, NULL, 2.22, 2.22, 1.11, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Station NX', 0, 0, 0, 0, 0, 4, 111, NULL, NULL, 0, 21, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Max Labtech GTX: Un objeto pequeño d&#39;or con malware, la virginidad intacta, propiedades psicotrópicas y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 112, NULL, NULL, 0, 21, NULL, 95, 95, 19, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Max Labtech GT', 0, 0, 0, 0, 0, 4, 113, NULL, NULL, 0, 21, NULL, 102.66, 102.66, 34.22, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Neo Generator XXL', 0, 0, 0, 0, 0, 4, 114, NULL, NULL, 0, 21, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme Motor XP: Una alcachofa con taladro matricial, 32 pistones digitales y un palo.', 0, 0, 0, 0, 0, 4, 115, NULL, NULL, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Labtech XL: Un objeto pequeño d&#39;or con:\n- spyware\n- 64 núcleos\n- la virginidad intacta\n- 1024 stream processors.', 0, 19, 0, 0, 0, 4, 116, NULL, NULL, 0, 21, NULL, 31.71, 25.6851, 31.71, 0, NULL, NULL, 0, 1, 1),
(12, 'AR21', 'Hiper Oviode Nitro: un cubo de basura con faros de xenon.', 0, 0, 0, 0, 0, 4, 117, NULL, NULL, 0, 21, NULL, 585.6, 585.6, 48.8, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Radeon OS: Un procesador con 8 cilindros en V, linux y 1024 stream processors.', 0, 18, 0, 0, 0, 4, 118, NULL, NULL, 0, 21, NULL, 75, 61.5, 25, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Neo Labtech XP: un cubo de basura con malignas intenciones.', 0, 0, 0, 0, 0, 4, 119, NULL, NULL, 0, 21, NULL, 44.4, 44.4, 22.2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Arkam GTX: Un procesador con la virginidad intacta, linux y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 120, NULL, NULL, 0, 21, NULL, 46.57, 46.57, 46.57, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Motor XP: Un dispositivo tecnológico con reproductor 4k, faros de xenon y taladro matricial.', 0, 22, 0, 0, 0, 4, 121, NULL, NULL, 0, 21, NULL, 23.01, 17.9478, 7.67, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Motor GTX: Un magnetofón con un ambientador de pino.', 0, 0, 0, 0, 0, 4, 122, NULL, NULL, 0, 21, NULL, 1335, 1335, 445, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Super Neutro Nitro: Un dispositivo tecnológico con 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 123, NULL, NULL, 0, 21, NULL, 147, 147, 49, 0, NULL, NULL, 0, 1, 1),
(15, 'AR21', 'Ultra Engine NX', 0, 0, 0, 0, 0, 4, 124, NULL, NULL, 0, 21, NULL, 263.4, 263.4, 17.56, 0, NULL, NULL, 0, 1, 1),
(2.5, 'AR21', 'Minga nForce XXL: Una targeta gráfica (GPU) con:\n- spyware\n- la virginidad intacta\n- Wifi 4G\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 125, NULL, NULL, 0, 21, NULL, 70, 70, 28, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Generator OS: un cubo de basura con:\n- pantalla Super AMOLED\n- linux\n- 8 cilindros en V\n- reproductor 4k.', 0, 0, 0, 0, 0, 4, 126, NULL, NULL, 0, 21, NULL, 48, 48, 16, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Generator OS: Un dispositivo tecnológico con:\n- taladro matricial\n- 64 núcleos\n- cuernos metálicos\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 127, NULL, NULL, 0, 21, NULL, 310, 310, 310, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga Motor XP: Una targeta gráfica (GPU) con un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 128, NULL, NULL, 0, 21, NULL, 82, 82, 41, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Max Arco OS: Un palo con:\n- Wifi 4G\n- 8 cilindros en V\n- spyware\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 129, NULL, NULL, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Arco XXL: &quot;La hostia&quot; con faros de xenon, Wifi 4G, frenos de berilio y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 130, NULL, NULL, 0, 21, NULL, 70, 70, 35, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Pro Generator SE: Un motor con faros de xenon.', 0, 0, 0, 0, 0, 4, 131, NULL, NULL, 0, 21, NULL, 36, 36, 12, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Extreme Motor Pro: Un motor con frenos de berilio, un palo, 1024 stream processors y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 132, NULL, NULL, 0, 21, NULL, 24, 24, 8, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga nForce GTX: Un magnetofón con memoria HBM, propiedades psicotrópicas, tecnología digitrónica 4.1 y Windows Vista.', 0, 21, 0, 0, 0, 4, 133, NULL, NULL, 0, 21, NULL, 4, 3.16, 2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Motor GTX: Un objeto pequeño d&#39;or con un posavasos.', 0, 0, 0, 0, 0, 4, 134, NULL, NULL, 0, 21, NULL, 64.44, 64.44, 32.22, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Labtech GTX: Un procesador con Windows Vista, frenos de berilio y un palo.', 0, 7, 0, 0, 0, 4, 135, NULL, NULL, 0, 21, NULL, 68, 63.24, 34, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Box XL: Un palo con linux.', 0, 0, 0, 0, 0, 4, 136, NULL, NULL, 0, 21, NULL, 12, 12, 6, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Oviode GT: Un procesador con:\n- chasis de fibra de carbono\n- cuernos metálicos\n- taladro matricial\n- 64 núcleos.', 0, 7, 0, 0, 0, 4, 137, NULL, NULL, 0, 21, NULL, 80, 74.4, 40, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Jet Arco Pro', 0, 0, 0, 0, 0, 4, 138, NULL, NULL, 0, 21, NULL, 145, 145, 29, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Arco Nitro: Un procesador con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 139, NULL, NULL, 0, 21, NULL, 12.66, 12.66, 6.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Neutro Pro: Un procesador con pantalla Super AMOLED, 1024 stream processors y taladro matricial.', 0, 0, 0, 0, 0, 4, 140, NULL, NULL, 0, 21, NULL, 1275, 1275, 425, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Max Tool XXL: Un dispositivo tecnológico con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 141, NULL, NULL, 0, 21, NULL, 66.5, 66.5, 33.25, 0, NULL, NULL, 0, 1, 1),
(4, 'AR21', 'Jet Labtech II: Un procesador con 64 núcleos, 1024 stream processors y taladro matricial.', 0, 0, 0, 0, 0, 4, 142, NULL, NULL, 0, 21, NULL, 44, 44, 11, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Motor XP', 0, 58, 0, 0, 0, 4, 143, NULL, NULL, 0, 21, NULL, 39, 16.38, 39, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Neutro GTX: Una alcachofa con Wifi 4G, un ambientador de pino y Windows Vista.', 0, 1, 0, 0, 0, 4, 144, NULL, NULL, 0, 21, NULL, 129, 127.71, 43, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Super Tool SE: Un magnetofón con 8 cilindros en V, spyware, malignas intenciones y pantalla Super AMOLED.', 0, 7, 0, 0, 0, 4, 145, NULL, NULL, 0, 21, NULL, 28.33, 26.3469, 28.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega Proton SE: Un dispositivo tecnológico con malignas intenciones, pantalla Super AMOLED y chasis de fibra de carbono.', 0, 18, 0, 0, 0, 4, 146, NULL, NULL, 0, 21, NULL, 108, 88.56, 36, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Engine Nitro: Un motor con 16 ejes, un núcleo híbrido y un ambientador de pino.', 0, 0, 0, 0, 0, 4, 147, NULL, NULL, 0, 21, NULL, 60, 60, 30, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Tool 3: &quot;La hostia&quot; con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 148, NULL, NULL, 0, 21, NULL, 862, 862, 431, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Arkam NX: Un dispositivo tecnológico con un posavasos, 16 ejes y un ambientador de pino.', 0, 5, 0, 0, 0, 4, 149, NULL, NULL, 0, 21, NULL, 36, 34.2, 18, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 4, 150, NULL, NULL, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 4, 151, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 4, 152, NULL, NULL, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(-1, 'AR21', 'Jet Box XXL', 0, 0, 0, 0, 0, 5, 153, NULL, NULL, 0, 21, NULL, -24, -24, 24, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Minga Proton OS: Un motor con reproductor 4k, frenos de berilio y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 5, 154, NULL, NULL, 0, 21, NULL, -46.83, -46.83, 46.83, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Maxi Labtech NX: Un magnetofón con:\n- frenos de berilio\n- un ambientador de pino\n- 64 núcleos\n- reproductor 4k.', 0, 0, 0, 0, 0, 5, 155, NULL, NULL, 0, 21, NULL, -256, -256, 256, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Jex nForce Nitro: Un dispositivo tecnológico con 64 núcleos, frenos de berilio, taladro matricial y la virginidad intacta.', 0, 0, 0, 0, 0, 5, 156, NULL, NULL, 0, 21, NULL, -21, -21, 21, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Super Oviode XL', 0, 0, 0, 0, 0, 5, 157, NULL, NULL, 0, 21, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-19, 'AR21', 'Minga Proton GTX: Un procesador con taladro matricial.', 0, 8, 0, 0, 0, 5, 158, NULL, NULL, 0, 21, NULL, -627, -576.84, 33, 0, NULL, NULL, 0, 1, 1),
(-2, 'AR21', 'Ultra Box NX: Un palo con:\n- la virginidad intacta\n- reproductor 4k\n- 32 pistones digitales\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 5, 159, NULL, NULL, 0, 21, NULL, -4, -4, 2, 0, NULL, NULL, 0, 1, 1),
(-3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 5, 160, NULL, NULL, 0, 27, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 5, 161, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-19, 'AR21', 'Matias Carrizo', 0, 13, 0, 0, 0, 5, 162, NULL, NULL, 0, 21, NULL, -9500, -8265, 500, 0, '4', NULL, 0, 1, 1),
(2.3, 'AR21', 'Super Oviode XXL: Un motor con:\n- 32 pistones digitales\n- propiedades psicotrópicas\n- 64 núcleos\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 6, 163, NULL, NULL, 0, 21, NULL, 87.4, 87.4, 38, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega nForce Nitro: un cubo de basura con pantalla Super AMOLED.', 0, 8, 0, 0, 0, 6, 164, NULL, NULL, 0, 21, NULL, 117, 107.64, 39, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Giga GeForce GTX', 0, 0, 0, 0, 0, 6, 165, NULL, NULL, 0, 21, NULL, 35, 35, 35, 0, NULL, NULL, 0, 1, 1),
(8, 'AR21', 'Max Oviode SE: Una alcachofa con:\n- malware\n- pantalla Super AMOLED\n- malignas intenciones\n- un palo.', 0, 0, 0, 0, 0, 6, 166, NULL, NULL, 0, 21, NULL, 4536, 4536, 567, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 12, 0, 0, 0, 6, 167, NULL, NULL, 0, 0, NULL, 360, 316.8, 120, 0, '1', NULL, 0, 1, 1),
(6, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 6, 168, NULL, NULL, 0, 21, NULL, 3000, 3000, 500, 0, '4', NULL, 0, 1, 1),
(3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 6, 169, NULL, NULL, 0, 27, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'FX Tool SE: &quot;La hostia&quot; con cuernos metálicos, propiedades psicotrópicas, malignas intenciones y memoria HBM.', 0, 29, 0, 0, 0, 9, 170, NULL, NULL, 0, 0, NULL, 21, 14.91, 21, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Labtech GTX: Una targeta gráfica (GPU) con cuernos metálicos, 16 ejes, 1024 stream processors y un posavasos.', 0, 0, 0, 0, 0, 9, 171, NULL, NULL, 0, 0, NULL, 10, 10, 5, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Hiper GeForce Pro: un cubo de basura con:\n- 32 pistones digitales\n- la virginidad intacta\n- reproductor 4k\n- frenos de berilio.', 0, 25, 0, 0, 0, 9, 172, NULL, NULL, 0, 0, NULL, 93, 69.75, 46.5, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Max Engine XXL: Un magnetofón con un ambientador de pino, frenos de berilio y linux.', 0, 0, 0, 0, 0, 9, 173, NULL, NULL, 0, 0, NULL, 100.32, 100.32, 33.44, 0, NULL, NULL, 0, 1, 1),
(19, NULL, 'Super Labtech 3: Un coche con un posavasos, la virginidad intacta y memoria HBM.', 0, 0, 0, 0, 0, 9, 174, NULL, NULL, 0, 0, NULL, 475, 475, 25, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Arco GTX: Un palo con un palo, 8 cilindros en V y reproductor 4k.', 0, 0, 0, 0, 0, 9, 175, NULL, NULL, 0, 0, NULL, 40, 40, 20, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Neo nForce XL: Un coche con linux, frenos de berilio y 8 cilindros en V.', 0, 20, 0, 0, 0, 9, 176, NULL, NULL, 0, 0, NULL, 46, 36.8, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Mega Generator Nitro: Una targeta gráfica (GPU) con un palo, faros de xenon, malignas intenciones y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 177, NULL, NULL, 0, 0, NULL, 87, 87, 29, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Sub Labtech 3: Un dispositivo tecnológico con tecnología digitrónica 4.1, Wifi 4G y memoria HBM.', 0, 0, 0, 0, 0, 9, 178, NULL, NULL, 0, 0, NULL, 87, 87, 29, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Hiper Proton XXL: Un palo con la virginidad intacta, 1024 stream processors y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 9, 179, NULL, NULL, 0, 0, NULL, 144, 144, 48, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Minga Box XXL: Un magnetofón con:\n- Windows Vista\n- 8 cilindros en V\n- propiedades psicotrópicas\n- spyware.', 0, 0, 0, 0, 0, 9, 180, NULL, NULL, 0, 0, NULL, 6, 6, 6, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Fusion Proton OS: Un magnetofón con cuernos metálicos, un ambientador de pino y 8 cilindros en V.', 0, 0, 0, 0, 0, 9, 181, NULL, NULL, 0, 0, NULL, 27, 27, 9, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Ultra Engine II', 0, 0, 0, 0, 0, 9, 182, NULL, NULL, 0, 0, NULL, 30, 30, 10, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Max GeForce Nitro: Una targeta gráfica (GPU) con:\n- memoria HBM\n- propiedades psicotrópicas\n- la virginidad intacta\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 9, 183, NULL, NULL, 0, 0, NULL, 16.14, 16.14, 16.14, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Sub Station GT: Un palo con chasis de fibra de carbono, un ambientador de pino y 32 pistones digitales.', 0, 0, 0, 0, 0, 9, 184, NULL, NULL, 0, 0, NULL, 692, 692, 346, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Motor 3: Un objeto pequeño d&#39;or con frenos de berilio, 16 ejes, un núcleo híbrido y 8 cilindros en V.', 0, 0, 0, 0, 0, 9, 185, NULL, NULL, 0, 0, NULL, 98, 98, 49, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi Box XL', 0, 0, 0, 0, 0, 9, 186, NULL, NULL, 0, 0, NULL, 17, 17, 17, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Ultra Engine NX: Una targeta gráfica (GPU) con:\n- malignas intenciones\n- linux\n- faros de xenon\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 9, 187, NULL, NULL, 0, 0, NULL, 58.6, 58.6, 29.3, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Neutro OS: un cubo de basura con:\n- un ambientador de pino\n- taladro matricial\n- propiedades psicotrópicas\n- 64 núcleos.', 0, 0, 0, 0, 0, 9, 188, NULL, NULL, 0, 0, NULL, 78, 78, 26, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Neo Arco SE: Un objeto pequeño d&#39;or con malignas intenciones.', 0, 0, 0, 0, 0, 9, 189, NULL, NULL, 0, 0, NULL, 33, 33, 11, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo Generator OS: Una alcachofa con la virginidad intacta.', 0, 0, 0, 0, 0, 9, 190, NULL, NULL, 0, 0, NULL, 57.12, 57.12, 28.56, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jet Arkam GT: Un objeto pequeño d&#39;or con:\n- spyware\n- un núcleo híbrido\n- Windows Vista\n- reproductor 4k.', 0, 6, 0, 0, 0, 9, 191, NULL, NULL, 0, 0, NULL, 43.5, 40.89, 14.5, 0, NULL, NULL, 0, 1, 1),
(10, NULL, 'Jet Labtech SE', 0, 0, 0, 0, 0, 9, 192, NULL, NULL, 0, 0, NULL, 174, 174, 17.4, 0, NULL, NULL, 0, 1, 1),
(2.71, NULL, 'Mega Arkam Pro: Un dispositivo tecnológico con:\n- Wifi 4G\n- 1024 stream processors\n- malignas intenciones\n- 64 núcleos.', 0, 8, 0, 0, 0, 9, 193, NULL, NULL, 0, 0, NULL, 24.39, 22.4388, 9, 0, NULL, NULL, 0, 1, 1),
(2.714, NULL, 'Neo Oviode XP: Un coche con:\n- Windows Vista\n- tecnología digitrónica 4.1\n- taladro matricial\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 9, 194, NULL, NULL, 0, 0, NULL, 125.44108, 125.44108, 46.22, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Station XL: Un motor con:\n- 8 cilindros en V\n- chasis de fibra de carbono\n- 16 ejes\n- reproductor 4k.', 0, 22, 0, 0, 0, 9, 195, NULL, NULL, 0, 0, NULL, 64, 49.92, 32, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Pro Generator XP: Un palo con:\n- cuernos metálicos\n- 32 pistones digitales\n- un ambientador de pino\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 9, 196, NULL, NULL, 0, 0, NULL, 14, 14, 7, 0, NULL, NULL, 0, 1, 1),
(18, NULL, 'Hiper Arkam SE: Una targeta gráfica (GPU) con la virginidad intacta, un posavasos y 64 núcleos.', 0, 19, 0, 0, 0, 9, 197, NULL, NULL, 0, 0, NULL, 324, 262.44, 18, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'FX Oviode 3: Un dispositivo tecnológico con un ambientador de pino, propiedades psicotrópicas y malware.', 0, 0, 0, 0, 0, 9, 198, NULL, NULL, 0, 0, NULL, 54, 54, 27, 0, NULL, NULL, 0, 1, 1),
(15, NULL, 'Giga Arkam GTX: un cubo de basura con un posavasos, chasis de fibra de carbono y faros de xenon.', 0, 0, 0, 0, 0, 9, 199, NULL, NULL, 0, 0, NULL, 195, 195, 13, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Sub Station II', 0, 0, 0, 0, 0, 9, 200, NULL, NULL, 0, 0, NULL, 5, 5, 5, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Hiper Arco Nitro', 0, 0, 0, 0, 0, 9, 201, NULL, NULL, 0, 0, NULL, 78, 78, 39, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Giga Arkam Nitro: Un procesador con Wifi 4G, 8 cilindros en V y faros de xenon.', 0, 5, 0, 0, 0, 9, 202, NULL, NULL, 0, 0, NULL, 1, 0.95, 1, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Radeon XXL: &quot;La hostia&quot; con malignas intenciones, un posavasos y taladro matricial.', 0, 30, 0, 0, 0, 9, 203, NULL, NULL, 0, 0, NULL, 51, 35.7, 17, 0, NULL, NULL, 0, 1, 1),
(17, NULL, 'Hiper Engine XL: Un motor con la virginidad intacta, cuernos metálicos, 8 cilindros en V y reproductor 4k.', 0, 14, 0, 0, 0, 9, 204, NULL, NULL, 0, 0, NULL, 429.25, 369.155, 25.25, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Station NX: Una targeta gráfica (GPU) con 16 ejes, faros de xenon y malignas intenciones.', 0, 0, 0, 0, 0, 9, 205, NULL, NULL, 0, 0, NULL, 21, 21, 21, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jet Arco XP: &quot;La hostia&quot; con:\n- cuernos metálicos\n- un posavasos\n- reproductor 4k\n- spyware.', 0, 0, 0, 0, 0, 9, 206, NULL, NULL, 0, 0, NULL, 46, 46, 46, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Mega Motor XL: Un dispositivo tecnológico con 16 ejes, 1024 stream processors y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 207, NULL, NULL, 0, 0, NULL, 1194, 1194, 597, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Minga Oviode II', 0, 0, 0, 0, 0, 9, 208, NULL, NULL, 0, 0, NULL, 63, 63, 21, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Extreme Arkam NX: Un procesador con un palo, 32 pistones digitales, 64 núcleos y un núcleo híbrido.', 0, 0, 0, 0, 0, 9, 209, NULL, NULL, 0, 0, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Sub Proton GTX: Un motor con 8 cilindros en V, memoria HBM y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 9, 210, NULL, NULL, 0, 0, NULL, 120.75, 120.75, 40.25, 0, NULL, NULL, 0, 1, 1),
(17, NULL, 'Broken nForce Nitro', 0, 0, 0, 0, 0, 9, 211, NULL, NULL, 0, 0, NULL, 340, 340, 20, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'FX Tool 3: Una alcachofa con cuernos metálicos, 8 cilindros en V, faros de xenon y un núcleo híbrido.', 0, 0, 0, 0, 0, 9, 212, NULL, NULL, 0, 0, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Fusion Labtech NX: Un procesador con malignas intenciones, malware, un núcleo híbrido y taladro matricial.', 0, 0, 0, 0, 0, 9, 213, NULL, NULL, 0, 0, NULL, 1380, 1380, 460, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Max Arco Pro: Un procesador con:\n- linux\n- un núcleo híbrido\n- 16 ejes\n- reproductor 4k.', 0, 8, 0, 0, 0, 9, 214, NULL, NULL, 0, 0, NULL, 33, 30.36, 16.5, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi Generator SE', 0, 0, 0, 0, 0, 9, 215, NULL, NULL, 0, 0, NULL, 102, 102, 34, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Proton GTX: &quot;La hostia&quot; con 32 pistones digitales, propiedades psicotrópicas y malignas intenciones.', 0, 0, 0, 0, 0, 9, 216, NULL, NULL, 0, 0, NULL, 165, 165, 55, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi Engine XL: Un coche con 64 núcleos, cuernos metálicos, chasis de fibra de carbono y malware.', 0, 0, 0, 0, 0, 9, 217, NULL, NULL, 0, 0, NULL, 48, 48, 48, 0, NULL, NULL, 0, 1, 1),
(4, NULL, 'Giga Station II: Una alcachofa con malignas intenciones.', 0, 12, 0, 0, 0, 9, 218, NULL, NULL, 0, 0, NULL, 69.6, 61.248, 17.4, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Extreme Proton XP', 0, 0, 0, 0, 0, 9, 219, NULL, NULL, 0, 0, NULL, 46, 46, 46, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Engine XXL: Un palo con cuernos metálicos, faros de xenon y un núcleo híbrido.', 0, 8, 0, 0, 0, 9, 220, NULL, NULL, 0, 0, NULL, 10, 9.2, 10, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'FX Engine NX: Un magnetofón con un palo, chasis de fibra de carbono y cuernos metálicos.', 0, 0, 0, 0, 0, 9, 221, NULL, NULL, 0, 0, NULL, 276, 276, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Station XL: Una targeta gráfica (GPU) con 32 pistones digitales, Wifi 4G, malignas intenciones y la virginidad intacta.', 0, 0, 0, 0, 0, 9, 222, NULL, NULL, 0, 0, NULL, 66, 66, 22, 0, NULL, NULL, 0, 1, 1),
(16, NULL, 'Max Generator 3: Un procesador con:\n- un posavasos\n- Wifi 4G\n- faros de xenon\n- linux.', 0, 0, 0, 0, 0, 9, 223, NULL, NULL, 0, 0, NULL, 81.76, 81.76, 5.11, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Giga Box GTX', 0, 0, 0, 0, 0, 9, 224, NULL, NULL, 0, 0, NULL, 22, 22, 11, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Labtech 3: un cubo de basura con Wifi 4G.', 0, 0, 0, 0, 0, 9, 225, NULL, NULL, 0, 0, NULL, 129, 129, 43, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Fusion Arkam SE: Un palo con malignas intenciones, tecnología digitrónica 4.1, taladro matricial y Windows Vista.', 0, 0, 0, 0, 0, 9, 226, NULL, NULL, 0, 0, NULL, 24, 24, 12, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Pro Motor OS: Una alcachofa con propiedades psicotrópicas, 64 núcleos y chasis de fibra de carbono.', 0, 23.2, 0, 0, 0, 9, 227, NULL, NULL, 0, 0, NULL, 27, 20.736, 27, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Ultra Motor 3', 0, 0, 0, 0, 0, 9, 228, NULL, NULL, 0, 0, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(12, NULL, 'Jex Engine SE: Un dispositivo tecnológico con malignas intenciones, frenos de berilio y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 229, NULL, NULL, 0, 0, NULL, 7980, 7980, 665, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Hiper Radeon II: un cubo de basura con:\n- Windows Vista\n- tecnología digitrónica 4.1\n- frenos de berilio\n- spyware.', 0, 0, 0, 0, 0, 9, 230, NULL, NULL, 0, 0, NULL, 7.66, 7.66, 3.83, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Mega Box OS', 0, 5, 0, 0, 0, 9, 231, NULL, NULL, 0, 0, NULL, 31, 29.45, 31, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Extreme Arco GT', 0, 0, 0, 0, 0, 9, 232, NULL, NULL, 0, 0, NULL, 29, 29, 29, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Mega Motor OS: Un magnetofón con:\n- propiedades psicotrópicas\n- 32 pistones digitales\n- 1024 stream processors\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 9, 233, NULL, NULL, 0, 0, NULL, 18, 18, 6, 0, NULL, NULL, 0, 1, 1),
(13, NULL, 'Pro nForce GTX', 0, 0, 0, 0, 0, 9, 234, NULL, NULL, 0, 0, NULL, 494, 494, 38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Oviode XXL: un cubo de basura con memoria HBM, taladro matricial, chasis de fibra de carbono y 32 pistones digitales.', 0, 0, 0, 0, 0, 9, 235, NULL, NULL, 0, 0, NULL, 96, 96, 48, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Neo Tool 3', 0, 0, 0, 0, 0, 9, 236, NULL, NULL, 0, 0, NULL, 16, 16, 16, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Giga Engine GT: Un objeto pequeño d&#39;or con reproductor 4k, frenos de berilio, la virginidad intacta y malware.', 0, 0, 0, 0, 0, 9, 237, NULL, NULL, 0, 0, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Max Motor GTX: Un magnetofón con frenos de berilio, spyware, taladro matricial y malware.', 0, 0, 0, 0, 0, 9, 238, NULL, NULL, 0, 0, NULL, 1428, 1428, 476, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Hiper Generator XL: Un motor con 1024 stream processors, un núcleo híbrido, 32 pistones digitales y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 9, 239, NULL, NULL, 0, 0, NULL, 45, 45, 15, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Radeon Nitro: Una targeta gráfica (GPU) con:\n- malignas intenciones\n- linux\n- tecnología digitrónica 4.1\n- Windows Vista.', 0, 0, 0, 0, 0, 9, 240, NULL, NULL, 0, 0, NULL, 75, 75, 25, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Super nForce Pro', 0, 0, 0, 0, 0, 9, 241, NULL, NULL, 0, 0, NULL, 17.33, 17.33, 17.33, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Generator XL: Un palo con:\n- malware\n- faros de xenon\n- 64 núcleos\n- la virginidad intacta.', 0, 30, 0, 0, 0, 9, 242, NULL, NULL, 0, 0, NULL, 104, 72.8, 52, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken Radeon Pro', 0, 0, 0, 0, 0, 9, 243, NULL, NULL, 0, 0, NULL, 12, 12, 12, 0, NULL, NULL, 0, 1, 1),
(19, NULL, 'FX Station II', 0, 0, 0, 0, 0, 9, 244, NULL, NULL, 0, 0, NULL, 855, 855, 45, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Generator XL: Un palo con pantalla Super AMOLED.', 0, 22, 0, 0, 0, 9, 245, NULL, NULL, 0, 0, NULL, 60, 46.8, 30, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper GeForce OS', 0, 0.44, 0, 0, 0, 9, 246, NULL, NULL, 0, 0, NULL, 17, 16.9252, 17, 0, NULL, NULL, 0, 1, 1),
(18, NULL, 'Pro GeForce Nitro: Un palo con un ambientador de pino, tecnología digitrónica 4.1, frenos de berilio y la virginidad intacta.', 0, 0, 0, 0, 0, 9, 247, NULL, NULL, 0, 0, NULL, 176.4, 176.4, 9.8, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Generator XP: Un objeto pequeño d&#39;or con linux, taladro matricial y cuernos metálicos.', 0, 22, 0, 0, 0, 9, 248, NULL, NULL, 0, 0, NULL, 9, 7.02, 3, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet Radeon Pro: Un coche con malignas intenciones, reproductor 4k, un núcleo híbrido y un palo.', 0, 0, 0, 0, 0, 9, 249, NULL, NULL, 0, 0, NULL, 56, 56, 28, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Broken Arco GTX', 0, 0, 0, 0, 0, 9, 250, NULL, NULL, 0, 0, NULL, 42, 42, 14, 0, NULL, NULL, 0, 1, 1),
(2.67, NULL, 'Super Oviode GT: Un motor con:\n- chasis de fibra de carbono\n- malware\n- Wifi 4G\n- cuernos metálicos.', 0, 31, 0, 0, 0, 9, 251, NULL, NULL, 0, 0, NULL, 48.9411, 33.769359, 18.33, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'FX Motor SE', 0, 0, 0, 0, 0, 9, 252, NULL, NULL, 0, 0, NULL, 36, 36, 36, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Super GeForce GT', 0, 0, 0, 0, 0, 9, 253, NULL, NULL, 0, 0, NULL, 26, 26, 13, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Super Station OS: Un motor con frenos de berilio, malware, tecnología digitrónica 4.1 y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 9, 254, NULL, NULL, 0, 0, NULL, 23, 23, 23, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'FX Neutro 3: Una alcachofa con cuernos metálicos.', 0, 0, 0, 0, 0, 9, 255, NULL, NULL, 0, 0, NULL, 66, 66, 22, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Broken nForce 3: Un magnetofón con 1024 stream processors, Windows Vista y 16 ejes.', 0, 0, 0, 0, 0, 9, 256, NULL, NULL, 0, 0, NULL, 75, 75, 37.5, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Motor SE: Un palo con:\n- un núcleo híbrido\n- 1024 stream processors\n- linux\n- taladro matricial.', 0, 0, 0, 0, 0, 9, 257, NULL, NULL, 0, 0, NULL, 40, 40, 20, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Ultra Arkam XL: Un dispositivo tecnológico con:\n- 32 pistones digitales\n- un palo\n- taladro matricial\n- 16 ejes.', 0, 0, 0, 0, 0, 9, 258, NULL, NULL, 0, 0, NULL, 87, 87, 29, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Giga Labtech XL: &quot;La hostia&quot; con:\n- 32 pistones digitales\n- 16 ejes\n- malware\n- faros de xenon.', 0, 0, 0, 0, 0, 9, 259, NULL, NULL, 0, 0, NULL, 4, 4, 2, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken Engine NX: Una alcachofa con Windows Vista.', 0, 0, 0, 0, 0, 9, 260, NULL, NULL, 0, 0, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet Engine Pro: Un objeto pequeño d&#39;or con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 9, 261, NULL, NULL, 0, 0, NULL, 30, 30, 15, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Broken Arco GT', 0, 2, 0, 0, 0, 10, 262, NULL, NULL, 0, 10.5, NULL, 75.6, 74.088, 25.2, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo Labtech Nitro: Una targeta gráfica (GPU) con Windows Vista, malware, cuernos metálicos y reproductor 4k.', 0, 0, 0, 0, 0, 9, 263, NULL, NULL, 0, 0, NULL, 36, 36, 18, 0, NULL, NULL, 0, 1, 1),
(17, 'AR105', 'Hiper Arco XXL: Un coche con 8 cilindros en V.', 0, 0, 0, 0, 0, 10, 264, NULL, NULL, 0, 10.5, NULL, 136, 136, 8, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Fusion Generator Nitro: &quot;La hostia&quot; con un palo, 64 núcleos, malignas intenciones y propiedades psicotrópicas.', 0, 28, 0, 0, 0, 9, 265, NULL, NULL, 0, 0, NULL, 40, 28.8, 20, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Mega Motor OS: Un magnetofón con:\n- reproductor 4k\n- pantalla Super AMOLED\n- malignas intenciones\n- faros de xenon.', 0, 0, 0, 0, 0, 10, 266, NULL, NULL, 0, 10.5, NULL, 126, 126, 42, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Pro Neutro GTX: un cubo de basura con propiedades psicotrópicas, chasis de fibra de carbono, reproductor 4k y Windows Vista.', 0, 0, 0, 0, 0, 9, 267, NULL, NULL, 0, 0, NULL, 4, 4, 2, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Generator SE', 0, 0, 0, 0, 0, 10, 268, NULL, NULL, 0, 10.5, NULL, 36, 36, 12, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Radeon GTX: Un procesador con malware, cuernos metálicos y linux.', 0, 0, 0, 0, 0, 9, 269, NULL, NULL, 0, 0, NULL, 105, 105, 35, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Tool OS: Un objeto pequeño d&#39;or con un palo, cuernos metálicos y frenos de berilio.', 0, 0, 0, 0, 0, 10, 270, NULL, NULL, 0, 10.5, NULL, 126.6, 126.6, 42.2, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Oviode SE: Un motor con linux, faros de xenon, propiedades psicotrópicas y 16 ejes.', 0, 0, 0, 0, 0, 9, 271, NULL, NULL, 0, 0, NULL, 41.14, 41.14, 20.57, 0, NULL, NULL, 0, 1, 1),
(11, 'AR105', 'FX Engine Pro: &quot;La hostia&quot; con:\n- propiedades psicotrópicas\n- frenos de berilio\n- taladro matricial\n- un posavasos.', 0, 0, 0, 0, 0, 10, 272, NULL, NULL, 0, 10.5, NULL, 418, 418, 38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet Labtech II: Una targeta gráfica (GPU) con propiedades psicotrópicas, reproductor 4k, linux y Wifi 4G.', 0, 0, 0, 0, 0, 9, 273, NULL, NULL, 0, 0, NULL, 28, 28, 14, 0, NULL, NULL, 0, 1, 1),
(16, 'AR105', 'Ultra Radeon Pro: Un objeto pequeño d&#39;or con propiedades psicotrópicas, spyware y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 10, 274, NULL, NULL, 0, 10.5, NULL, 680, 680, 42.5, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Sub Motor Pro: Un motor con 32 pistones digitales.', 0, 0, 0, 0, 0, 9, 275, NULL, NULL, 0, 0, NULL, 66, 66, 22, 0, NULL, NULL, 0, 1, 1),
(2.25, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 10, 276, NULL, NULL, 0, 21, NULL, 1125, 1125, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Pro Radeon XP: Una alcachofa con un ambientador de pino.', 0, 19, 0, 0, 0, 9, 277, NULL, NULL, 0, 0, NULL, 36, 29.16, 18, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Radeon OS: un cubo de basura con un ambientador de pino.', 0, 0, 0, 0, 0, 9, 278, NULL, NULL, 0, 0, NULL, 29.8, 29.8, 29.8, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Max Tool XP: Un palo con:\n- 1024 stream processors\n- taladro matricial\n- malignas intenciones\n- malware.', 0, 0, 0, 0, 0, 9, 279, NULL, NULL, 0, 0, NULL, 87, 87, 43.5, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 10, 280, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Minga Arco XL: Un coche con un núcleo híbrido, 8 cilindros en V y cuernos metálicos.', 0, 0, 0, 0, 0, 9, 281, NULL, NULL, 0, 0, NULL, 5, 5, 5, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion Labtech II: Un motor con 64 núcleos, Windows Vista, chasis de fibra de carbono y cuernos metálicos.', 0, 16.7, 0, 0, 0, 9, 282, NULL, NULL, 0, 0, NULL, 39, 32.487, 39, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Tool GT: Una alcachofa con malware, cuernos metálicos, Wifi 4G y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 9, 283, NULL, NULL, 0, 0, NULL, 147, 147, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 10, 284, NULL, NULL, 0, 27, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Jex Labtech SE: Una alcachofa con pantalla Super AMOLED, faros de xenon, 8 cilindros en V y reproductor 4k.', 0, 0, 0, 0, 0, 9, 285, NULL, NULL, 0, 0, NULL, 18, 18, 18, 0, NULL, NULL, 0, 1, 1);
INSERT INTO `lineasalbaranescli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(1, NULL, 'Minga Labtech II: Un dispositivo tecnológico con 8 cilindros en V, memoria HBM y frenos de berilio.', 0, 0, 0, 0, 0, 9, 286, NULL, NULL, 0, 0, NULL, 16, 16, 16, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi nForce Pro', 0, 0, 0, 0, 0, 9, 287, NULL, NULL, 0, 0, NULL, 12, 12, 4, 0, NULL, NULL, 0, 1, 1),
(2.3, NULL, 'Jet Oviode GTX: Un palo con cuernos metálicos.', 0, 11, 0, 0, 0, 9, 288, NULL, NULL, 0, 0, NULL, 18.4, 16.376, 8, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Hiper Radeon NX: Un procesador con reproductor 4k.', 0, 33, 0, 0, 0, 11, 289, NULL, NULL, 0, 10.5, NULL, 786, 526.62, 393, 0, NULL, NULL, 0, 1, 1),
(7, NULL, 'Sub Tool XL: Un palo con frenos de berilio, faros de xenon, Windows Vista y un ambientador de pino.', 0, 0, 0, 0, 0, 9, 290, NULL, NULL, 0, 0, NULL, 119, 119, 17, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Jet Arco OS', 0, 0, 0, 0, 0, 11, 291, NULL, NULL, 0, 10.5, NULL, 44, 44, 22, 0, NULL, NULL, 0, 1, 1),
(4, NULL, 'Maxi GeForce XL: Un objeto pequeño d&#39;or con la virginidad intacta, 64 núcleos y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 292, NULL, NULL, 0, 0, NULL, 96, 96, 24, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Ultra Arkam XXL: Una alcachofa con chasis de fibra de carbono, 1024 stream processors, Wifi 4G y frenos de berilio.', 0, 0, 0, 0, 0, 11, 293, NULL, NULL, 0, 10.5, NULL, 10.38, 10.38, 10.38, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Super Box NX: Un coche con 32 pistones digitales.', 0, 22, 0, 0, 0, 9, 294, NULL, NULL, 0, 0, NULL, 29, 22.62, 29, 0, NULL, NULL, 0, 1, 1),
(14, 'AR105', 'Jex Station Pro: Un coche con taladro matricial, linux, propiedades psicotrópicas y un posavasos.', 0, 0, 0, 0, 0, 11, 295, NULL, NULL, 0, 10.5, NULL, 3332, 3332, 238, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion GeForce GTX: Un palo con un palo, chasis de fibra de carbono y linux.', 0, 0, 0, 0, 0, 9, 296, NULL, NULL, 0, 0, NULL, 35.4, 35.4, 35.4, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Giga Labtech XXL: un cubo de basura con un palo.', 0, 0, 0, 0, 0, 11, 297, NULL, NULL, 0, 10.5, NULL, 11, 11, 11, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jex Oviode NX: Un magnetofón con reproductor 4k, taladro matricial, 32 pistones digitales y malware.', 0, 0, 0, 0, 0, 9, 298, NULL, NULL, 0, 0, NULL, 45, 45, 45, 0, NULL, NULL, 0, 1, 1),
(1.57, 'AR105', 'Extreme Box 3: Un coche con:\n- un posavasos\n- chasis de fibra de carbono\n- 8 cilindros en V\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 11, 299, NULL, NULL, 0, 10.5, NULL, 880.77, 880.77, 561, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Hiper Neutro OS: Una targeta gráfica (GPU) con frenos de berilio, un palo, chasis de fibra de carbono y taladro matricial.', 0, 15, 0, 0, 0, 9, 300, NULL, NULL, 0, 0, NULL, 36.75, 31.2375, 12.25, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Maxi Tool 3: Un magnetofón con:\n- un posavasos\n- un palo\n- 16 ejes\n- malware.', 0, 0, 0, 0, 0, 11, 301, NULL, NULL, 0, 10.5, NULL, 40, 40, 20, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Pro Proton II', 0, 0, 0, 0, 0, 9, 302, NULL, NULL, 0, 0, NULL, 40, 40, 40, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 11, 303, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Maxi nForce II', 0, 0, 0, 0, 0, 9, 304, NULL, NULL, 0, 0, NULL, 99, 99, 33, 0, NULL, NULL, 0, 1, 1),
(2.8, NULL, 'Broken nForce 3: Un objeto pequeño d&#39;or con:\n- un ambientador de pino\n- 1024 stream processors\n- la virginidad intacta\n- taladro matricial.', 0, 0, 0, 0, 0, 9, 305, NULL, NULL, 0, 0, NULL, 92.4, 92.4, 33, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Motor GTX: Un procesador con chasis de fibra de carbono, linux, reproductor 4k y spyware.', 0, 0, 0, 0, 0, 9, 306, NULL, NULL, 0, 0, NULL, 15.5, 15.5, 15.5, 0, NULL, NULL, 0, 1, 1),
(2, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 11, 307, NULL, NULL, 0, 27, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Max Motor XP: Una targeta gráfica (GPU) con malignas intenciones, malware, pantalla Super AMOLED y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 308, NULL, NULL, 0, 0, NULL, 2, 2, 2, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 11, 309, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Fusion Arkam GT: Un objeto pequeño d&#39;or con malware.', 0, 0, 0, 0, 0, 9, 310, NULL, NULL, 0, 0, NULL, 8.49, 8.49, 2.83, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Sub Neutro 3: Un palo con pantalla Super AMOLED, 64 núcleos y 16 ejes.', 0, 0, 0, 0, 0, 9, 311, NULL, NULL, 0, 0, NULL, 675, 675, 225, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Pro Radeon GTX', 0, 0, 0, 0, 0, 9, 312, NULL, NULL, 0, 0, NULL, 36.13, 36.13, 36.13, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Mega Station XL: un cubo de basura con:\n- cuernos metálicos\n- pantalla Super AMOLED\n- propiedades psicotrópicas\n- malware.', 0, 29, 0, 0, 0, 9, 313, NULL, NULL, 0, 0, NULL, 33, 23.43, 11, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Minga Box II', 0, 0, 0, 0, 0, 9, 314, NULL, NULL, 0, 0, NULL, 70.5, 70.5, 23.5, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Sub Arco SE: un cubo de basura con tecnología digitrónica 4.1, linux y Wifi 4G.', 0, 13, 0, 0, 0, 9, 315, NULL, NULL, 0, 0, NULL, 38, 33.06, 38, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi Labtech XL', 0, 0, 0, 0, 0, 9, 316, NULL, NULL, 0, 0, NULL, 60, 60, 20, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Neo GeForce 3', 0, 0, 0, 0, 0, 9, 317, NULL, NULL, 0, 0, NULL, 93, 93, 31, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Super Oviode XP: Un palo con un ambientador de pino, 32 pistones digitales, frenos de berilio y un núcleo híbrido.', 0, 0, 0, 0, 0, 9, 318, NULL, NULL, 0, 0, NULL, 24.4, 24.4, 12.2, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Fusion Motor GTX: Un palo con:\n- Windows Vista\n- la virginidad intacta\n- 16 ejes\n- 64 núcleos.', 0, 0, 0, 0, 0, 12, 319, NULL, NULL, 0, 10.5, NULL, 81, 81, 27, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Pro Neutro XXL: Un coche con:\n- un posavasos\n- linux\n- cuernos metálicos\n- un palo.', 0, 0, 0, 0, 0, 9, 320, NULL, NULL, 0, 0, NULL, 80, 80, 40, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Fusion Station Nitro: Una targeta gráfica (GPU) con un núcleo híbrido, frenos de berilio, linux y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 12, 321, NULL, NULL, 0, 10.5, NULL, 874, 874, 437, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'Broken Labtech II: Un magnetofón con malware.', 0, 0, 0, 0, 0, 9, 322, NULL, NULL, 0, 0, NULL, 228, 228, 38, 0, NULL, NULL, 0, 1, 1),
(1.4, 'AR105', 'Jex Radeon XP', 0, 0, 0, 0, 0, 12, 323, NULL, NULL, 0, 10.5, NULL, 40.6, 40.6, 29, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jex Radeon NX', 0, 0, 0, 0, 0, 9, 324, NULL, NULL, 0, 0, NULL, 29, 29, 29, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Broken Engine GTX: Una alcachofa con:\n- un núcleo híbrido\n- taladro matricial\n- un posavasos\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 12, 325, NULL, NULL, 0, 10.5, NULL, 17.2, 17.2, 17.2, 0, NULL, NULL, 0, 1, 1),
(17, NULL, 'Minga Proton GT: &quot;La hostia&quot; con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 9, 326, NULL, NULL, 0, 0, NULL, 408, 408, 24, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 12, 327, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Giga Station XXL: Una targeta gráfica (GPU) con reproductor 4k, 64 núcleos y un ambientador de pino.', 0, 0, 0, 0, 0, 9, 328, NULL, NULL, 0, 0, NULL, 951, 951, 317, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Max Radeon NX: Una targeta gráfica (GPU) con 64 núcleos, malware y 32 pistones digitales.', 0, 0, 0, 0, 0, 9, 329, NULL, NULL, 0, 0, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(1.7, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 12, 330, NULL, NULL, 0, 27, NULL, 200.787, 200.787, 118.11, 0, '3', NULL, 0, 1, 1),
(17, NULL, 'Juan Perez Jr.', 0, 2, 0, 0, 0, 9, 331, NULL, NULL, 0, 0, NULL, 2040, 1999.2, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 12, 332, NULL, NULL, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 22.833, 0, 0, 0, 9, 333, NULL, NULL, 0, 0, NULL, 354.33, 273.4258311, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 9, 334, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(-3, 'AR105', 'Extreme Motor GTX: &quot;La hostia&quot; con:\n- 32 pistones digitales\n- 1024 stream processors\n- malignas intenciones\n- un ambientador de pino.', 0, 0, 0, 0, 0, 13, 335, NULL, NULL, 0, 10.5, NULL, -1098, -1098, 366, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR105', 'Giga Box GT: un cubo de basura con linux, 1024 stream processors, memoria HBM y 64 núcleos.', 0, 0, 0, 0, 0, 13, 336, NULL, NULL, 0, 10.5, NULL, -48, -48, 48, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR105', 'Neo Station XXL: Un objeto pequeño d&#39;or con 16 ejes, 64 núcleos y 32 pistones digitales.', 0, 0, 0, 0, 0, 13, 337, NULL, NULL, 0, 10.5, NULL, -18, -18, 18, 0, NULL, NULL, 0, 1, 1),
(-17, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 13, 338, NULL, NULL, 0, 0, NULL, -1700, -1700, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Broken Generator Pro: Un procesador con linux, 8 cilindros en V y 32 pistones digitales.', 0, 0, 0, 0, 0, 14, 339, NULL, NULL, 0, 0, NULL, 27, 27, 27, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jet Proton OS', 0, 0, 0, 0, 0, 14, 340, NULL, NULL, 0, 0, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 14, 341, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 13, 342, NULL, NULL, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 14, 343, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(-1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 13, 344, NULL, NULL, 0, 21, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 14, 345, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 14, 346, NULL, NULL, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, 'AR105', 'Jet Neutro GT: Un magnetofón con la virginidad intacta.', 0, 0, 0, 0, 0, 15, 347, NULL, NULL, 0, 10.5, NULL, 36, 36, 12, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Sub Engine GT: un cubo de basura con faros de xenon, cuernos metálicos, pantalla Super AMOLED y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 15, 348, NULL, NULL, 0, 10.5, NULL, 35.26, 35.26, 17.63, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Broken Labtech NX: un cubo de basura con un palo, 1024 stream processors, propiedades psicotrópicas y spyware.', 0, 3, 0, 0, 0, 15, 349, NULL, NULL, 0, 10.5, NULL, 123, 119.31, 41, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 16, 350, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR105', 'Super nForce XL: Un palo con un palo, chasis de fibra de carbono, tecnología digitrónica 4.1 y cuernos metálicos.', 0, 17, 0, 0, 0, 15, 351, NULL, NULL, 0, 10.5, NULL, 60.9, 50.547, 20.3, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 15, 352, NULL, NULL, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(7, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 16, 353, NULL, NULL, 0, 0, NULL, 3500, 3500, 500, 0, '4', NULL, 0, 1, 1),
(2.2, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 15, 354, NULL, NULL, 0, 27, NULL, 259.842, 259.842, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 15, 355, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(13, NULL, 'Alumno', 0, 0, 0, 0, 0, 16, 356, NULL, NULL, 0, 0, NULL, 1535.43, 1535.43, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Extreme Radeon Pro', 0, 18, 0, 0, 0, 17, 357, NULL, NULL, 0, 0, NULL, 87, 71.34, 29, 0, NULL, NULL, 0, 1, 1),
(10, NULL, 'Minga Tool SE: &quot;La hostia&quot; con reproductor 4k.', 0, 0, 0, 0, 0, 17, 358, NULL, NULL, 0, 0, NULL, 450, 450, 45, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 42, 0, 0, 0, 17, 359, NULL, NULL, 0, 0, NULL, 200, 116, 100, 0, '2', NULL, 0, 1, 1),
(2, 'AR105', 'Neo Station Pro: &quot;La hostia&quot; con:\n- un posavasos\n- memoria HBM\n- 32 pistones digitales\n- spyware.', 0, 0, 0, 0, 0, 18, 360, NULL, NULL, 0, 10.5, NULL, 70.66, 70.66, 35.33, 0, NULL, NULL, 0, 1, 1),
(19, 'AR105', 'Minga Generator XXL: un cubo de basura con propiedades psicotrópicas, taladro matricial, chasis de fibra de carbono y pantalla Super AMOLED.', 0, 29.222, 0, 0, 0, 18, 361, NULL, NULL, 0, 10.5, NULL, 858.8, 607.841464, 45.2, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 17, 362, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(2, 'AR105', 'Minga Generator XL', 0, 0, 0, 0, 0, 18, 363, NULL, NULL, 0, 10.5, NULL, 98, 98, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Minga Generator XL: Un motor con 16 ejes.', 0, 0, 0, 0, 0, 18, 364, NULL, NULL, 0, 10.5, NULL, 44, 44, 44, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Minga Motor GT: Un dispositivo tecnológico con:\n- frenos de berilio\n- cuernos metálicos\n- pantalla Super AMOLED\n- un ambientador de pino.', 0, 0, 0, 0, 0, 18, 365, NULL, NULL, 0, 10.5, NULL, 57, 57, 19, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 17, 366, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(3, 'AR105', 'Mega Neutro GTX', 0, 0, 0, 0, 0, 18, 367, NULL, NULL, 0, 10.5, NULL, 67.8, 67.8, 22.6, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Super Tool NX: Un magnetofón con 16 ejes, faros de xenon y un palo.', 0, 0, 0, 0, 0, 18, 368, NULL, NULL, 0, 10.5, NULL, 27, 27, 9, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 18, 369, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(-2, NULL, 'Minga Arkam XP: Un dispositivo tecnológico con:\n- memoria HBM\n- cuernos metálicos\n- un palo\n- 16 ejes.', 0, 0, 0, 0, 0, 19, 370, NULL, NULL, 0, 0, NULL, -32, -32, 16, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion nForce OS: Un dispositivo tecnológico con:\n- malware\n- 64 núcleos\n- un posavasos\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 19, 371, NULL, NULL, 0, 0, NULL, -286, -286, 286, 0, NULL, NULL, 0, 1, 1),
(2.2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 18, 372, NULL, NULL, 0, 0, NULL, 264, 264, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Sub Neutro OS', 0, 0, 0, 0, 0, 19, 373, NULL, NULL, 0, 0, NULL, -91.5, -91.5, 30.5, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Neutro GTX: Un objeto pequeño d&#39;or con cuernos metálicos.', 0, 0, 0, 0, 0, 19, 374, NULL, NULL, 0, 0, NULL, -19.13, -19.13, 19.13, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'FX Engine SE: Un coche con frenos de berilio, un palo y Windows Vista.', 0, 0, 0, 0, 0, 19, 375, NULL, NULL, 0, 0, NULL, -136, -136, 68, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 18, 376, NULL, NULL, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(-1, NULL, 'Jet Oviode OS: Un coche con chasis de fibra de carbono, reproductor 4k y malware.', 0, 33, 0, 0, 0, 19, 377, NULL, NULL, 0, 0, NULL, -39, -26.13, 39, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Oviode OS: Un objeto pequeño d&#39;or con reproductor 4k, un palo, un posavasos y frenos de berilio.', 0, 0, 0, 0, 0, 19, 378, NULL, NULL, 0, 0, NULL, -40, -40, 40, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 19, 379, NULL, NULL, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-5, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 19, 380, NULL, NULL, 0, 0, NULL, -500, -500, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 20, 381, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 19, 382, NULL, NULL, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 20, 383, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 20, 384, NULL, NULL, 0, 21, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2.14, NULL, 'Broken Generator XP', 0, 0, 0, 0, 0, 21, 385, NULL, NULL, 0, 0, NULL, 34.24, 34.24, 16, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jex Labtech SE: Un objeto pequeño d&#39;or con:\n- tecnología digitrónica 4.1\n- 64 núcleos\n- reproductor 4k\n- un palo.', 0, 0, 0, 0, 0, 21, 386, NULL, NULL, 0, 0, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(12, NULL, 'Mega Neutro XXL: Un coche con:\n- chasis de fibra de carbono\n- 16 ejes\n- tecnología digitrónica 4.1\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 21, 387, NULL, NULL, 0, 0, NULL, 312, 312, 26, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Extreme Tool SE: Un coche con un palo, un núcleo híbrido y un ambientador de pino.', 0, 0, 0, 0, 0, 21, 388, NULL, NULL, 0, 0, NULL, 52, 52, 26, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Pro nForce GTX: un cubo de basura con memoria HBM, malware y 32 pistones digitales.', 0, 33, 0, 0, 0, 22, 389, NULL, NULL, 0, 0, NULL, 34.14, 22.8738, 11.38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Super Station XL', 0, 0, 0, 0, 0, 21, 390, NULL, NULL, 0, 0, NULL, 96, 96, 48, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi Oviode XXL: un cubo de basura con memoria HBM, taladro matricial, chasis de fibra de carbono y 32 pistones digitales.', 0, 2, 0, 0, 0, 22, 391, NULL, NULL, 0, 0, NULL, 12.43, 12.1814, 12.43, 0, NULL, NULL, 0, 1, 1),
(14, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 21, 392, NULL, NULL, 0, 0, NULL, 1400, 1400, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Neo Tool 3: Un objeto pequeño d&#39;or con 32 pistones digitales, malware y cuernos metálicos.', 0, 0, 0, 0, 0, 22, 393, NULL, NULL, 0, 0, NULL, 39, 39, 13, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Engine GT: Un objeto pequeño d&#39;or con:\n- reproductor 4k\n- frenos de berilio\n- la virginidad intacta\n- malware.', 0, 0, 0, 0, 0, 22, 394, NULL, NULL, 0, 0, NULL, 1167, 1167, 389, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 21, 395, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Max Motor GTX', 0, 0, 0, 0, 0, 22, 396, NULL, NULL, 0, 0, NULL, 75, 75, 25, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Generator XL', 0, 0, 0, 0, 0, 22, 397, NULL, NULL, 0, 0, NULL, 30.33, 30.33, 30.33, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 22, 398, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 21, 399, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 22, 400, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 2, 0, 0, 0, 22, 401, NULL, NULL, 0, 0, NULL, 100, 98, 100, 0, '2', NULL, 0, 1, 1),
(-1, NULL, 'Extreme Oviode GTX: Un motor con un ambientador de pino.', 0, 0, 0, 0, 0, 23, 402, NULL, NULL, 0, 0, NULL, -27, -27, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo Arkam XL: Un objeto pequeño d&#39;or con taladro matricial, 32 pistones digitales, un ambientador de pino y 1024 stream processors.', 0, 0, 0, 0, 0, 23, 403, NULL, NULL, 0, 0, NULL, -72.51, -72.51, 24.17, 0, NULL, NULL, 0, 1, 1),
(-1.333, NULL, 'Minga GeForce XXL: Un palo con reproductor 4k, 16 ejes, spyware y Windows Vista.', 0, 0, 0, 0, 0, 23, 404, NULL, NULL, 0, 0, NULL, -18.662, -18.662, 14, 0, NULL, NULL, 0, 1, 1),
(-2.2, NULL, 'Fusion nForce GTX: Un dispositivo tecnológico con:\n- malware\n- faros de xenon\n- reproductor 4k\n- spyware.', 0, 0, 0, 0, 0, 23, 405, NULL, NULL, 0, 0, NULL, -97.9, -97.9, 44.5, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Pro Labtech 3: Una targeta gráfica (GPU) con:\n- 1024 stream processors\n- cuernos metálicos\n- un palo\n- Wifi 4G.', 0, 28, 0, 0, 0, 23, 406, NULL, NULL, 0, 0, NULL, -70, -50.4, 35, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Arco GTX: Un procesador con propiedades psicotrópicas, chasis de fibra de carbono y reproductor 4k.', 0, 0, 0, 0, 0, 23, 407, NULL, NULL, 0, 0, NULL, -23, -23, 23, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Proton XP: Un magnetofón con un palo, malware y 16 ejes.', 0, 0, 0, 0, 0, 24, 408, NULL, NULL, 0, 0, NULL, 35, 35, 17.5, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Station II: &quot;La hostia&quot; con 8 cilindros en V, Windows Vista, malignas intenciones y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 409, NULL, NULL, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet nForce NX: Un magnetofón con un posavasos.', 0, 15, 0, 0, 0, 24, 410, NULL, NULL, 0, 0, NULL, 1010, 858.5, 505, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Box OS: Una targeta gráfica (GPU) con faros de xenon, 8 cilindros en V y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 411, NULL, NULL, 0, 0, NULL, -141, -141, 47, 0, NULL, NULL, 0, 1, 1),
(13, NULL, 'Super Neutro XXL: &quot;La hostia&quot; con Windows Vista, spyware, pantalla Super AMOLED y linux.', 0, 0, 0, 0, 0, 24, 412, NULL, NULL, 0, 0, NULL, 242.71, 242.71, 18.67, 0, NULL, NULL, 0, 1, 1),
(-2.7, NULL, 'Giga Arkam NX: Un coche con faros de xenon.', 0, 0, 0, 0, 0, 23, 413, NULL, NULL, 0, 0, NULL, -89.1, -89.1, 33, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo nForce NX', 0, 8, 0, 0, 0, 24, 414, NULL, NULL, 0, 0, NULL, 4, 3.68, 2, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Generator XL: Una targeta gráfica (GPU) con un ambientador de pino, Windows Vista y frenos de berilio.', 0, 0, 0, 0, 0, 24, 415, NULL, NULL, 0, 0, NULL, 84.87, 84.87, 28.29, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Mega Arkam XL: un cubo de basura con:\n- reproductor 4k\n- propiedades psicotrópicas\n- la virginidad intacta\n- memoria HBM.', 0, 0, 0, 0, 0, 23, 416, NULL, NULL, 0, 0, NULL, -205, -205, 205, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Sub Engine XL', 0, 10.4, 0, 0, 0, 24, 417, NULL, NULL, 0, 0, NULL, 5.11, 4.57856, 5.11, 0, NULL, NULL, 0, 1, 1),
(-19, NULL, 'Hiper Engine Nitro: Un palo con:\n- faros de xenon\n- 8 cilindros en V\n- cuernos metálicos\n- la virginidad intacta.', 0, 0, 0, 0, 0, 23, 418, NULL, NULL, 0, 0, NULL, -836, -836, 44, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'Extreme Engine 3: Una targeta gráfica (GPU) con tecnología digitrónica 4.1, malignas intenciones, 8 cilindros en V y 32 pistones digitales.', 0, 12, 0, 0, 0, 24, 419, NULL, NULL, 0, 0, NULL, 121.98, 107.3424, 20.33, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Mega Neutro XL: Un dispositivo tecnológico con:\n- un ambientador de pino\n- faros de xenon\n- un palo\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 23, 420, NULL, NULL, 0, 0, NULL, -177.94, -177.94, 12.71, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 24, 421, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(-2.1, NULL, 'Extreme Radeon OS: Un coche con:\n- chasis de fibra de carbono\n- Wifi 4G\n- frenos de berilio\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 422, NULL, NULL, 0, 0, NULL, -44.1, -44.1, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Motor 3: Un objeto pequeño d&#39;or con reproductor 4k, chasis de fibra de carbono, malignas intenciones y faros de xenon.', 0, 0, 0, 0, 0, 23, 423, NULL, NULL, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Station SE: Una alcachofa con taladro matricial, frenos de berilio y malignas intenciones.', 0, 0, 0, 0, 0, 23, 424, NULL, NULL, 0, 0, NULL, -76.14, -76.14, 25.38, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 14, 0, 0, 0, 24, 425, NULL, NULL, 0, 0, NULL, 360, 309.6, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Giga GeForce Pro: Un coche con 32 pistones digitales, propiedades psicotrópicas, malware y Windows Vista.', 0, 20, 0, 0, 0, 23, 426, NULL, NULL, 0, 0, NULL, -7.5, -6, 2.5, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX GeForce XP: Un palo con:\n- Wifi 4G\n- 64 núcleos\n- un palo\n- malignas intenciones.', 0, 0, 0, 0, 0, 23, 427, NULL, NULL, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega nForce NX: Una alcachofa con 32 pistones digitales, malignas intenciones y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 428, NULL, NULL, 0, 0, NULL, -60.66, -60.66, 20.22, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 24, 429, NULL, NULL, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Giga Radeon Nitro', 0, 0, 0, 0, 0, 23, 430, NULL, NULL, 0, 0, NULL, -129, -129, 43, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Station GTX: Un motor con 1024 stream processors, chasis de fibra de carbono, 32 pistones digitales y un palo.', 0, 0, 0, 0, 0, 23, 431, NULL, NULL, 0, 0, NULL, -41.66, -41.66, 20.83, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Proton 3: Un magnetofón con 1024 stream processors, 16 ejes y linux.', 0, 0, 0, 0, 0, 23, 432, NULL, NULL, 0, 0, NULL, -71.4, -71.4, 23.8, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Oviode SE: Un magnetofón con pantalla Super AMOLED, memoria HBM, 1024 stream processors y 16 ejes.', 0, 0, 0, 0, 0, 23, 433, NULL, NULL, 0, 0, NULL, -87, -87, 29, 0, NULL, NULL, 0, 1, 1),
(1.6, NULL, 'Maxi Generator OS', 0, 0, 0, 0, 0, 25, 434, NULL, NULL, 0, 0, NULL, 43.2, 43.2, 27, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Proton XL: un cubo de basura con un ambientador de pino, faros de xenon, 8 cilindros en V y memoria HBM.', 0, 0, 0, 0, 0, 23, 435, NULL, NULL, 0, 0, NULL, -82, -82, 41, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Labtech GTX: Una targeta gráfica (GPU) con cuernos metálicos, memoria HBM, 16 ejes y la virginidad intacta.', 0, 16, 0, 0, 0, 25, 436, NULL, NULL, 0, 0, NULL, 27.42, 23.0328, 9.14, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Ultra Arco GTX: Un objeto pequeño d&#39;or con memoria HBM, malware y frenos de berilio.', 0, 0, 0, 0, 0, 23, 437, NULL, NULL, 0, 0, NULL, -11, -11, 11, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Generator Nitro: Un magnetofón con:\n- faros de xenon\n- propiedades psicotrópicas\n- un núcleo híbrido\n- la virginidad intacta.', 0, 16, 0, 0, 0, 25, 438, NULL, NULL, 0, 0, NULL, 144, 120.96, 48, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Oviode GT: Una targeta gráfica (GPU) con propiedades psicotrópicas, Windows Vista y malignas intenciones.', 0, 0, 0, 0, 0, 23, 439, NULL, NULL, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Station GT: Un coche con spyware.', 0, 27, 0, 0, 0, 23, 440, NULL, NULL, 0, 0, NULL, -81, -59.13, 27, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Minga Radeon 3: Un palo con:\n- memoria HBM\n- un palo\n- tecnología digitrónica 4.1\n- 16 ejes.', 0, 0, 0, 0, 0, 25, 441, NULL, NULL, 0, 0, NULL, 114, 114, 38, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Station OS: &quot;La hostia&quot; con chasis de fibra de carbono, linux, cuernos metálicos y 64 núcleos.', 0, 0, 0, 0, 0, 23, 442, NULL, NULL, 0, 0, NULL, -29, -29, 29, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Box XXL: Un objeto pequeño d&#39;or con malware, Windows Vista, pantalla Super AMOLED y propiedades psicotrópicas.', 0, 30, 0, 0, 0, 25, 443, NULL, NULL, 0, 0, NULL, 114, 79.8, 38, 0, NULL, NULL, 0, 1, 1),
(-10, NULL, 'Broken Oviode Nitro: &quot;La hostia&quot; con un posavasos.', 0, 0, 0, 0, 0, 23, 444, NULL, NULL, 0, 0, NULL, -483.3, -483.3, 48.33, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet Oviode NX: Un procesador con un núcleo híbrido, malware y 1024 stream processors.', 0, 0, 0, 0, 0, 25, 445, NULL, NULL, 0, 0, NULL, 82, 82, 41, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Arco Nitro: &quot;La hostia&quot; con:\n- chasis de fibra de carbono\n- pantalla Super AMOLED\n- la virginidad intacta\n- taladro matricial.', 0, 6, 0, 0, 0, 23, 446, NULL, NULL, 0, 0, NULL, -83.01, -78.0294, 27.67, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Generator NX', 0, 5, 0, 0, 0, 25, 447, NULL, NULL, 0, 0, NULL, 31.68, 30.096, 10.56, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Neutro GT', 0, 0, 0, 0, 0, 23, 448, NULL, NULL, 0, 0, NULL, -70, -70, 35, 0, NULL, NULL, 0, 1, 1),
(2.43, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 25, 449, NULL, NULL, 0, 0, NULL, 1215, 1215, 500, 0, '4', NULL, 0, 1, 1),
(-1.4, NULL, 'Sub Station XP: Una targeta gráfica (GPU) con 8 cilindros en V, un ambientador de pino, faros de xenon y Wifi 4G.', 0, 0, 0, 0, 0, 23, 450, NULL, NULL, 0, 0, NULL, -29.862, -29.862, 21.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Station Nitro: Un dispositivo tecnológico con un núcleo híbrido, un palo, un ambientador de pino y memoria HBM.', 0, 0, 0, 0, 0, 23, 451, NULL, NULL, 0, 0, NULL, -129, -129, 43, 0, NULL, NULL, 0, 1, 1),
(-2.333, NULL, 'Sub Box GT: Un coche con:\n- cuernos metálicos\n- propiedades psicotrópicas\n- un ambientador de pino\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 452, NULL, NULL, 0, 0, NULL, -23.33, -23.33, 10, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 5, 0, 0, 0, 25, 453, NULL, NULL, 0, 0, NULL, 236.22, 224.409, 118.11, 0, '3', NULL, 0, 1, 1),
(-2, NULL, 'Maxi Generator GT: Una alcachofa con un núcleo híbrido.', 0, 30, 0, 0, 0, 23, 454, NULL, NULL, 0, 0, NULL, -26, -18.2, 13, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 10, 0, 0, 0, 25, 455, NULL, NULL, 0, 0, NULL, 360, 324, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Pro Radeon XL', 0, 0, 0, 0, 0, 23, 456, NULL, NULL, 0, 0, NULL, -136.71, -136.71, 45.57, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Station NX', 0, 0, 0, 0, 0, 23, 457, NULL, NULL, 0, 0, NULL, -135, -135, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Generator XL: Un palo con taladro matricial, malware y cuernos metálicos.', 0, 0, 0, 0, 0, 23, 458, NULL, NULL, 0, 0, NULL, -135.6, -135.6, 45.2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Motor XXL: un cubo de basura con frenos de berilio, un posavasos, malignas intenciones y spyware.', 0, 16, 0, 0, 0, 23, 459, NULL, NULL, 0, 0, NULL, -90, -75.6, 30, 0, NULL, NULL, 0, 1, 1),
(-2.4, NULL, 'Hiper Tool 3: Una targeta gráfica (GPU) con:\n- frenos de berilio\n- propiedades psicotrópicas\n- pantalla Super AMOLED\n- spyware.', 0, 32, 0, 0, 0, 23, 460, NULL, NULL, 0, 0, NULL, -62.4, -42.432, 26, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Engine II: Un palo con reproductor 4k.', 0, 0, 0, 0, 0, 23, 461, NULL, NULL, 0, 0, NULL, -6, -6, 6, 0, NULL, NULL, 0, 1, 1),
(-4, NULL, 'Hiper Box Nitro: Una targeta gráfica (GPU) con 64 núcleos, memoria HBM, pantalla Super AMOLED y un posavasos.', 0, 0, 0, 0, 0, 23, 462, NULL, NULL, 0, 0, NULL, -57.32, -57.32, 14.33, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Arco GT', 0, 0, 0, 0, 0, 23, 463, NULL, NULL, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Motor XXL: Un palo con un núcleo híbrido.', 0, 11, 0, 0, 0, 23, 464, NULL, NULL, 0, 0, NULL, -105, -93.45, 35, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Super Radeon XP', 0, 0, 0, 0, 0, 23, 465, NULL, NULL, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Motor XL: Un magnetofón con tecnología digitrónica 4.1, un palo, cuernos metálicos y frenos de berilio.', 0, 0, 0, 0, 0, 23, 466, NULL, NULL, 0, 0, NULL, -405, -405, 405, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Mega Arkam Nitro: Un palo con linux.', 0, 0, 0, 0, 0, 23, 467, NULL, NULL, 0, 0, NULL, -19.5, -19.5, 19.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi GeForce SE', 0, 0, 0, 0, 0, 23, 468, NULL, NULL, 0, 0, NULL, -846, -846, 282, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Maxi Tool II: Un objeto pequeño d&#39;or con memoria HBM, un posavasos y frenos de berilio.', 0, 0, 0, 0, 0, 23, 469, NULL, NULL, 0, 0, NULL, -36, -36, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Station OS: Un palo con un palo, tecnología digitrónica 4.1, un posavasos y memoria HBM.', 0, 0, 0, 0, 0, 23, 470, NULL, NULL, 0, 0, NULL, -93, -93, 31, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Neutro NX: un cubo de basura con pantalla Super AMOLED, malware y linux.', 0, 1, 0, 0, 0, 23, 471, NULL, NULL, 0, 0, NULL, -68, -67.32, 34, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Generator NX: Un coche con un ambientador de pino, malware, 32 pistones digitales y taladro matricial.', 0, 0, 0, 0, 0, 23, 472, NULL, NULL, 0, 0, NULL, -565, -565, 565, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga nForce 3: Un procesador con faros de xenon.', 0, 0, 0, 0, 0, 23, 473, NULL, NULL, 0, 0, NULL, -2, -2, 2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Arco NX: Un palo con cuernos metálicos, Wifi 4G, un posavasos y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 474, NULL, NULL, 0, 0, NULL, -954, -954, 318, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Broken Arco XL: &quot;La hostia&quot; con un posavasos, 1024 stream processors y Windows Vista.', 0, 0, 0, 0, 0, 23, 475, NULL, NULL, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Giga Arco GTX: Una targeta gráfica (GPU) con linux, 16 ejes y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 476, NULL, NULL, 0, 0, NULL, -44, -44, 22, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Labtech II: un cubo de basura con spyware, faros de xenon, 1024 stream processors y un ambientador de pino.', 0, 54, 0, 0, 0, 23, 477, NULL, NULL, 0, 0, NULL, -20, -9.2, 10, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet GeForce SE', 0, 9, 0, 0, 0, 23, 478, NULL, NULL, 0, 0, NULL, -44, -40.04, 44, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'FX Radeon Nitro: Una alcachofa con chasis de fibra de carbono, la virginidad intacta y cuernos metálicos.', 0, 4.5, 0, 0, 0, 23, 479, NULL, NULL, 0, 0, NULL, -74, -70.67, 37, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Proton XL', 0, 0, 0, 0, 0, 23, 480, NULL, NULL, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo GeForce II: Una targeta gráfica (GPU) con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 481, NULL, NULL, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-16, NULL, 'Hiper Labtech SE', 0, 0, 0, 0, 0, 23, 482, NULL, NULL, 0, 0, NULL, -448, -448, 28, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Labtech XXL', 0, 0, 0, 0, 0, 23, 483, NULL, NULL, 0, 0, NULL, -10, -10, 5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Radeon GTX: Una alcachofa con malignas intenciones, malware y faros de xenon.', 0, 29, 0, 0, 0, 23, 484, NULL, NULL, 0, 0, NULL, -81, -57.51, 27, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken Arkam Pro: Un magnetofón con la virginidad intacta, 64 núcleos, 1024 stream processors y malignas intenciones.', 0, 0, 0, 0, 0, 23, 485, NULL, NULL, 0, 0, NULL, -74, -74, 37, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken nForce GT: &quot;La hostia&quot; con:\n- chasis de fibra de carbono\n- 64 núcleos\n- 1024 stream processors\n- linux.', 0, 23.2, 0, 0, 0, 23, 486, NULL, NULL, 0, 0, NULL, -92, -70.656, 46, 0, NULL, NULL, 0, 1, 1),
(-2.56, NULL, 'Jex Motor NX: Un motor con 8 cilindros en V, un palo, propiedades psicotrópicas y un ambientador de pino.', 0, 13.4, 0, 0, 0, 23, 487, NULL, NULL, 0, 0, NULL, -74.24, -64.29184, 29, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Proton XP', 0, 0, 0, 0, 0, 23, 488, NULL, NULL, 0, 0, NULL, -32, -32, 32, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Station XP: Una targeta gráfica (GPU) con:\n- taladro matricial\n- tecnología digitrónica 4.1\n- frenos de berilio\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 489, NULL, NULL, 0, 0, NULL, -345, -345, 345, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Oviode II', 0, 23, 0, 0, 0, 23, 490, NULL, NULL, 0, 0, NULL, -30, -23.1, 10, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Neutro OS: Un dispositivo tecnológico con:\n- 32 pistones digitales\n- faros de xenon\n- un núcleo híbrido\n- spyware.', 0, 0, 0, 0, 0, 23, 491, NULL, NULL, 0, 0, NULL, -11, -11, 11, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega GeForce Pro: Una targeta gráfica (GPU) con propiedades psicotrópicas, spyware, pantalla Super AMOLED y Windows Vista.', 0, 0, 0, 0, 0, 23, 492, NULL, NULL, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Labtech XL', 0, 5, 0, 0, 0, 26, 493, NULL, NULL, 0, 0, NULL, -106.29, -100.9755, 35.43, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Tool SE: un cubo de basura con cuernos metálicos, un posavasos y 1024 stream processors.', 0, 14, 0, 0, 0, 23, 494, NULL, NULL, 0, 0, NULL, -496, -426.56, 496, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'FX Arco GT: Un palo con 1024 stream processors.', 0, 0, 0, 0, 0, 26, 495, NULL, NULL, 0, 0, NULL, -39.99, -39.99, 13.33, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max nForce II: Una alcachofa con:\n- Wifi 4G\n- spyware\n- un posavasos\n- taladro matricial.', 0, 0, 0, 0, 0, 23, 496, NULL, NULL, 0, 0, NULL, -27, -27, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi Station GTX: Una targeta gráfica (GPU) con un palo, frenos de berilio, spyware y 32 pistones digitales.', 0, 0, 0, 0, 0, 26, 497, NULL, NULL, 0, 0, NULL, -55.5, -55.5, 18.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Arco NX: Una alcachofa con frenos de berilio.', 0, 0, 0, 0, 0, 23, 498, NULL, NULL, 0, 0, NULL, -9, -9, 3, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Station NX: Una targeta gráfica (GPU) con reproductor 4k, un palo y malware.', 0, 0, 0, 0, 0, 26, 499, NULL, NULL, 0, 0, NULL, -21, -21, 7, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Motor XXL: Un coche con faros de xenon, pantalla Super AMOLED, Windows Vista y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 500, NULL, NULL, 0, 0, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Oviode Pro', 0, 0, 0, 0, 0, 26, 501, NULL, NULL, 0, 0, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Giga Generator Pro: Un magnetofón con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 502, NULL, NULL, 0, 0, NULL, -224, -224, 16, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 26, 503, NULL, NULL, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-2, NULL, 'Hiper Radeon XL: un cubo de basura con 8 cilindros en V.', 0, 24, 0, 0, 0, 23, 504, NULL, NULL, 0, 0, NULL, -90.22, -68.5672, 45.11, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Radeon NX: Un palo con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 505, NULL, NULL, 0, 0, NULL, -46, -46, 46, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Labtech 3: Un motor con propiedades psicotrópicas, faros de xenon y un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 506, NULL, NULL, 0, 0, NULL, -33, -33, 33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 26, 507, NULL, NULL, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Mega Arco 3', 0, 0, 0, 0, 0, 23, 508, NULL, NULL, 0, 0, NULL, -114, -114, 38, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 26, 509, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Jet GeForce SE: un cubo de basura con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 510, NULL, NULL, 0, 0, NULL, -24, -24, 8, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Motor II: &quot;La hostia&quot; con malignas intenciones, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 23, 511, NULL, NULL, 0, 0, NULL, -1118, -1118, 559, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Engine XP: Un objeto pequeño d&#39;or con:\n- Windows Vista\n- un núcleo híbrido\n- 1024 stream processors\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 512, NULL, NULL, 0, 0, NULL, -6, -6, 6, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Radeon XXL', 0, 0, 0, 0, 0, 23, 513, NULL, NULL, 0, 0, NULL, -381, -381, 127, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Radeon SE: Un dispositivo tecnológico con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 514, NULL, NULL, 0, 0, NULL, -132, -132, 44, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Oviode GTX: Una targeta gráfica (GPU) con:\n- tecnología digitrónica 4.1\n- spyware\n- 8 cilindros en V\n- un ambientador de pino.', 0, 0, 0, 0, 0, 23, 515, NULL, NULL, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 27, 516, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(-17, NULL, 'Fusion Labtech GT: Un magnetofón con:\n- taladro matricial\n- un palo\n- malware\n- 8 cilindros en V.', 0, 2, 0, 0, 0, 23, 517, NULL, NULL, 0, 0, NULL, -374, -366.52, 22, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Hiper Generator Pro: Un procesador con un posavasos.', 0, 0, 0, 0, 0, 23, 518, NULL, NULL, 0, 0, NULL, -10.83, -10.83, 10.83, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Arkam 3: Un dispositivo tecnológico con:\n- un posavasos\n- memoria HBM\n- Wifi 4G\n- cuernos metálicos.', 0, 0, 0, 0, 0, 23, 519, NULL, NULL, 0, 0, NULL, -97.6, -97.6, 48.8, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Radeon II', 0, 0, 0, 0, 0, 23, 520, NULL, NULL, 0, 0, NULL, -5, -5, 5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Labtech OS', 0, 0, 0, 0, 0, 23, 521, NULL, NULL, 0, 0, NULL, -39, -39, 13, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Radeon II: Un magnetofón con memoria HBM, reproductor 4k y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 522, NULL, NULL, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Box GTX: Un dispositivo tecnológico con 8 cilindros en V.', 0, 0, 0, 0, 0, 28, 523, NULL, NULL, 0, 0, NULL, -39, -39, 39, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Arco XXL: Un objeto pequeño d&#39;or con Wifi 4G, un palo, cuernos metálicos y malware.', 0, 0, 0, 0, 0, 23, 524, NULL, NULL, 0, 0, NULL, -81, -81, 27, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Motor OS: Un procesador con spyware.', 0, 0, 0, 0, 0, 28, 525, NULL, NULL, 0, 0, NULL, -21, -21, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Labtech 3', 0, 0, 0, 0, 0, 23, 526, NULL, NULL, 0, 0, NULL, -111, -111, 37, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jex Radeon Nitro', 0, 6, 0, 0, 0, 28, 527, NULL, NULL, 0, 0, NULL, -90, -84.6, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Arkam 3: Un magnetofón con un palo, Windows Vista y 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 528, NULL, NULL, 0, 0, NULL, -1116, -1116, 372, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo nForce Nitro: un cubo de basura con 64 núcleos, un posavasos y spyware.', 0, 17, 0, 0, 0, 28, 529, NULL, NULL, 0, 0, NULL, -39, -32.37, 13, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo GeForce XL: Un procesador con memoria HBM, 8 cilindros en V, frenos de berilio y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 530, NULL, NULL, 0, 0, NULL, -18, -18, 18, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 2, 0, 0, 0, 28, 531, NULL, NULL, 0, 0, NULL, -240, -235.2, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Sub GeForce 3', 0, 0, 0, 0, 0, 23, 532, NULL, NULL, 0, 0, NULL, -24, -24, 12, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Labtech 3: Un coche con 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 533, NULL, NULL, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Engine OS: Una alcachofa con:\n- la virginidad intacta\n- 16 ejes\n- 1024 stream processors\n- reproductor 4k.', 0, 0, 0, 0, 0, 23, 534, NULL, NULL, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Alumno', 0, 0, 0, 0, 0, 28, 535, NULL, NULL, 0, 0, NULL, -118.11, -118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(-2.5, NULL, 'Giga Motor Pro', 0, 0, 0, 0, 0, 23, 536, NULL, NULL, 0, 0, NULL, -72.5, -72.5, 29, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 28, 537, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Extreme Generator II: Un coche con pantalla Super AMOLED, 16 ejes y taladro matricial.', 0, 0, 0, 0, 0, 23, 538, NULL, NULL, 0, 0, NULL, -28.89, -28.89, 9.63, 0, NULL, NULL, 0, 1, 1),
(-1.5, NULL, 'FX Labtech II: Una alcachofa con tecnología digitrónica 4.1, un ambientador de pino, linux y spyware.', 0, 0, 0, 0, 0, 23, 539, NULL, NULL, 0, 0, NULL, -35.565, -35.565, 23.71, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken nForce 3: Un coche con 1024 stream processors, tecnología digitrónica 4.1 y memoria HBM.', 0, 0, 0, 0, 0, 23, 540, NULL, NULL, 0, 0, NULL, -24, -24, 12, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Generator NX: Un procesador con:\n- reproductor 4k\n- propiedades psicotrópicas\n- frenos de berilio\n- Wifi 4G.', 0, 23, 0, 0, 0, 23, 541, NULL, NULL, 0, 0, NULL, -43, -33.11, 43, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Radeon NX: Un motor con un palo, malware y Wifi 4G.', 0, 0, 0, 0, 0, 23, 542, NULL, NULL, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'FX Neutro XP: Una targeta gráfica (GPU) con un posavasos, malignas intenciones, un núcleo híbrido y tecnología digitrónica 4.1.', 0, 2, 0, 0, 0, 23, 543, NULL, NULL, 0, 0, NULL, -195, -191.1, 65, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Ultra GeForce NX: Un motor con reproductor 4k, un núcleo híbrido y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 29, 544, NULL, NULL, 0, 0, NULL, 18, 18, 6, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Generator XXL: Un dispositivo tecnológico con tecnología digitrónica 4.1, 32 pistones digitales y taladro matricial.', 0, 0, 0, 0, 0, 23, 545, NULL, NULL, 0, 0, NULL, -40, -40, 20, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'FX Oviode II: Un dispositivo tecnológico con linux, faros de xenon, un posavasos y 32 pistones digitales.', 0, 0, 0, 0, 0, 29, 546, NULL, NULL, 0, 0, NULL, 326, 326, 326, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega GeForce GT: Un dispositivo tecnológico con:\n- Windows Vista\n- malignas intenciones\n- un núcleo híbrido\n- cuernos metálicos.', 0, 0, 0, 0, 0, 23, 547, NULL, NULL, 0, 0, NULL, -70, -70, 35, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Radeon NX', 0, 8, 0, 0, 0, 29, 548, NULL, NULL, 0, 0, NULL, 12, 11.04, 12, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Motor NX', 0, 31, 0, 0, 0, 23, 549, NULL, NULL, 0, 0, NULL, -16, -11.04, 8, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 29, 550, NULL, NULL, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Hiper Motor GTX: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1, reproductor 4k y linux.', 0, 0, 0, 0, 0, 23, 551, NULL, NULL, 0, 0, NULL, -12.99, -12.99, 4.33, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Arco Nitro: Un palo con un palo.', 0, 1, 0, 0, 0, 23, 552, NULL, NULL, 0, 0, NULL, -90, -89.1, 45, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Hiper Arkam GT: &quot;La hostia&quot; con faros de xenon, propiedades psicotrópicas y malware.', 0, 0, 0, 0, 0, 23, 553, NULL, NULL, 0, 0, NULL, -350, -350, 25, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 29, 554, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Extreme Motor NX: &quot;La hostia&quot; con malignas intenciones, un ambientador de pino y memoria HBM.', 0, 0, 0, 0, 0, 23, 555, NULL, NULL, 0, 0, NULL, -16, -16, 8, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Broken Arkam Pro: Un dispositivo tecnológico con memoria HBM.', 0, 32, 0, 0, 0, 23, 556, NULL, NULL, 0, 0, NULL, -43.5, -29.58, 17.4, 0, NULL, NULL, 0, 1, 1),
(-5, NULL, 'Pro Neutro OS: &quot;La hostia&quot; con un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 557, NULL, NULL, 0, 0, NULL, -130, -130, 26, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 29, 558, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Sub Box XXL: Un magnetofón con:\n- Wifi 4G\n- malware\n- memoria HBM\n- Windows Vista.', 0, 0, 0, 0, 0, 23, 559, NULL, NULL, 0, 0, NULL, -135, -135, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Engine XXL: Un magnetofón con 8 cilindros en V, cuernos metálicos, un posavasos y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 560, NULL, NULL, 0, 0, NULL, -90, -90, 30, 0, NULL, NULL, 0, 1, 1),
(-17, NULL, 'Extreme Arco GTX: Un dispositivo tecnológico con malignas intenciones, un palo, frenos de berilio y 64 núcleos.', 0, 0, 0, 0, 0, 23, 561, NULL, NULL, 0, 0, NULL, -136, -136, 8, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Giga Tool 3: Una targeta gráfica (GPU) con:\n- chasis de fibra de carbono\n- taladro matricial\n- un ambientador de pino\n- spyware.', 0, 0, 0, 0, 0, 30, 562, NULL, NULL, 0, 0, NULL, 13, 13, 13, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Generator Nitro: Un dispositivo tecnológico con:\n- malignas intenciones\n- linux\n- la virginidad intacta\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 563, NULL, NULL, 0, 0, NULL, -27, -27, 9, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Generator XL: Un objeto pequeño d&#39;or con Windows Vista.', 0, 0, 0, 0, 0, 30, 564, NULL, NULL, 0, 0, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Giga Engine 3: Un coche con malware, un palo, la virginidad intacta y Wifi 4G.', 0, 0, 0, 0, 0, 23, 565, NULL, NULL, 0, 0, NULL, -12, -12, 12, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Hiper GeForce Nitro: Una alcachofa con faros de xenon.', 0, 0, 0, 0, 0, 30, 566, NULL, NULL, 0, 0, NULL, 86.5, 86.5, 43.25, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Labtech II: un cubo de basura con tecnología digitrónica 4.1, frenos de berilio y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 567, NULL, NULL, 0, 0, NULL, -38, -38, 19, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi GeForce II', 0, 0, 0, 0, 0, 30, 568, NULL, NULL, 0, 0, NULL, 81, 81, 27, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Motor 3: Una targeta gráfica (GPU) con:\n- frenos de berilio\n- cuernos metálicos\n- memoria HBM\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 569, NULL, NULL, 0, 0, NULL, -195, -195, 195, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi GeForce 3: Un procesador con:\n- la virginidad intacta\n- propiedades psicotrópicas\n- un palo\n- faros de xenon.', 0, 0, 0, 0, 0, 30, 570, NULL, NULL, 0, 0, NULL, 541, 541, 541, 0, NULL, NULL, 0, 1, 1),
(-1.111, NULL, 'Jet Arkam NX', 0, 27, 0, 0, 0, 23, 571, NULL, NULL, 0, 0, NULL, -22.03113, -16.0827249, 19.83, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Giga Labtech GT: Una alcachofa con frenos de berilio, tecnología digitrónica 4.1, malware y taladro matricial.', 0, 0, 0, 0, 0, 30, 572, NULL, NULL, 0, 0, NULL, 10, 10, 5, 0, NULL, NULL, 0, 1, 1),
(-12, NULL, 'Mega Oviode XXL: Un palo con un ambientador de pino, frenos de berilio, un núcleo híbrido y malware.', 0, 0, 0, 0, 0, 23, 573, NULL, NULL, 0, 0, NULL, -540, -540, 45, 0, NULL, NULL, 0, 1, 1),
(7, NULL, 'Ultra Radeon XL', 0, 0, 0, 0, 0, 30, 574, NULL, NULL, 0, 0, NULL, 77, 77, 11, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Arkam Nitro: Un palo con 8 cilindros en V.', 0, 8, 0, 0, 0, 23, 575, NULL, NULL, 0, 0, NULL, -105, -96.6, 35, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 31, 0, 0, 0, 30, 576, NULL, NULL, 0, 0, NULL, 300, 207, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Minga Engine GTX: Un palo con:\n- malware\n- un ambientador de pino\n- linux\n- frenos de berilio.', 0, 0, 0, 0, 0, 23, 577, NULL, NULL, 0, 0, NULL, -63, -63, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Arco XP', 0, 0, 0, 0, 0, 23, 578, NULL, NULL, 0, 0, NULL, -66, -66, 22, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Mega Arkam SE', 0, 0, 0, 0, 0, 23, 579, NULL, NULL, 0, 0, NULL, -142.5, -142.5, 57, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 30, 580, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-2.2, NULL, 'Mega Engine GT: Un palo con spyware, pantalla Super AMOLED y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 581, NULL, NULL, 0, 0, NULL, -39.6, -39.6, 18, 0, NULL, NULL, 0, 1, 1),
(9, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 30, 582, NULL, NULL, 0, 0, NULL, 4500, 4500, 500, 0, '4', NULL, 0, 1, 1);
INSERT INTO `lineasalbaranescli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(-2.5, NULL, 'Neo Station XP: Una alcachofa con:\n- faros de xenon\n- malware\n- un núcleo híbrido\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 583, NULL, NULL, 0, 0, NULL, -90, -90, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Oviode XL: Un procesador con un núcleo híbrido, 1024 stream processors y spyware.', 0, 0, 0, 0, 0, 23, 584, NULL, NULL, 0, 0, NULL, -120, -120, 40, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Arco Pro: Un objeto pequeño d&#39;or con:\n- tecnología digitrónica 4.1\n- Windows Vista\n- memoria HBM\n- malignas intenciones.', 0, 26, 0, 0, 0, 23, 585, NULL, NULL, 0, 0, NULL, -25, -18.5, 25, 0, NULL, NULL, 0, 1, 1),
(-9, NULL, 'FX Motor GTX: Un objeto pequeño d&#39;or con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 586, NULL, NULL, 0, 0, NULL, -126, -126, 14, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga Oviode 3: un cubo de basura con frenos de berilio, malware, un ambientador de pino y un palo.', 0, 0, 0, 0, 0, 23, 587, NULL, NULL, 0, 0, NULL, -102, -102, 34, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Generator GT: un cubo de basura con spyware, linux y 1024 stream processors.', 0, 0.4, 0, 0, 0, 23, 588, NULL, NULL, 0, 0, NULL, -48, -47.808, 48, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Station OS: Un palo con Windows Vista, malignas intenciones y un palo.', 0, 0, 0, 0, 0, 23, 589, NULL, NULL, 0, 0, NULL, -278, -278, 139, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Box OS: &quot;La hostia&quot; con memoria HBM, propiedades psicotrópicas, Windows Vista y 1024 stream processors.', 0, 0, 0, 0, 0, 23, 590, NULL, NULL, 0, 0, NULL, -72, -72, 36, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Engine 3: Un motor con:\n- linux\n- 16 ejes\n- Windows Vista\n- un ambientador de pino.', 0, 38, 0, 0, 0, 23, 591, NULL, NULL, 0, 0, NULL, -14, -8.68, 14, 0, NULL, NULL, 0, 1, 1),
(-2.6, NULL, 'Extreme Arco 3: Un dispositivo tecnológico con cuernos metálicos, propiedades psicotrópicas y linux.', 0, 0, 0, 0, 0, 23, 592, NULL, NULL, 0, 0, NULL, -81.9, -81.9, 31.5, 0, NULL, NULL, 0, 1, 1),
(-1.375, NULL, 'Hiper Engine XL: Un objeto pequeño d&#39;or con:\n- memoria HBM\n- 16 ejes\n- malware\n- Wifi 4G.', 0, 28, 0, 0, 0, 23, 593, NULL, NULL, 0, 0, NULL, -698.5, -502.92, 508, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Proton SE: Un coche con:\n- cuernos metálicos\n- la virginidad intacta\n- spyware\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 594, NULL, NULL, 0, 0, NULL, -139.2, -139.2, 46.4, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub GeForce OS: Un coche con:\n- frenos de berilio\n- un posavasos\n- Wifi 4G\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 595, NULL, NULL, 0, 0, NULL, -42, -42, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo Oviode NX', 0, 16, 0, 0, 0, 23, 596, NULL, NULL, 0, 0, NULL, -84, -70.56, 28, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max GeForce SE: Un coche con 64 núcleos, memoria HBM y cuernos metálicos.', 0, 0, 0, 0, 0, 23, 597, NULL, NULL, 0, 0, NULL, -36, -36, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Tool 3: Un procesador con un ambientador de pino.', 0, 0, 0, 0, 0, 23, 598, NULL, NULL, 0, 0, NULL, -96, -96, 32, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi nForce SE: Una targeta gráfica (GPU) con linux, malware y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 599, NULL, NULL, 0, 0, NULL, -141.33, -141.33, 47.11, 0, NULL, NULL, 0, 1, 1),
(-2.625, NULL, 'Extreme Arco NX: Un magnetofón con linux, taladro matricial y memoria HBM.', 0, 25, 0, 0, 0, 23, 600, NULL, NULL, 0, 0, NULL, -354.375, -265.78125, 135, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 23, 601, NULL, NULL, 0, 0, NULL, -200, -200, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 23, 602, NULL, NULL, 0, 0, NULL, -1500, -1500, 500, 0, '4', NULL, 0, 1, 1),
(-1, NULL, 'Alumno', 0, 36, 0, 0, 0, 23, 603, NULL, NULL, 0, 0, NULL, -118.11, -75.5904, 118.11, 0, '3', NULL, 0, 1, 1),
(6, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 31, 604, NULL, NULL, 0, 0, NULL, 3000, 3000, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 31, 605, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 31, 606, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 8, 0, 0, 0, 32, 607, NULL, NULL, 0, 0, NULL, 1500, 1380, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 32, 608, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Max Labtech II: un cubo de basura con 32 pistones digitales.', 0, 0, 0, 0, 0, 33, 609, NULL, NULL, 0, 0, NULL, 31, 31, 31, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 21, 0, 0, 0, 32, 610, NULL, NULL, 0, 0, NULL, 236.22, 186.6138, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Giga Neutro GTX: Un coche con:\n- 1024 stream processors\n- 64 núcleos\n- memoria HBM\n- 8 cilindros en V.', 0, 16, 0, 0, 0, 33, 611, NULL, NULL, 0, 0, NULL, 201, 168.84, 67, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Oviode NX: &quot;La hostia&quot; con tecnología digitrónica 4.1, linux, chasis de fibra de carbono y spyware.', 0, 0, 0, 0, 0, 33, 612, NULL, NULL, 0, 0, NULL, 9, 9, 3, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Broken Proton GT: Un motor con:\n- 32 pistones digitales\n- un posavasos\n- propiedades psicotrópicas\n- 16 ejes.', 0, 0, 0, 0, 0, 33, 613, NULL, NULL, 0, 0, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Broken GeForce Nitro: Un objeto pequeño d&#39;or con Windows Vista, pantalla Super AMOLED y 64 núcleos.', 0, 0, 0, 0, 0, 33, 614, NULL, NULL, 0, 0, NULL, 114, 114, 38, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Minga Box XL: Un palo con 32 pistones digitales.', 0, 0, 0, 0, 0, 33, 615, NULL, NULL, 0, 0, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(1.25, NULL, 'Pro GeForce NX: Un palo con memoria HBM, spyware y frenos de berilio.', 0, 0, 0, 0, 0, 33, 616, NULL, NULL, 0, 0, NULL, 111.25, 111.25, 89, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Mega Oviode 3', 0, 0, 0, 0, 0, 35, 617, NULL, NULL, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 24, 0, 0, 0, 33, 618, NULL, NULL, 0, 0, NULL, 200, 152, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Pro GeForce GT: un cubo de basura con:\n- 8 cilindros en V\n- un ambientador de pino\n- chasis de fibra de carbono\n- la virginidad intacta.', 0, 0, 0, 0, 0, 35, 619, NULL, NULL, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 35, 620, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 33, 621, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 35, 622, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 33, 623, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 35, 624, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 36, 625, NULL, NULL, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Alumno', 0, 0, 0, 0, 0, 36, 626, NULL, NULL, 0, 0, NULL, -236.22, -236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Ultra Station Pro: Un magnetofón con un posavasos, cuernos metálicos, memoria HBM y linux.', 0, 0, 0, 0, 0, 37, 627, NULL, NULL, 0, 0, NULL, 42, 42, 21, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 37, 628, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 37, 629, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(6, NULL, 'Alumno', 0, 0, 0, 0, 0, 37, 630, NULL, NULL, 0, 0, NULL, 708.66, 708.66, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Jex Arkam OS', 0, 0, 0, 0, 0, 38, 631, NULL, NULL, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 38, 632, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 38, 633, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 38, 634, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(8, NULL, 'Jex Tool SE: Un dispositivo tecnológico con:\n- malignas intenciones\n- 64 núcleos\n- 1024 stream processors\n- la virginidad intacta.', 0, 24, 0, 0, 0, 39, 635, NULL, NULL, 0, 0, NULL, 72, 54.72, 9, 0, NULL, NULL, 0, 1, 1),
(8, NULL, 'Mega Neutro XXL: Un objeto pequeño d&#39;or con taladro matricial, un núcleo híbrido, 64 núcleos y 16 ejes.', 0, 0, 0, 0, 0, 39, 636, NULL, NULL, 0, 0, NULL, 4680, 4680, 585, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Super Labtech NX: Un motor con memoria HBM, un posavasos, pantalla Super AMOLED y un ambientador de pino.', 0, 2, 0, 0, 0, 39, 637, NULL, NULL, 0, 0, NULL, 10, 9.8, 5, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Sub Labtech NX', 0, 0, 0, 0, 0, 39, 638, NULL, NULL, 0, 0, NULL, 91.66, 91.66, 45.83, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 39, 639, NULL, NULL, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Fusion Motor GT', 0, 0, 0, 0, 0, 40, 640, NULL, NULL, 0, 0, NULL, 41.25, 41.25, 41.25, 0, NULL, NULL, 0, 1, 1),
(5, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 39, 641, NULL, NULL, 0, 0, NULL, 2500, 2500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 40, 642, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 40, 643, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 39, 644, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 33, 0, 0, 0, 40, 645, NULL, NULL, 0, 0, NULL, 360, 241.2, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 41, 646, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(-16, NULL, 'Broken nForce GTX: un cubo de basura con 16 ejes, linux, un posavasos y memoria HBM.', 0, 0, 0, 0, 0, 42, 647, NULL, NULL, 0, 0, NULL, -224, -224, 14, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Radeon Pro: Una targeta gráfica (GPU) con 32 pistones digitales.', 0, 0, 0, 0, 0, 42, 648, NULL, NULL, 0, 0, NULL, -117, -117, 39, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Tool SE: &quot;La hostia&quot; con:\n- reproductor 4k\n- memoria HBM\n- un núcleo híbrido\n- un palo.', 0, 0, 0, 0, 0, 42, 649, NULL, NULL, 0, 0, NULL, -642, -642, 642, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 41, 650, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-1, NULL, 'Fusion Engine XP: Un objeto pequeño d&#39;or con un palo, 64 núcleos, 16 ejes y memoria HBM.', 0, 0, 0, 0, 0, 42, 651, NULL, NULL, 0, 0, NULL, -1, -1, 1, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Extreme Motor XP: Un coche con:\n- 32 pistones digitales\n- frenos de berilio\n- tecnología digitrónica 4.1\n- linux.', 0, 0, 0, 0, 0, 42, 652, NULL, NULL, 0, 0, NULL, -6, -6, 3, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Arco Nitro: Un palo con 64 núcleos, un palo, spyware y pantalla Super AMOLED.', 0, 5, 0, 0, 0, 42, 653, NULL, NULL, 0, 0, NULL, -141, -133.95, 47, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Arkam OS: Una targeta gráfica (GPU) con:\n- la virginidad intacta\n- linux\n- propiedades psicotrópicas\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 42, 654, NULL, NULL, 0, 0, NULL, -75.34, -75.34, 37.67, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Arkam XP: Un objeto pequeño d&#39;or con 1024 stream processors, spyware, frenos de berilio y 32 pistones digitales.', 0, 0, 0, 0, 0, 43, 655, NULL, NULL, 0, 0, NULL, 22.76, 22.76, 11.38, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 22, 0, 0, 0, 42, 656, NULL, NULL, 0, 0, NULL, -300, -234, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Broken Generator SE: &quot;La hostia&quot; con un palo, tecnología digitrónica 4.1 y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 43, 657, NULL, NULL, 0, 0, NULL, 22.86, 22.86, 11.43, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Neo Box 3: Una alcachofa con un ambientador de pino, reproductor 4k y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 43, 658, NULL, NULL, 0, 0, NULL, 145.68, 145.68, 48.56, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Arkam SE: Una alcachofa con un palo, un ambientador de pino y 1024 stream processors.', 0, 0, 0, 0, 0, 43, 659, NULL, NULL, 0, 0, NULL, 3, 3, 1, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Alumno', 0, 0, 0, 0, 0, 42, 660, NULL, NULL, 0, 0, NULL, -236.22, -236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1.1, NULL, 'Super Labtech NX: Una targeta gráfica (GPU) con Wifi 4G, malignas intenciones y taladro matricial.', 0, 0, 0, 0, 0, 43, 661, NULL, NULL, 0, 0, NULL, 30.8, 30.8, 28, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 42, 662, NULL, NULL, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 43, 663, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 43, 664, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 43, 665, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'FX Engine SE: Un coche con frenos de berilio.', 0, 0, 0, 0, 0, 44, 666, NULL, NULL, 0, 0, NULL, -37, -37, 37, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Oviode OS: Un coche con chasis de fibra de carbono, reproductor 4k, malware y faros de xenon.', 0, 0, 0, 0, 0, 44, 667, NULL, NULL, 0, 0, NULL, -42, -42, 14, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Oviode OS', 0, 0, 0, 0, 0, 44, 668, NULL, NULL, 0, 0, NULL, -20, -20, 10, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 44, 669, NULL, NULL, 0, 0, NULL, -1500, -1500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 44, 670, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 44, 671, NULL, NULL, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Broken Generator XP', 0, 0, 0, 0, 0, 45, 672, NULL, NULL, 0, 0, NULL, 697, 697, 697, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Labtech SE: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 45, 673, NULL, NULL, 0, 0, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Mega Neutro XXL: Un coche con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 45, 674, NULL, NULL, 0, 0, NULL, 4.5, 4.5, 4.5, 0, NULL, NULL, 0, 1, 1),
(13, NULL, 'Extreme Tool SE: Un coche con un palo, un núcleo híbrido, un ambientador de pino y la virginidad intacta.', 0, 0, 0, 0, 0, 45, 675, NULL, NULL, 0, 0, NULL, 390, 390, 30, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 45, 676, NULL, NULL, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 45, 677, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 45, 678, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 45, 679, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'FX nForce 3: Un magnetofón con un posavasos.', 0, 0, 0, 0, 0, 46, 680, NULL, NULL, 0, 0, NULL, -124.5, -124.5, 41.5, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Giga Tool XL: Una alcachofa con un ambientador de pino.', 0, 0, 0, 0, 0, 46, 681, NULL, NULL, 0, 0, NULL, -1016, -1016, 508, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 46, 682, NULL, NULL, 0, 0, NULL, -100, -100, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 46, 683, NULL, NULL, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 46, 684, NULL, NULL, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 46, 685, NULL, NULL, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Max Motor II: Una alcachofa con:\n- spyware\n- 32 pistones digitales\n- linux\n- un palo.', 0, 0, 0, 0, 0, 47, 686, NULL, NULL, 0, 0, NULL, 46, 46, 46, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Engine XP: Un palo con la virginidad intacta.', 0, 0, 0, 0, 0, 47, 687, NULL, NULL, 0, 0, NULL, 76, 76, 38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo Neutro Nitro', 0, 0, 0, 0, 0, 47, 688, NULL, NULL, 0, 0, NULL, 90, 90, 45, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jet Arco NX: Un objeto pequeño d&#39;or con un ambientador de pino.', 0, 0, 0, 0, 0, 47, 689, NULL, NULL, 0, 0, NULL, 6, 6, 2, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Hiper Proton Nitro', 0, 21.5, 0, 0, 0, 47, 690, NULL, NULL, 0, 0, NULL, 105, 82.425, 35, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi Labtech 3: &quot;La hostia&quot; con tecnología digitrónica 4.1, taladro matricial y un palo.', 0, 0, 0, 0, 0, 47, 691, NULL, NULL, 0, 0, NULL, 24, 24, 8, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 47, 692, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1.6, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 47, 693, NULL, NULL, 0, 0, NULL, 800, 800, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 47, 694, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 47, 695, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 48, 696, NULL, NULL, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 48, 697, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 48, 698, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Sub Labtech GTX: Una alcachofa con linux, memoria HBM, frenos de berilio y Windows Vista.', 0, 0, 0, 0, 0, 49, 699, NULL, NULL, 0, 0, NULL, 32, 32, 16, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 12, 0, 0, 0, 49, 700, NULL, NULL, 0, 0, NULL, 236.22, 207.8736, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 49, 701, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 49, 702, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Hiper Engine Pro: Un motor con 16 ejes.', 0, 0, 0, 0, 0, 50, 703, NULL, NULL, 0, 0, NULL, 129, 129, 43, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Extreme Generator OS: Un dispositivo tecnológico con:\n- un ambientador de pino\n- un posavasos\n- chasis de fibra de carbono\n- reproductor 4k.', 0, 0, 0, 0, 0, 50, 704, NULL, NULL, 0, 0, NULL, 36, 36, 36, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'FX Motor OS: Un coche con:\n- frenos de berilio\n- faros de xenon\n- un ambientador de pino\n- linux.', 0, 0, 0, 0, 0, 50, 705, NULL, NULL, 0, 0, NULL, 122.5, 122.5, 49, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Arkam GT', 0, 99, 0, 0, 0, 50, 706, NULL, NULL, 0, 0, NULL, 94.68, 0.9468, 31.56, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 50, 707, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 50, 708, NULL, NULL, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(14, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 50, 709, NULL, NULL, 0, 0, NULL, 7000, 7000, 500, 0, '4', NULL, 0, 1, 1),
(17, 'AR105', 'Fusion Proton GTX: Un magnetofón con:\n- cuernos metálicos\n- 1024 stream processors\n- reproductor 4k\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 51, 710, NULL, NULL, 0, 10.5, NULL, 493, 493, 29, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Hiper Station NX', 0, 0, 0, 0, 0, 51, 711, NULL, NULL, 0, 10.5, NULL, 123, 123, 41, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Minga Neutro GTX', 0, 0, 0, 0, 0, 51, 712, NULL, NULL, 0, 10.5, NULL, 97.14, 97.14, 32.38, 0, NULL, NULL, 0, 1, 1),
(2, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 51, 713, NULL, NULL, 0, 27, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 5, 0, 0, 0, 51, 714, NULL, NULL, 0, 0, NULL, 360, 342, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 51, 715, NULL, NULL, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 52, 716, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(1.57, NULL, 'Juan Perez Jr.', 0, 28, 0, 0, 0, 52, 717, NULL, NULL, 0, 0, NULL, 188.4, 135.648, 120, 0, '1', NULL, 0, 1, 1),
(2.2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 52, 718, NULL, NULL, 0, 0, NULL, 220, 220, 100, 0, '2', NULL, 0, 1, 1),
(1, 'AR105', 'Minga Motor XP', 0, 13, 0, 0, 0, 53, 719, NULL, NULL, 0, 10.5, NULL, 15.38, 13.3806, 15.38, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Jex Generator Pro: un cubo de basura con chasis de fibra de carbono, un núcleo híbrido, un palo y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 53, 720, NULL, NULL, 0, 10.5, NULL, 330, 330, 110, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Fusion Box XXL: Un objeto pequeño d&#39;or con faros de xenon.', 0, 0, 0, 0, 0, 53, 721, NULL, NULL, 0, 10.5, NULL, 12.99, 12.99, 4.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Sub Labtech NX: Un palo con:\n- taladro matricial\n- chasis de fibra de carbono\n- un núcleo híbrido\n- 8 cilindros en V.', 0, 17, 0, 0, 0, 53, 722, NULL, NULL, 0, 10.5, NULL, 17, 14.11, 17, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Max Motor Pro', 0, 38, 0, 0, 0, 53, 723, NULL, NULL, 0, 10.5, NULL, 12, 7.44, 4, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Arkam NX: Un dispositivo tecnológico con un palo.', 0, 3, 0, 0, 0, 53, 724, NULL, NULL, 0, 10.5, NULL, 54.75, 53.1075, 18.25, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Giga Station OS: Un magnetofón con frenos de berilio.', 0, 0, 0, 0, 0, 53, 725, NULL, NULL, 0, 10.5, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(2.11, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 53, 726, NULL, NULL, 0, 27, NULL, 249.2121, 249.2121, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 53, 727, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 53, 728, NULL, NULL, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(1, 'AR105', 'Maxi Station GTX: Un objeto pequeño d&#39;or con:\n- 8 cilindros en V\n- un ambientador de pino\n- la virginidad intacta\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 54, 729, NULL, NULL, 0, 10.5, NULL, 24, 24, 24, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Jex Labtech SE: Un procesador con 32 pistones digitales, malignas intenciones, Windows Vista y 1024 stream processors.', 0, 0, 0, 0, 0, 54, 730, NULL, NULL, 0, 10.5, NULL, 67.5, 67.5, 22.5, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Broken Engine NX: Un magnetofón con:\n- Windows Vista\n- 1024 stream processors\n- memoria HBM\n- la virginidad intacta.', 0, 32, 0, 0, 0, 54, 731, NULL, NULL, 0, 10.5, NULL, 26, 17.68, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Ultra nForce Pro', 0, 0, 0, 0, 0, 54, 732, NULL, NULL, 0, 10.5, NULL, 1.14, 1.14, 1.14, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 54, 733, NULL, NULL, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(5, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 54, 734, NULL, NULL, 0, 0, NULL, 500, 500, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 54, 735, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR105', 'Ultra Arco 3', 0, 0, 0, 0, 0, 55, 736, NULL, NULL, 0, 10.5, NULL, 3, 3, 3, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Broken Neutro GT: &quot;La hostia&quot; con malware.', 0, 0, 0, 0, 0, 55, 737, NULL, NULL, 0, 10.5, NULL, 40, 40, 20, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Minga Engine OS: Un coche con 1024 stream processors, 64 núcleos, la virginidad intacta y taladro matricial.', 0, 0, 0, 0, 0, 55, 738, NULL, NULL, 0, 10.5, NULL, 8, 8, 4, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Giga Labtech 3: Un objeto pequeño d&#39;or con faros de xenon.', 0, 0, 0, 0, 0, 55, 739, NULL, NULL, 0, 10.5, NULL, 41, 41, 41, 0, NULL, NULL, 0, 1, 1),
(2.667, 'AR105', 'Ultra GeForce GT: Un procesador con un núcleo híbrido, un palo, 32 pistones digitales y 1024 stream processors.', 0, 0, 0, 0, 0, 55, 740, NULL, NULL, 0, 10.5, NULL, 112.014, 112.014, 42, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'FX GeForce 3: &quot;La hostia&quot; con la virginidad intacta, pantalla Super AMOLED, un núcleo híbrido y Wifi 4G.', 0, 0, 0, 0, 0, 55, 741, NULL, NULL, 0, 10.5, NULL, 86, 86, 43, 0, NULL, NULL, 0, 1, 1),
(10, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 55, 742, NULL, NULL, 0, 0, NULL, 1000, 1000, 100, 0, '2', NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 20, 0, 0, 0, 55, 743, NULL, NULL, 0, 21, NULL, 1000, 800, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 55, 744, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Broken Neutro 3', 0, 0, 0, 0, 0, 56, 745, NULL, NULL, 0, 0, NULL, 223, 223, 223, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Fusion Engine SE: Un procesador con un núcleo híbrido, pantalla Super AMOLED, reproductor 4k y un posavasos.', 0, 82, 0, 0, 0, 56, 746, NULL, NULL, 0, 0, NULL, 69, 12.42, 23, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion Tool XP: &quot;La hostia&quot; con:\n- frenos de berilio\n- 16 ejes\n- Windows Vista\n- malignas intenciones.', 0, 0, 0, 0, 0, 56, 747, NULL, NULL, 0, 0, NULL, 32, 32, 32, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo GeForce OS: Un magnetofón con 1024 stream processors, faros de xenon y frenos de berilio.', 0, 0, 0, 0, 0, 56, 748, NULL, NULL, 0, 0, NULL, 54, 54, 27, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Oviode Pro: Una alcachofa con Wifi 4G.', 0, 0, 0, 0, 0, 56, 749, NULL, NULL, 0, 0, NULL, 16.11, 16.11, 16.11, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 56, 750, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 56, 751, NULL, NULL, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 56, 752, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR105', 'Broken Station GT', 0, 0, 0, 0, 0, 57, 753, NULL, NULL, 0, 10.5, NULL, 21, 21, 7, 0, NULL, NULL, 0, 1, 1),
(15, 'AR105', 'Maxi Generator Pro: Un coche con:\n- un ambientador de pino\n- malware\n- taladro matricial\n- un posavasos.', 0, 3, 0, 0, 0, 57, 754, NULL, NULL, 0, 10.5, NULL, 346.5, 336.105, 23.1, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 57, 755, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 31, 0, 0, 0, 57, 756, NULL, NULL, 0, 0, NULL, 300, 207, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 57, 757, NULL, NULL, 0, 27, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-1, NULL, 'Minga GeForce XXL', 0, 0, 0, 0, 0, 58, 758, NULL, NULL, 0, 0, NULL, -15, -15, 15, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 58, 759, NULL, NULL, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 59, 0, 0, 0, 58, 760, NULL, NULL, 0, 0, NULL, -360, -147.6, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 58, 761, NULL, NULL, 0, 0, NULL, -200, -200, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 14, 0, 0, 0, 58, 762, NULL, NULL, 0, 0, NULL, -1500, -1290, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 59, 763, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 19, 0, 0, 0, 59, 764, NULL, NULL, 0, 0, NULL, 300, 243, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 59, 765, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(-2, NULL, 'FX Neutro XP: &quot;La hostia&quot; con un ambientador de pino, un núcleo híbrido y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 60, 766, NULL, NULL, 0, 0, NULL, -48, -48, 24, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Station XP: Un magnetofón con reproductor 4k, la virginidad intacta y frenos de berilio.', 0, 0, 0, 0, 0, 60, 767, NULL, NULL, 0, 0, NULL, -48, -48, 48, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Arkam XXL: Un objeto pequeño d&#39;or con:\n- cuernos metálicos\n- 64 núcleos\n- faros de xenon\n- un posavasos.', 0, 30, 0, 0, 0, 60, 768, NULL, NULL, 0, 0, NULL, -132, -92.4, 44, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 60, 769, NULL, NULL, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 25, 0, 0, 0, 60, 770, NULL, NULL, 0, 0, NULL, -354.33, -265.7475, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 60, 771, NULL, NULL, 0, 0, NULL, -1500, -1500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Jex Neutro NX: Un objeto pequeño d&#39;or con:\n- spyware\n- malignas intenciones\n- chasis de fibra de carbono\n- 64 núcleos.', 0, 0, 0, 0, 0, 61, 772, NULL, NULL, 0, 0, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jet Labtech NX: Una alcachofa con un núcleo híbrido.', 0, 0, 0, 0, 0, 61, 773, NULL, NULL, 0, 0, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Fusion Tool GTX: Una alcachofa con linux, reproductor 4k y 16 ejes.', 0, 0, 0, 0, 0, 61, 774, NULL, NULL, 0, 0, NULL, 674, 674, 337, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Labtech Pro: Un magnetofón con:\n- un núcleo híbrido\n- chasis de fibra de carbono\n- la virginidad intacta\n- linux.', 0, 0, 0, 0, 0, 61, 775, NULL, NULL, 0, 0, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 61, 776, NULL, NULL, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 26, 0, 0, 0, 61, 777, NULL, NULL, 0, 0, NULL, 120, 88.8, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 14.8, 0, 0, 0, 61, 778, NULL, NULL, 0, 0, NULL, 236.22, 201.25944, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 62, 779, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 62, 780, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 63, 781, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 63, 782, NULL, NULL, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Fusion Station XL: &quot;La hostia&quot; con:\n- taladro matricial\n- pantalla Super AMOLED\n- 64 núcleos\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 64, 783, NULL, NULL, 0, 0, NULL, 10, 10, 10, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet nForce II: Un magnetofón con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 64, 784, NULL, NULL, 0, 0, NULL, 24.66, 24.66, 12.33, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'Super Labtech OS: Un procesador con:\n- pantalla Super AMOLED\n- 1024 stream processors\n- faros de xenon\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 64, 785, NULL, NULL, 0, 0, NULL, 17.5, 17.5, 7, 0, NULL, NULL, 0, 1, 1),
(1.5, NULL, 'FX Radeon II', 0, 0, 0, 0, 0, 64, 786, NULL, NULL, 0, 0, NULL, 51, 51, 34, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'Extreme Neutro NX: Un motor con un núcleo híbrido, Wifi 4G, 64 núcleos y malignas intenciones.', 0, 30, 0, 0, 0, 64, 787, NULL, NULL, 0, 0, NULL, 240, 168, 40, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super nForce XXL: un cubo de basura con la virginidad intacta, Windows Vista y cuernos metálicos.', 0, 24, 0, 0, 0, 64, 788, NULL, NULL, 0, 0, NULL, 147, 111.72, 49, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 24, 0, 0, 0, 64, 789, NULL, NULL, 0, 0, NULL, 1000, 760, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 64, 790, NULL, NULL, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 64, 791, NULL, NULL, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'FX Neutro GTX: Una targeta gráfica (GPU) con:\n- la virginidad intacta\n- chasis de fibra de carbono\n- 8 cilindros en V\n- un ambientador de pino.', 0, 1, 0, 0, 0, 65, 792, NULL, NULL, 0, 0, NULL, 844, 835.56, 422, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 65, 793, NULL, NULL, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 65, 794, NULL, NULL, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 65, 795, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Extreme Proton Nitro: Una targeta gráfica (GPU) con:\n- malignas intenciones\n- Windows Vista\n- la virginidad intacta\n- malware.', 0, 28, 0, 0, 0, 66, 796, NULL, NULL, 0, 0, NULL, 100.2, 72.144, 33.4, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 66, 797, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(14, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 66, 798, NULL, NULL, 0, 0, NULL, 7000, 7000, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 66, 799, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 66, 800, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 10, 0, 0, 0, 67, 801, NULL, NULL, 0, 0, NULL, 200, 180, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 67, 802, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 67, 803, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(-2.67, NULL, 'Mega nForce XL', 0, 0, 0, 0, 0, 68, 804, NULL, NULL, 0, 0, NULL, -40.9311, -40.9311, 15.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga Arkam GTX: Un motor con cuernos metálicos.', 0, 0, 0, 0, 0, 68, 805, NULL, NULL, 0, 0, NULL, -62.01, -62.01, 20.67, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Neutro GT: Un objeto pequeño d&#39;or con linux, malware y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 68, 806, NULL, NULL, 0, 0, NULL, -40.4, -40.4, 40.4, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Box GTX: Una targeta gráfica (GPU) con Wifi 4G, un palo y tecnología digitrónica 4.1.', 0, 25, 0, 0, 0, 68, 807, NULL, NULL, 0, 0, NULL, -49, -36.75, 49, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Generator XP: Una alcachofa con:\n- un posavasos\n- faros de xenon\n- reproductor 4k\n- malware.', 0, 0, 0, 0, 0, 68, 808, NULL, NULL, 0, 0, NULL, -27.34, -27.34, 13.67, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 68, 809, NULL, NULL, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 68, 810, NULL, NULL, 0, 0, NULL, -120, -120, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 68, 811, NULL, NULL, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'FX Tool 3: Un objeto pequeño d&#39;or con malignas intenciones.', 0, 0, 0, 0, 0, 69, 812, NULL, NULL, 0, 0, NULL, 64, 64, 32, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Neo Neutro SE: Una alcachofa con un núcleo híbrido, propiedades psicotrópicas, 16 ejes y frenos de berilio.', 0, 0, 0, 0, 0, 69, 813, NULL, NULL, 0, 0, NULL, 6, 6, 6, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'FX nForce Nitro: Un dispositivo tecnológico con reproductor 4k, memoria HBM, un posavasos y 8 cilindros en V.', 0, 0, 0, 0, 0, 69, 814, NULL, NULL, 0, 0, NULL, 51, 51, 17, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo Generator SE: Una alcachofa con:\n- faros de xenon\n- un ambientador de pino\n- malignas intenciones\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 69, 815, NULL, NULL, 0, 0, NULL, 52, 52, 26, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'Jex Arco XL: Un objeto pequeño d&#39;or con Wifi 4G, 64 núcleos, un ambientador de pino y memoria HBM.', 0, 25, 0, 0, 0, 69, 816, NULL, NULL, 0, 0, NULL, 100, 75, 40, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Labtech Pro: Un motor con:\n- spyware\n- tecnología digitrónica 4.1\n- un posavasos\n- frenos de berilio.', 0, 0, 0, 0, 0, 69, 817, NULL, NULL, 0, 0, NULL, 78, 78, 39, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 69, 818, NULL, NULL, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 69, 819, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 69, 820, NULL, NULL, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Pro Engine 3: Un palo con cuernos metálicos, 64 núcleos y malignas intenciones.', 0, 0, 0, 0, 0, 70, 821, NULL, NULL, 0, 0, NULL, 17, 17, 17, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Engine XXL: Una alcachofa con propiedades psicotrópicas, un posavasos, 16 ejes y malignas intenciones.', 0, 0, 0, 0, 0, 70, 822, NULL, NULL, 0, 0, NULL, 86, 86, 43, 0, NULL, NULL, 0, 1, 1),
(5, NULL, 'Extreme GeForce XXL: &quot;La hostia&quot; con reproductor 4k, Windows Vista, un núcleo híbrido y faros de xenon.', 0, 0, 0, 0, 0, 70, 823, NULL, NULL, 0, 0, NULL, 115, 115, 23, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 70, 824, NULL, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 70, 825, NULL, NULL, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 70, 826, NULL, NULL, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(-2, NULL, 'Jex Labtech XL: Un dispositivo tecnológico con chasis de fibra de carbono, tecnología digitrónica 4.1 y un ambientador de pino.', 0, 15, 0, 0, 0, 71, 827, NULL, NULL, 0, 0, NULL, -86, -73.1, 43, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken Radeon XP: Un coche con frenos de berilio, propiedades psicotrópicas, la virginidad intacta y linux.', 0, 0, 0, 0, 0, 71, 828, NULL, NULL, 0, 0, NULL, -76, -76, 38, 0, NULL, NULL, 0, 1, 1),
(-10, NULL, 'Jet Generator XP', 0, 0, 0, 0, 0, 71, 829, NULL, NULL, 0, 0, NULL, -20, -20, 2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Station GT: Un palo con reproductor 4k, malignas intenciones, 32 pistones digitales y 16 ejes.', 0, 0, 0, 0, 0, 71, 830, NULL, NULL, 0, 0, NULL, -144, -144, 48, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Motor Pro: Un palo con 64 núcleos, un posavasos, 8 cilindros en V y un palo.', 0, 0, 0, 0, 0, 71, 831, NULL, NULL, 0, 0, NULL, -42, -42, 14, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 71, 832, NULL, NULL, 0, 0, NULL, -1000, -1000, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 71, 833, NULL, NULL, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 71, 834, NULL, NULL, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1.5, NULL, 'Minga Labtech II', 0, 62, 0, 0, 0, 72, 835, NULL, NULL, 0, 0, NULL, 53.07, 20.1666, 35.38, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 28, 0, 0, 0, 72, 836, NULL, NULL, 0, 0, NULL, 354.33, 255.1176, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 72, 837, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 72, 838, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Sub Neutro II: Un procesador con 8 cilindros en V, un ambientador de pino, 16 ejes y taladro matricial.', 0, 0, 0, 0, 0, 73, 839, NULL, NULL, 0, 0, NULL, -82.71, -82.71, 27.57, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Neutro GTX: &quot;La hostia&quot; con taladro matricial, 32 pistones digitales, Windows Vista y faros de xenon.', 0, 0, 0, 0, 0, 73, 840, NULL, NULL, 0, 0, NULL, -116.01, -116.01, 38.67, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Minga Proton XP', 0, 0, 0, 0, 0, 73, 841, NULL, NULL, 0, 0, NULL, -14, -14, 7, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Giga Labtech GT: Un procesador con reproductor 4k, Wifi 4G y malignas intenciones.', 0, 0, 0, 0, 0, 73, 842, NULL, NULL, 0, 0, NULL, -38, -38, 38, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Motor XL: Una alcachofa con:\n- un palo\n- malignas intenciones\n- 64 núcleos\n- reproductor 4k.', 0, 0, 0, 0, 0, 73, 843, NULL, NULL, 0, 0, NULL, -3, -3, 3, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Arkam Nitro: Un magnetofón con:\n- pantalla Super AMOLED\n- frenos de berilio\n- Windows Vista\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 73, 844, NULL, NULL, 0, 0, NULL, -32, -32, 32, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Generator Pro: Un procesador con frenos de berilio.', 0, 0, 0, 0, 0, 73, 845, NULL, NULL, 0, 0, NULL, -33, -33, 33, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Minga Radeon NX', 0, 0, 0, 0, 0, 73, 846, NULL, NULL, 0, 0, NULL, -8.22, -8.22, 4.11, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Tool Pro: Un objeto pequeño d&#39;or con:\n- malware\n- Windows Vista\n- 8 cilindros en V\n- reproductor 4k.', 0, 20, 0, 0, 0, 73, 847, NULL, NULL, 0, 0, NULL, -60, -48, 20, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega GeForce NX', 0, 0, 0, 0, 0, 73, 848, NULL, NULL, 0, 0, NULL, -56.66, -56.66, 28.33, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Labtech SE: &quot;La hostia&quot; con linux, memoria HBM, un posavasos y 32 pistones digitales.', 0, 4, 0, 0, 0, 73, 849, NULL, NULL, 0, 0, NULL, -27, -25.92, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Radeon GT: Un motor con malware.', 0, 0, 0, 0, 0, 73, 850, NULL, NULL, 0, 0, NULL, -1719, -1719, 573, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Ultra Generator NX: un cubo de basura con linux, taladro matricial y 16 ejes.', 0, 0, 0, 0, 0, 73, 851, NULL, NULL, 0, 0, NULL, -21, -21, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi Labtech GTX: Una targeta gráfica (GPU) con 32 pistones digitales, memoria HBM y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 73, 852, NULL, NULL, 0, 0, NULL, -9, -9, 3, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Box XP', 0, 0, 0, 0, 0, 73, 853, NULL, NULL, 0, 0, NULL, -396, -396, 396, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Generator NX: Una alcachofa con la virginidad intacta, memoria HBM y 64 núcleos.', 0, 0, 0, 0, 0, 73, 854, NULL, NULL, 0, 0, NULL, -76.2, -76.2, 38.1, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Neutro XL', 0, 0, 0, 0, 0, 73, 855, NULL, NULL, 0, 0, NULL, -2, -2, 1, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Tool Pro', 0, 0, 0, 0, 0, 73, 856, NULL, NULL, 0, 0, NULL, -126, -126, 42, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Arkam XXL', 0, 0, 0, 0, 0, 73, 857, NULL, NULL, 0, 0, NULL, -27, -27, 9, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Motor XXL: Un palo con la virginidad intacta, 32 pistones digitales y Wifi 4G.', 0, 0, 0, 0, 0, 73, 858, NULL, NULL, 0, 0, NULL, -71, -71, 35.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi Arco XXL: Un objeto pequeño d&#39;or con:\n- pantalla Super AMOLED\n- un posavasos\n- faros de xenon\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 73, 859, NULL, NULL, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max nForce GT: Un motor con un posavasos, malignas intenciones, un palo y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 73, 860, NULL, NULL, 0, 0, NULL, -40, -40, 20, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Neutro XXL: Un dispositivo tecnológico con 16 ejes, spyware y 8 cilindros en V.', 0, 0, 0, 0, 0, 73, 861, NULL, NULL, 0, 0, NULL, -8, -8, 4, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Engine II: &quot;La hostia&quot; con un palo.', 0, 21, 0, 0, 0, 73, 862, NULL, NULL, 0, 0, NULL, -22, -17.38, 22, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Generator Pro', 0, 0, 0, 0, 0, 73, 863, NULL, NULL, 0, 0, NULL, -9, -9, 9, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Labtech GTX', 0, 0, 0, 0, 0, 73, 864, NULL, NULL, 0, 0, NULL, -12, -12, 4, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Pro Generator GT: Una alcachofa con:\n- malware\n- la virginidad intacta\n- linux\n- faros de xenon.', 0, 29, 0, 0, 0, 73, 865, NULL, NULL, 0, 0, NULL, -74.44, -52.8524, 37.22, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Arkam XL: Un coche con malware, 16 ejes, un palo y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 73, 866, NULL, NULL, 0, 0, NULL, -28, -28, 14, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Oviode 3: un cubo de basura con un palo, malignas intenciones y un núcleo híbrido.', 0, 6, 0, 0, 0, 73, 867, NULL, NULL, 0, 0, NULL, -48, -45.12, 16, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex nForce Nitro: Un motor con spyware, pantalla Super AMOLED, tecnología digitrónica 4.1 y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 73, 868, NULL, NULL, 0, 0, NULL, -30.75, -30.75, 10.25, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Arkam Pro: &quot;La hostia&quot; con un ambientador de pino.', 0, 0, 0, 0, 0, 73, 869, NULL, NULL, 0, 0, NULL, -86, -86, 43, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo Generator OS: Un procesador con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 73, 870, NULL, NULL, 0, 0, NULL, -54, -54, 18, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Motor XL: Un objeto pequeño d&#39;or con la virginidad intacta.', 0, 0, 0, 0, 0, 73, 871, NULL, NULL, 0, 0, NULL, -1728, -1728, 576, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Oviode II: Un magnetofón con propiedades psicotrópicas, 16 ejes, frenos de berilio y linux.', 0, 0, 0, 0, 0, 73, 872, NULL, NULL, 0, 0, NULL, -36, -36, 18, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Neutro 3', 0, 0, 0, 0, 0, 73, 873, NULL, NULL, 0, 0, NULL, -44, -44, 22, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Giga nForce Nitro: Un coche con:\n- un ambientador de pino\n- faros de xenon\n- chasis de fibra de carbono\n- taladro matricial.', 0, 0, 0, 0, 0, 73, 874, NULL, NULL, 0, 0, NULL, -92, -92, 46, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'FX Proton SE: Un dispositivo tecnológico con memoria HBM, frenos de berilio y 64 núcleos.', 0, 0, 0, 0, 0, 73, 875, NULL, NULL, 0, 0, NULL, -705, -705, 235, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Broken Arkam II', 0, 0, 0, 0, 0, 73, 876, NULL, NULL, 0, 0, NULL, -28, -28, 28, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Labtech II: Un coche con cuernos metálicos, 1024 stream processors, reproductor 4k y un ambientador de pino.', 0, 0, 0, 0, 0, 73, 877, NULL, NULL, 0, 0, NULL, -92.58, -92.58, 46.29, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Arco Pro', 0, 0, 0, 0, 0, 73, 878, NULL, NULL, 0, 0, NULL, -25, -25, 25, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Broken Oviode OS', 0, 0, 0, 0, 0, 73, 879, NULL, NULL, 0, 0, NULL, -5, -5, 5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Tool 3: Un procesador con spyware, propiedades psicotrópicas y un posavasos.', 0, 0, 0, 0, 0, 73, 880, NULL, NULL, 0, 0, NULL, -81, -81, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Arkam II: Un coche con:\n- cuernos metálicos\n- propiedades psicotrópicas\n- spyware\n- faros de xenon.', 0, 0, 0, 0, 0, 73, 881, NULL, NULL, 0, 0, NULL, -36, -36, 12, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Engine XXL: Un motor con un núcleo híbrido, un palo y 8 cilindros en V.', 0, 0, 0, 0, 0, 73, 882, NULL, NULL, 0, 0, NULL, -30.56, -30.56, 30.56, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Oviode 3: Un motor con:\n- propiedades psicotrópicas\n- cuernos metálicos\n- spyware\n- malignas intenciones.', 0, 0, 0, 0, 0, 73, 883, NULL, NULL, 0, 0, NULL, -123, -123, 41, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Labtech XL: Un procesador con taladro matricial.', 0, 0, 0, 0, 0, 73, 884, NULL, NULL, 0, 0, NULL, -85, -85, 42.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Labtech OS', 0, 0, 0, 0, 0, 73, 885, NULL, NULL, 0, 0, NULL, -3, -3, 1, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Motor 3: Un magnetofón con chasis de fibra de carbono, memoria HBM y faros de xenon.', 0, 0, 0, 0, 0, 73, 886, NULL, NULL, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Generator II', 0, 0, 0, 0, 0, 73, 887, NULL, NULL, 0, 0, NULL, -38, -38, 38, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Broken GeForce XP', 0, 0, 0, 0, 0, 73, 888, NULL, NULL, 0, 0, NULL, -34, -34, 34, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Proton II: &quot;La hostia&quot; con memoria HBM.', 0, 0, 0, 0, 0, 73, 889, NULL, NULL, 0, 0, NULL, -27.14, -27.14, 13.57, 0, NULL, NULL, 0, 1, 1),
(-1.1, NULL, 'Pro Proton Nitro: un cubo de basura con:\n- 8 cilindros en V\n- spyware\n- malignas intenciones\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 73, 890, NULL, NULL, 0, 0, NULL, -36.3, -36.3, 33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Generator SE: Un palo con pantalla Super AMOLED, 32 pistones digitales y cuernos metálicos.', 0, 0, 0, 0, 0, 73, 891, NULL, NULL, 0, 0, NULL, -9, -9, 3, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Neutro NX', 0, 0, 0, 0, 0, 73, 892, NULL, NULL, 0, 0, NULL, -41.33, -41.33, 41.33, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Arkam SE: Un coche con:\n- 16 ejes\n- la virginidad intacta\n- 32 pistones digitales\n- Windows Vista.', 0, 0, 0, 0, 0, 73, 893, NULL, NULL, 0, 0, NULL, -41, -41, 41, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi GeForce GTX', 0, 0, 0, 0, 0, 73, 894, NULL, NULL, 0, 0, NULL, -28.88, -28.88, 14.44, 0, NULL, NULL, 0, 1, 1),
(-2.33, NULL, 'Extreme nForce Nitro', 0, 0, 0, 0, 0, 73, 895, NULL, NULL, 0, 0, NULL, -13.98, -13.98, 6, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Radeon 3', 0, 0, 0, 0, 0, 73, 896, NULL, NULL, 0, 0, NULL, -60, -60, 30, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Proton II: un cubo de basura con reproductor 4k, linux y memoria HBM.', 0, 0, 0, 0, 0, 73, 897, NULL, NULL, 0, 0, NULL, -58, -58, 29, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Proton XXL', 0, 0, 0, 0, 0, 73, 898, NULL, NULL, 0, 0, NULL, -7, -7, 7, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken nForce NX: Un dispositivo tecnológico con 8 cilindros en V, Windows Vista, reproductor 4k y linux.', 0, 0, 0, 0, 0, 73, 899, NULL, NULL, 0, 0, NULL, -51, -51, 17, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Box XL: Un magnetofón con un ambientador de pino.', 0, 0, 0, 0, 0, 73, 900, NULL, NULL, 0, 0, NULL, -6, -6, 6, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Labtech XP: Un magnetofón con:\n- linux\n- memoria HBM\n- la virginidad intacta\n- un posavasos.', 0, 0, 0, 0, 0, 73, 901, NULL, NULL, 0, 0, NULL, -44, -44, 22, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Engine XP: Un procesador con un núcleo híbrido, Wifi 4G, la virginidad intacta y memoria HBM.', 0, 0, 0, 0, 0, 73, 902, NULL, NULL, 0, 0, NULL, -19, -19, 19, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Generator Nitro: Un objeto pequeño d&#39;or con Wifi 4G.', 0, 0, 0, 0, 0, 73, 903, NULL, NULL, 0, 0, NULL, -141, -141, 47, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Oviode XP', 0, 0, 0, 0, 0, 73, 904, NULL, NULL, 0, 0, NULL, -46.44, -46.44, 23.22, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Pro Labtech Nitro: Un procesador con la virginidad intacta, un palo y 1024 stream processors.', 0, 28, 0, 0, 0, 73, 905, NULL, NULL, 0, 0, NULL, -99, -71.28, 33, 0, NULL, NULL, 0, 1, 1);
INSERT INTO `lineasalbaranescli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(-3, NULL, 'Extreme Tool OS: Un procesador con 1024 stream processors, malware, linux y Windows Vista.', 0, 14, 0, 0, 0, 73, 906, NULL, NULL, 0, 0, NULL, -145.5, -125.13, 48.5, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Pro Motor SE: Una alcachofa con:\n- taladro matricial\n- linux\n- un palo\n- faros de xenon.', 0, 0, 0, 0, 0, 73, 907, NULL, NULL, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Arco GT: Una targeta gráfica (GPU) con:\n- memoria HBM\n- 32 pistones digitales\n- 1024 stream processors\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 73, 908, NULL, NULL, 0, 0, NULL, -32, -32, 16, 0, NULL, NULL, 0, 1, 1),
(-16, NULL, 'Hiper Arco Nitro', 0, 0, 0, 0, 0, 73, 909, NULL, NULL, 0, 0, NULL, -64, -64, 4, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max GeForce XP: Un palo con un posavasos, frenos de berilio, chasis de fibra de carbono y Wifi 4G.', 0, 0, 0, 0, 0, 73, 910, NULL, NULL, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Super Radeon XL: Un objeto pequeño d&#39;or con un palo, cuernos metálicos y malignas intenciones.', 0, 0, 0, 0, 0, 73, 911, NULL, NULL, 0, 0, NULL, -70, -70, 35, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra nForce GT: Un dispositivo tecnológico con cuernos metálicos.', 0, 0, 0, 0, 0, 73, 912, NULL, NULL, 0, 0, NULL, -147, -147, 49, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Generator SE: Un procesador con 64 núcleos, 32 pistones digitales, chasis de fibra de carbono y frenos de berilio.', 0, 19, 0, 0, 0, 73, 913, NULL, NULL, 0, 0, NULL, -47.25, -38.2725, 47.25, 0, NULL, NULL, 0, 1, 1),
(-1.8, NULL, 'Fusion Arco XXL: Un magnetofón con tecnología digitrónica 4.1, spyware y 32 pistones digitales.', 0, 0, 0, 0, 0, 73, 914, NULL, NULL, 0, 0, NULL, -10.8, -10.8, 6, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Proton SE: Un motor con spyware, linux, propiedades psicotrópicas y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 73, 915, NULL, NULL, 0, 0, NULL, -41, -41, 41, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 73, 916, NULL, NULL, 0, 0, NULL, -200, -200, 100, 0, '2', NULL, 0, 1, 1),
(-1.11, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 73, 917, NULL, NULL, 0, 0, NULL, -133.2, -133.2, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 73, 918, NULL, NULL, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 74, 919, NULL, NULL, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 7, 0, 0, 0, 74, 920, NULL, NULL, 0, 0, NULL, 118.11, 109.8423, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Ultra Station OS: Una alcachofa con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 75, 921, NULL, NULL, 0, 0, NULL, 45, 45, 45, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Motor XP: &quot;La hostia&quot; con:\n- Windows Vista\n- 8 cilindros en V\n- 16 ejes\n- taladro matricial.', 0, 0, 0, 0, 0, 75, 922, NULL, NULL, 0, 0, NULL, 58, 58, 29, 0, NULL, NULL, 0, 1, 1),
(1.7, NULL, 'Pro GeForce GT: Un magnetofón con:\n- un ambientador de pino\n- spyware\n- 8 cilindros en V\n- 1024 stream processors.', 0, 0, 0, 0, 0, 75, 923, NULL, NULL, 0, 0, NULL, 1171.3, 1171.3, 689, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken Proton XL: Una alcachofa con spyware, memoria HBM, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 75, 924, NULL, NULL, 0, 0, NULL, 22, 22, 22, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion Motor SE: Un palo con frenos de berilio, memoria HBM y un posavasos.', 0, 17, 0, 0, 0, 75, 925, NULL, NULL, 0, 0, NULL, 103, 85.49, 103, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken nForce XP: Una targeta gráfica (GPU) con malware, memoria HBM y 1024 stream processors.', 0, 0, 0, 0, 0, 75, 926, NULL, NULL, 0, 0, NULL, 36.71, 36.71, 36.71, 0, NULL, NULL, 0, 1, 1),
(12, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 75, 927, NULL, NULL, 0, 0, NULL, 6000, 6000, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 75, 928, NULL, NULL, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 75, 929, NULL, NULL, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, 'AR0', 'Juan Perez Jr.', 0, 0, 0, 0, 0, 76, 930, NULL, NULL, 0, 0, NULL, 150, 150, 150, 0, '1', NULL, 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasalbaranesprov`
--

CREATE TABLE `lineasalbaranesprov` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `idlineapedido` int(11) DEFAULT NULL,
  `idpedido` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasalbaranesprov`
--

INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`) VALUES
(2, 'AR21', 'Alumno', 0, 0, 1, 1, NULL, NULL, 0, 21, 300, 300, 150, 0, '3', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasfacturascli`
--

CREATE TABLE `lineasfacturascli` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `dtopor2` double NOT NULL DEFAULT '0',
  `dtopor3` double NOT NULL DEFAULT '0',
  `dtopor4` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `idlineaalbaran` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double NOT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `orden` int(11) DEFAULT '0',
  `mostrar_cantidad` tinyint(1) DEFAULT '1',
  `mostrar_precio` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasfacturascli`
--

INSERT INTO `lineasfacturascli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idfactura`, `idlinea`, `idlineaalbaran`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(3, 'AR21', 'cuota mes agosto', 0, 0, 5, 7, 10, NULL, 1, 1, NULL, 0, 21, NULL, 174, 138.3561, 58, 0, NULL, NULL, 0, 1, 1),
(1, 'AR0', 'Juan Perez Jr.', 0, 0, 0, 0, 0, NULL, 2, 2, NULL, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(2, 'AR27', 'Alumno', 0, 0, 0, 0, 0, NULL, 4, 3, NULL, 0, 27, NULL, 300, 300, 150, 0, '3', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, NULL, 5, 4, NULL, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Extreme Proton Nitro: Una targeta gráfica (GPU) con:\n- malignas intenciones\n- Windows Vista\n- la virginidad intacta\n- malware.', 0, 28, 0, 0, 0, 66, 6, 5, 796, 0, 0, NULL, 100.2, 72.144, 33.4, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 66, 6, 6, 797, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(14, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 66, 6, 7, 798, 0, 0, NULL, 7000, 7000, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 66, 6, 8, 799, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 66, 6, 9, 800, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Box XL: Un objeto pequeño d&#39;or con malware, un ambientador de pino, un palo y 8 cilindros en V.', 0, 0, 0, 0, 0, 1, 6, 10, 1, 0, 21, NULL, 147, 147, 49, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Tool II: Un palo con 16 ejes.', 0, 0, 0, 0, 0, 1, 6, 11, 2, 0, 21, NULL, 22, 22, 11, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga GeForce OS: Un dispositivo tecnológico con:\n- malignas intenciones\n- 64 núcleos\n- taladro matricial\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 1, 6, 12, 3, 0, 21, NULL, 1270, 1270, 635, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool SE: &quot;La hostia&quot; con cuernos metálicos.', 0, 0, 0, 0, 0, 1, 6, 13, 4, 0, 21, NULL, 88, 88, 44, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 22, 0, 0, 0, 1, 6, 14, 5, 0, 21, NULL, 500, 390, 500, 0, '4', NULL, 0, 1, 1),
(1.3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 1, 6, 15, 6, 0, 27, NULL, 153.543, 153.543, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 1, 6, 16, 7, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 62, 6, 17, 779, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 62, 6, 18, 780, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2.3, 'AR21', 'Super Oviode XXL: Un motor con:\n- 32 pistones digitales\n- propiedades psicotrópicas\n- 64 núcleos\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 6, 6, 19, 163, 0, 21, NULL, 87.4, 87.4, 38, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega nForce Nitro: un cubo de basura con pantalla Super AMOLED.', 0, 8, 0, 0, 0, 6, 6, 20, 164, 0, 21, NULL, 117, 107.64, 39, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Giga GeForce GTX', 0, 0, 0, 0, 0, 6, 6, 21, 165, 0, 21, NULL, 35, 35, 35, 0, NULL, NULL, 0, 1, 1),
(8, 'AR21', 'Max Oviode SE: Una alcachofa con:\n- malware\n- pantalla Super AMOLED\n- malignas intenciones\n- un palo.', 0, 0, 0, 0, 0, 6, 6, 22, 166, 0, 21, NULL, 4536, 4536, 567, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 12, 0, 0, 0, 6, 6, 23, 167, 0, 0, NULL, 360, 316.8, 120, 0, '1', NULL, 0, 1, 1),
(6, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 6, 6, 24, 168, 0, 21, NULL, 3000, 3000, 500, 0, '4', NULL, 0, 1, 1),
(3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 6, 6, 25, 169, 0, 27, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Sub Labtech GTX: Una alcachofa con linux, memoria HBM, frenos de berilio y Windows Vista.', 0, 0, 0, 0, 0, 49, 6, 26, 699, 0, 0, NULL, 32, 32, 16, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 12, 0, 0, 0, 49, 6, 27, 700, 0, 0, NULL, 236.22, 207.8736, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 49, 6, 28, 701, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 49, 6, 29, 702, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(14, 'AR21', 'Giga Labtech Pro: Un procesador con reproductor 4k, un posavasos, 16 ejes y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 6, 30, 18, 0, 21, NULL, 84, 84, 6, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Fusion Oviode NX: Una targeta gráfica (GPU) con:\n- faros de xenon\n- 16 ejes\n- propiedades psicotrópicas\n- un ambientador de pino.', 0, 0, 0, 0, 0, 4, 6, 31, 19, 0, 21, NULL, 336, 336, 24, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Arco Pro: Un objeto pequeño d&#39;or con:\n- malware\n- faros de xenon\n- cuernos metálicos\n- 8 cilindros en V.', 0, 32, 0, 0, 0, 4, 6, 32, 20, 0, 21, NULL, 38.33, 26.0644, 38.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Hiper Station GTX: Un objeto pequeño d&#39;or con:\n- taladro matricial\n- 8 cilindros en V\n- malware\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 6, 33, 21, 0, 21, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Proton XL: un cubo de basura con malware.', 0, 0, 0, 0, 0, 4, 6, 34, 22, 0, 21, NULL, 78, 78, 26, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Arkam Pro: Un procesador con:\n- 32 pistones digitales\n- pantalla Super AMOLED\n- 8 cilindros en V\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 6, 35, 23, 0, 21, NULL, 41, 41, 41, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'FX Neutro 3: Un objeto pequeño d&#39;or con 8 cilindros en V.', 0, 6, 0, 0, 0, 4, 6, 36, 24, 0, 21, NULL, 93, 87.42, 31, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Proton Nitro', 0, 0, 0, 0, 0, 4, 6, 37, 25, 0, 21, NULL, 72.99, 72.99, 24.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Maxi Engine SE: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 6, 38, 26, 0, 21, NULL, 9, 9, 3, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jex Station Pro: un cubo de basura con malware, taladro matricial, Wifi 4G y frenos de berilio.', 0, 0, 0, 0, 0, 4, 6, 39, 27, 0, 21, NULL, 6, 6, 6, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Giga Labtech GTX: &quot;La hostia&quot; con malignas intenciones, reproductor 4k y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 6, 40, 28, 0, 21, NULL, 11, 11, 11, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Radeon XP: Un motor con:\n- pantalla Super AMOLED\n- un posavasos\n- malware\n- cuernos metálicos.', 0, 27, 0, 0, 0, 4, 6, 41, 29, 0, 21, NULL, 40, 29.2, 40, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Pro Box XP: un cubo de basura con:\n- linux\n- la virginidad intacta\n- cuernos metálicos\n- reproductor 4k.', 0, 0, 0, 0, 0, 4, 6, 42, 30, 0, 21, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator 3: Un palo con memoria HBM.', 0, 0, 0, 0, 0, 4, 6, 43, 31, 0, 21, NULL, 48.14, 48.14, 48.14, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Minga Labtech SE', 0, 20, 0, 0, 0, 4, 6, 44, 32, 0, 21, NULL, 4, 3.2, 4, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Mega Radeon XP: Un motor con linux.', 0, 16, 0, 0, 0, 4, 6, 45, 33, 0, 21, NULL, 62.16, 52.2144, 4.44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Minga Oviode Nitro', 0, 0, 0, 0, 0, 4, 6, 46, 34, 0, 21, NULL, 69.34, 69.34, 34.67, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Arco XL: Un coche con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 6, 47, 35, 0, 21, NULL, 24.8, 24.8, 12.4, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Station XXL: &quot;La hostia&quot; con Wifi 4G, taladro matricial y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 6, 48, 36, 0, 21, NULL, 46, 46, 23, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Neutro OS', 0, 30, 0, 0, 0, 4, 6, 49, 37, 0, 21, NULL, 92, 64.4, 46, 0, NULL, NULL, 0, 1, 1),
(8, 'AR21', 'Max Radeon Pro: &quot;La hostia&quot; con:\n- tecnología digitrónica 4.1\n- propiedades psicotrópicas\n- 16 ejes\n- taladro matricial.', 0, 0, 0, 0, 0, 4, 6, 50, 38, 0, 21, NULL, 392, 392, 49, 0, NULL, NULL, 0, 1, 1),
(1.4, 'AR21', 'Mega Arco Nitro: Un palo con 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 6, 51, 39, 0, 21, NULL, 63, 63, 45, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator 3: Un motor con:\n- taladro matricial\n- la virginidad intacta\n- un núcleo híbrido\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 6, 52, 40, 0, 21, NULL, 43, 43, 43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Sub Labtech OS', 0, 0, 0, 0, 0, 4, 6, 53, 41, 0, 21, NULL, 141, 141, 47, 0, NULL, NULL, 0, 1, 1),
(7, 'AR21', 'Fusion Engine XXL: Un magnetofón con Wifi 4G, un ambientador de pino y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 6, 54, 42, 0, 21, NULL, 14, 14, 2, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Minga Radeon II: Un coche con 1024 stream processors, spyware, cuernos metálicos y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 6, 55, 43, 0, 21, NULL, 6, 6, 2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Minga Tool Nitro: Un dispositivo tecnológico con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 6, 56, 44, 0, 21, NULL, 29.56, 29.56, 29.56, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Box NX: &quot;La hostia&quot; con la virginidad intacta, 16 ejes y 64 núcleos.', 0, 0, 0, 0, 0, 4, 6, 57, 45, 0, 21, NULL, 39.33, 39.33, 39.33, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Ultra Station OS: Un motor con un palo.', 0, 0, 0, 0, 0, 4, 6, 58, 46, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jet GeForce Nitro', 0, 6.667, 0, 0, 0, 4, 6, 59, 47, 0, 21, NULL, 80.49, 75.1237317, 26.83, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Engine 3: Una alcachofa con 8 cilindros en V.', 0, 5, 0, 0, 0, 4, 6, 60, 48, 0, 21, NULL, 54.66, 51.927, 27.33, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Motor OS: Un palo con malignas intenciones.', 0, 0, 0, 0, 0, 4, 6, 61, 49, 0, 21, NULL, 48, 48, 24, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Hiper Box GT: Un coche con 64 núcleos, 8 cilindros en V, la virginidad intacta y taladro matricial.', 0, 0, 0, 0, 0, 4, 6, 62, 50, 0, 21, NULL, 53.14, 53.14, 26.57, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Proton GTX: &quot;La hostia&quot; con cuernos metálicos, tecnología digitrónica 4.1, propiedades psicotrópicas y 1024 stream processors.', 0, 0, 0, 0, 0, 4, 6, 63, 51, 0, 21, NULL, 54.6, 54.6, 18.2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Fusion Motor GTX: Un procesador con spyware, cuernos metálicos, 16 ejes y 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 6, 64, 52, 0, 21, NULL, 68, 68, 34, 0, NULL, NULL, 0, 1, 1),
(11, 'AR21', 'Maxi Box Nitro: &quot;La hostia&quot; con malware.', 0, 0, 0, 0, 0, 4, 6, 65, 53, 0, 21, NULL, 539, 539, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jet Station XL: Un motor con pantalla Super AMOLED, la virginidad intacta, chasis de fibra de carbono y 16 ejes.', 0, 0, 0, 0, 0, 4, 6, 66, 54, 0, 21, NULL, 7.4, 7.4, 7.4, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Box XXL: Un objeto pequeño d&#39;or con reproductor 4k, 32 pistones digitales y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 6, 67, 55, 0, 21, NULL, 30, 30, 30, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Minga Box OS: Un motor con un ambientador de pino.', 0, 0, 0, 0, 0, 4, 6, 68, 56, 0, 21, NULL, 16, 16, 8, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Generator XP: Un coche con:\n- pantalla Super AMOLED\n- faros de xenon\n- 16 ejes\n- linux.', 0, 0, 0, 0, 0, 4, 6, 69, 57, 0, 21, NULL, 8, 8, 8, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Sub Generator OS', 0, 98, 0, 0, 0, 4, 6, 70, 58, 0, 21, NULL, 57.26, 1.1452, 28.63, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Box SE: un cubo de basura con:\n- 8 cilindros en V\n- un núcleo híbrido\n- reproductor 4k\n- Wifi 4G.', 0, 0, 0, 0, 0, 4, 6, 71, 59, 0, 21, NULL, 72.86, 72.86, 36.43, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme nForce Nitro: Un motor con Windows Vista.', 0, 0, 0, 0, 0, 4, 6, 72, 60, 0, 21, NULL, 14.25, 14.25, 14.25, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Jex Box Pro', 0, 9, 0, 0, 0, 4, 6, 73, 61, 0, 21, NULL, 460, 418.6, 230, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Arkam NX: Un coche con propiedades psicotrópicas, 8 cilindros en V, spyware y 64 núcleos.', 0, 23, 0, 0, 0, 4, 6, 74, 62, 0, 21, NULL, 1074, 826.98, 358, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX nForce Nitro: Un palo con chasis de fibra de carbono, pantalla Super AMOLED y un ambientador de pino.', 0, 0, 0, 0, 0, 4, 6, 75, 63, 0, 21, NULL, 68.86, 68.86, 34.43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Minga nForce XL', 0, 27, 0, 0, 0, 4, 6, 76, 64, 0, 21, NULL, 117.51, 85.7823, 39.17, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion nForce XL: Un palo con un ambientador de pino, linux, tecnología digitrónica 4.1 y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 6, 77, 65, 0, 21, NULL, 15.99, 15.99, 5.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Generator Pro', 0, 0, 0, 0, 0, 4, 6, 78, 66, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega Generator XL: Una targeta gráfica (GPU) con 16 ejes.', 0, 31, 0, 0, 0, 4, 6, 79, 67, 0, 21, NULL, 39, 26.91, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Max Tool Nitro', 0, 0, 0, 0, 0, 4, 6, 80, 68, 0, 21, NULL, 592, 592, 592, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Engine GT', 0, 0, 0, 0, 0, 4, 6, 81, 69, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool GTX: Un dispositivo tecnológico con chasis de fibra de carbono, faros de xenon y Windows Vista.', 0, 0, 0, 0, 0, 4, 6, 82, 70, 0, 21, NULL, 38, 38, 19, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi Arco 3', 0, 0, 0, 0, 0, 4, 6, 83, 71, 0, 21, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega nForce Nitro: Una alcachofa con:\n- Wifi 4G\n- frenos de berilio\n- 8 cilindros en V\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 6, 84, 72, 0, 21, NULL, 46, 46, 23, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi Proton GT: Un palo con Wifi 4G, 16 ejes y tecnología digitrónica 4.1.', 0, 10, 0, 0, 0, 4, 6, 85, 73, 0, 21, NULL, 410, 369, 410, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Generator GT: Un motor con:\n- spyware\n- malignas intenciones\n- 64 núcleos\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 6, 86, 74, 0, 21, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Neutro SE: Una alcachofa con un palo.', 0, 12, 0, 0, 0, 4, 6, 87, 75, 0, 21, NULL, 46, 40.48, 46, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Sub Tool Pro', 0, 0, 0, 0, 0, 4, 6, 88, 76, 0, 21, NULL, 43.8, 43.8, 14.6, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Neutro 3', 0, 0, 0, 0, 0, 4, 6, 89, 77, 0, 21, NULL, 111.87, 111.87, 37.29, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Generator XL', 0, 0, 0, 0, 0, 4, 6, 90, 78, 0, 21, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Tool Pro: Un objeto pequeño d&#39;or con:\n- taladro matricial\n- un palo\n- faros de xenon\n- Wifi 4G.', 0, 15, 0, 0, 0, 4, 6, 91, 79, 0, 21, NULL, 385, 327.25, 385, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Station 3: Un motor con:\n- pantalla Super AMOLED\n- faros de xenon\n- reproductor 4k\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 6, 92, 80, 0, 21, NULL, 6, 6, 2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi GeForce GTX: Un magnetofón con:\n- taladro matricial\n- 64 núcleos\n- un núcleo híbrido\n- la virginidad intacta.', 0, 0, 0, 0, 0, 4, 6, 93, 81, 0, 21, NULL, 8.5, 8.5, 4.25, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Tool Nitro: Una alcachofa con cuernos metálicos, memoria HBM, Windows Vista y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 6, 94, 82, 0, 21, NULL, 51, 51, 17, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega nForce Nitro: Un palo con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 6, 95, 83, 0, 21, NULL, 4, 4, 2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Neo Radeon GT: Un palo con 64 núcleos.', 0, 0, 0, 0, 0, 4, 6, 96, 84, 0, 21, NULL, 13, 13, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Max nForce II: un cubo de basura con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 6, 97, 85, 0, 21, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme GeForce NX: Un magnetofón con:\n- propiedades psicotrópicas\n- 16 ejes\n- linux\n- 64 núcleos.', 0, 0, 0, 0, 0, 4, 6, 98, 86, 0, 21, NULL, 20, 20, 20, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Mega Box Nitro: Una alcachofa con Windows Vista, 32 pistones digitales, spyware y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 6, 99, 87, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Generator Pro: Un palo con 1024 stream processors, 8 cilindros en V, memoria HBM y reproductor 4k.', 0, 0, 0, 0, 0, 4, 6, 100, 88, 0, 21, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Oviode NX: Un dispositivo tecnológico con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 6, 101, 89, 0, 21, NULL, 94, 94, 47, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Super Arkam XXL: Una targeta gráfica (GPU) con Windows Vista.', 0, 22.29, 0, 0, 0, 4, 6, 102, 90, 0, 21, NULL, 15.57, 12.099447, 15.57, 0, NULL, NULL, 0, 1, 1),
(14, 'AR21', 'Max GeForce 3: Un coche con cuernos metálicos.', 0, 0, 0, 0, 0, 4, 6, 103, 91, 0, 21, NULL, 392, 392, 28, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'FX Station II: Un motor con 1024 stream processors, propiedades psicotrópicas, faros de xenon y memoria HBM.', 0, 0, 0, 0, 0, 4, 6, 104, 92, 0, 21, NULL, 3, 3, 3, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Motor NX: Un objeto pequeño d&#39;or con 16 ejes, taladro matricial, cuernos metálicos y malware.', 0, 0, 0, 0, 0, 4, 6, 105, 93, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Pro Radeon Nitro: Un dispositivo tecnológico con:\n- Wifi 4G\n- linux\n- 32 pistones digitales\n- chasis de fibra de carbono.', 0, 15, 0, 0, 0, 4, 6, 106, 94, 0, 21, NULL, 225, 191.25, 45, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Tool GTX: Un magnetofón con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 4, 6, 107, 95, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Ultra Arkam OS: Un objeto pequeño d&#39;or con un ambientador de pino, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 4, 6, 108, 96, 0, 21, NULL, 40.1, 40.1, 40.1, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jet Oviode OS: &quot;La hostia&quot; con:\n- la virginidad intacta\n- frenos de berilio\n- 16 ejes\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 6, 109, 97, 0, 21, NULL, 129, 129, 43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Max Neutro II: Un dispositivo tecnológico con un posavasos.', 0, 0, 0, 0, 0, 4, 6, 110, 98, 0, 21, NULL, 66, 66, 22, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Maxi GeForce XP: Un objeto pequeño d&#39;or con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 4, 6, 111, 99, 0, 21, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Jet Arco Pro: Una targeta gráfica (GPU) con 32 pistones digitales, un ambientador de pino, cuernos metálicos y faros de xenon.', 0, 0, 0, 0, 0, 4, 6, 112, 100, 0, 21, NULL, 20.8, 20.8, 20.8, 0, NULL, NULL, 0, 1, 1),
(19, 'AR21', 'Sub Motor SE', 0, 9, 0, 0, 0, 4, 6, 113, 101, 0, 21, NULL, 4940, 4495.4, 260, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Generator II: Un motor con:\n- cuernos metálicos\n- un palo\n- malignas intenciones\n- taladro matricial.', 0, 0, 0, 0, 0, 4, 6, 114, 102, 0, 21, NULL, 58.29, 58.29, 19.43, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Station 3: Un procesador con reproductor 4k, malware, chasis de fibra de carbono y 64 núcleos.', 0, 0, 0, 0, 0, 4, 6, 115, 103, 0, 21, NULL, 21.75, 21.75, 7.25, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Arco GTX', 0, 17, 0, 0, 0, 4, 6, 116, 104, 0, 21, NULL, 1914, 1588.62, 638, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'FX Neutro XL: Un procesador con reproductor 4k.', 0, 0, 0, 0, 0, 4, 6, 117, 105, 0, 21, NULL, 42, 42, 21, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Motor GTX: Un magnetofón con Wifi 4G, 8 cilindros en V y un núcleo híbrido.', 0, 34, 0, 0, 0, 4, 6, 118, 106, 0, 21, NULL, 94, 62.04, 47, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'FX Box GTX: Un objeto pequeño d&#39;or con frenos de berilio, pantalla Super AMOLED y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 6, 119, 107, 0, 21, NULL, 30, 30, 10, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Station Pro: Una targeta gráfica (GPU) con reproductor 4k, frenos de berilio y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 6, 120, 108, 0, 21, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Fusion Engine GT', 0, 0, 0, 0, 0, 4, 6, 121, 109, 0, 21, NULL, 42, 42, 21, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Hiper Box 3: Un procesador con malignas intenciones, Windows Vista y Wifi 4G.', 0, 0, 0, 0, 0, 4, 6, 122, 110, 0, 21, NULL, 2.22, 2.22, 1.11, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Hiper Station NX', 0, 0, 0, 0, 0, 4, 6, 123, 111, 0, 21, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Max Labtech GTX: Un objeto pequeño d&#39;or con malware, la virginidad intacta, propiedades psicotrópicas y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 6, 124, 112, 0, 21, NULL, 95, 95, 19, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Max Labtech GT', 0, 0, 0, 0, 0, 4, 6, 125, 113, 0, 21, NULL, 102.66, 102.66, 34.22, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Neo Generator XXL', 0, 0, 0, 0, 0, 4, 6, 126, 114, 0, 21, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Extreme Motor XP: Una alcachofa con taladro matricial, 32 pistones digitales y un palo.', 0, 0, 0, 0, 0, 4, 6, 127, 115, 0, 21, NULL, 7, 7, 7, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Sub Labtech XL: Un objeto pequeño d&#39;or con:\n- spyware\n- 64 núcleos\n- la virginidad intacta\n- 1024 stream processors.', 0, 19, 0, 0, 0, 4, 6, 128, 116, 0, 21, NULL, 31.71, 25.6851, 31.71, 0, NULL, NULL, 0, 1, 1),
(12, 'AR21', 'Hiper Oviode Nitro: un cubo de basura con faros de xenon.', 0, 0, 0, 0, 0, 4, 6, 129, 117, 0, 21, NULL, 585.6, 585.6, 48.8, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Ultra Radeon OS: Un procesador con 8 cilindros en V, linux y 1024 stream processors.', 0, 18, 0, 0, 0, 4, 6, 130, 118, 0, 21, NULL, 75, 61.5, 25, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Neo Labtech XP: un cubo de basura con malignas intenciones.', 0, 0, 0, 0, 0, 4, 6, 131, 119, 0, 21, NULL, 44.4, 44.4, 22.2, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Arkam GTX: Un procesador con la virginidad intacta, linux y 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 6, 132, 120, 0, 21, NULL, 46.57, 46.57, 46.57, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Jex Motor XP: Un dispositivo tecnológico con reproductor 4k, faros de xenon y taladro matricial.', 0, 22, 0, 0, 0, 4, 6, 133, 121, 0, 21, NULL, 23.01, 17.9478, 7.67, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Fusion Motor GTX: Un magnetofón con un ambientador de pino.', 0, 0, 0, 0, 0, 4, 6, 134, 122, 0, 21, NULL, 1335, 1335, 445, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Super Neutro Nitro: Un dispositivo tecnológico con 32 pistones digitales.', 0, 0, 0, 0, 0, 4, 6, 135, 123, 0, 21, NULL, 147, 147, 49, 0, NULL, NULL, 0, 1, 1),
(15, 'AR21', 'Ultra Engine NX', 0, 0, 0, 0, 0, 4, 6, 136, 124, 0, 21, NULL, 263.4, 263.4, 17.56, 0, NULL, NULL, 0, 1, 1),
(2.5, 'AR21', 'Minga nForce XXL: Una targeta gráfica (GPU) con:\n- spyware\n- la virginidad intacta\n- Wifi 4G\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 4, 6, 137, 125, 0, 21, NULL, 70, 70, 28, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Generator OS: un cubo de basura con:\n- pantalla Super AMOLED\n- linux\n- 8 cilindros en V\n- reproductor 4k.', 0, 0, 0, 0, 0, 4, 6, 138, 126, 0, 21, NULL, 48, 48, 16, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Pro Generator OS: Un dispositivo tecnológico con:\n- taladro matricial\n- 64 núcleos\n- cuernos metálicos\n- malignas intenciones.', 0, 0, 0, 0, 0, 4, 6, 139, 127, 0, 21, NULL, 310, 310, 310, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga Motor XP: Una targeta gráfica (GPU) con un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 6, 140, 128, 0, 21, NULL, 82, 82, 41, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Max Arco OS: Un palo con:\n- Wifi 4G\n- 8 cilindros en V\n- spyware\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 4, 6, 141, 129, 0, 21, NULL, 74, 74, 37, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Maxi Arco XXL: &quot;La hostia&quot; con faros de xenon, Wifi 4G, frenos de berilio y un núcleo híbrido.', 0, 0, 0, 0, 0, 4, 6, 142, 130, 0, 21, NULL, 70, 70, 35, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Pro Generator SE: Un motor con faros de xenon.', 0, 0, 0, 0, 0, 4, 6, 143, 131, 0, 21, NULL, 36, 36, 12, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Extreme Motor Pro: Un motor con frenos de berilio, un palo, 1024 stream processors y la virginidad intacta.', 0, 0, 0, 0, 0, 4, 6, 144, 132, 0, 21, NULL, 24, 24, 8, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Giga nForce GTX: Un magnetofón con memoria HBM, propiedades psicotrópicas, tecnología digitrónica 4.1 y Windows Vista.', 0, 21, 0, 0, 0, 4, 6, 145, 133, 0, 21, NULL, 4, 3.16, 2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Motor GTX: Un objeto pequeño d&#39;or con un posavasos.', 0, 0, 0, 0, 0, 4, 6, 146, 134, 0, 21, NULL, 64.44, 64.44, 32.22, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Labtech GTX: Un procesador con Windows Vista, frenos de berilio y un palo.', 0, 7, 0, 0, 0, 4, 6, 147, 135, 0, 21, NULL, 68, 63.24, 34, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Box XL: Un palo con linux.', 0, 0, 0, 0, 0, 4, 6, 148, 136, 0, 21, NULL, 12, 12, 6, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Oviode GT: Un procesador con:\n- chasis de fibra de carbono\n- cuernos metálicos\n- taladro matricial\n- 64 núcleos.', 0, 7, 0, 0, 0, 4, 6, 149, 137, 0, 21, NULL, 80, 74.4, 40, 0, NULL, NULL, 0, 1, 1),
(5, 'AR21', 'Jet Arco Pro', 0, 0, 0, 0, 0, 4, 6, 150, 138, 0, 21, NULL, 145, 145, 29, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Extreme Arco Nitro: Un procesador con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 6, 151, 139, 0, 21, NULL, 12.66, 12.66, 6.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Neo Neutro Pro: Un procesador con pantalla Super AMOLED, 1024 stream processors y taladro matricial.', 0, 0, 0, 0, 0, 4, 6, 152, 140, 0, 21, NULL, 1275, 1275, 425, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Max Tool XXL: Un dispositivo tecnológico con 1024 stream processors.', 0, 0, 0, 0, 0, 4, 6, 153, 141, 0, 21, NULL, 66.5, 66.5, 33.25, 0, NULL, NULL, 0, 1, 1),
(4, 'AR21', 'Jet Labtech II: Un procesador con 64 núcleos, 1024 stream processors y taladro matricial.', 0, 0, 0, 0, 0, 4, 6, 154, 142, 0, 21, NULL, 44, 44, 11, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Fusion Motor XP', 0, 58, 0, 0, 0, 4, 6, 155, 143, 0, 21, NULL, 39, 16.38, 39, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Giga Neutro GTX: Una alcachofa con Wifi 4G, un ambientador de pino y Windows Vista.', 0, 1, 0, 0, 0, 4, 6, 156, 144, 0, 21, NULL, 129, 127.71, 43, 0, NULL, NULL, 0, 1, 1),
(1, 'AR21', 'Super Tool SE: Un magnetofón con 8 cilindros en V, spyware, malignas intenciones y pantalla Super AMOLED.', 0, 7, 0, 0, 0, 4, 6, 157, 145, 0, 21, NULL, 28.33, 26.3469, 28.33, 0, NULL, NULL, 0, 1, 1),
(3, 'AR21', 'Mega Proton SE: Un dispositivo tecnológico con malignas intenciones, pantalla Super AMOLED y chasis de fibra de carbono.', 0, 18, 0, 0, 0, 4, 6, 158, 146, 0, 21, NULL, 108, 88.56, 36, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Engine Nitro: Un motor con 16 ejes, un núcleo híbrido y un ambientador de pino.', 0, 0, 0, 0, 0, 4, 6, 159, 147, 0, 21, NULL, 60, 60, 30, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Pro Tool 3: &quot;La hostia&quot; con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 4, 6, 160, 148, 0, 21, NULL, 862, 862, 431, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Mega Arkam NX: Un dispositivo tecnológico con un posavasos, 16 ejes y un ambientador de pino.', 0, 5, 0, 0, 0, 4, 6, 161, 149, 0, 21, NULL, 36, 34.2, 18, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 4, 6, 162, 150, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 4, 6, 163, 151, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 4, 6, 164, 152, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(-1, NULL, 'FX Engine SE: Un coche con frenos de berilio.', 0, 0, 0, 0, 0, 44, 6, 165, 666, 0, 0, NULL, -37, -37, 37, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Oviode OS: Un coche con chasis de fibra de carbono, reproductor 4k, malware y faros de xenon.', 0, 0, 0, 0, 0, 44, 6, 166, 667, 0, 0, NULL, -42, -42, 14, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Oviode OS', 0, 0, 0, 0, 0, 44, 6, 167, 668, 0, 0, NULL, -20, -20, 10, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 44, 6, 168, 669, 0, 0, NULL, -1500, -1500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 44, 6, 169, 670, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 44, 6, 170, 671, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 36, 6, 171, 625, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'Alumno', 0, 0, 0, 0, 0, 36, 6, 172, 626, 0, 0, NULL, -236.22, -236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 48, 6, 173, 696, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 48, 6, 174, 697, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 48, 6, 175, 698, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'FX nForce 3: Un magnetofón con un posavasos.', 0, 0, 0, 0, 0, 46, 6, 176, 680, 0, 0, NULL, -124.5, -124.5, 41.5, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Giga Tool XL: Una alcachofa con un ambientador de pino.', 0, 0, 0, 0, 0, 46, 6, 177, 681, 0, 0, NULL, -1016, -1016, 508, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 46, 6, 178, 682, 0, 0, NULL, -100, -100, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 46, 6, 179, 683, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 46, 6, 180, 684, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 46, 6, 181, 685, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 59, 6, 182, 763, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 19, 0, 0, 0, 59, 6, 183, 764, 0, 0, NULL, 300, 243, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 59, 6, 184, 765, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 41, 6, 185, 646, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 41, 6, 186, 650, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-1, NULL, 'Fusion Box GTX: Un dispositivo tecnológico con 8 cilindros en V.', 0, 0, 0, 0, 0, 28, 6, 187, 523, 0, 0, NULL, -39, -39, 39, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Motor OS: Un procesador con spyware.', 0, 0, 0, 0, 0, 28, 6, 188, 525, 0, 0, NULL, -21, -21, 21, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jex Radeon Nitro', 0, 6, 0, 0, 0, 28, 6, 189, 527, 0, 0, NULL, -90, -84.6, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo nForce Nitro: un cubo de basura con 64 núcleos, un posavasos y spyware.', 0, 17, 0, 0, 0, 28, 6, 190, 529, 0, 0, NULL, -39, -32.37, 13, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 2, 0, 0, 0, 28, 6, 191, 531, 0, 0, NULL, -240, -235.2, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Alumno', 0, 0, 0, 0, 0, 28, 6, 192, 535, 0, 0, NULL, -118.11, -118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 28, 6, 193, 537, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-1, 'AR21', 'Neo Radeon 3: Un procesador con:\n- taladro matricial\n- linux\n- 1024 stream processors\n- reproductor 4k.', 0, 0, 0, 0, 0, 3, 6, 194, 12, 0, 21, NULL, -126, -126, 126, 0, NULL, NULL, 0, 1, 1),
(-16, 'AR21', 'Maxi Arkam GTX: Un magnetofón con frenos de berilio.', 0, 0, 0, 0, 0, 3, 6, 195, 13, 0, 21, NULL, -768, -768, 48, 0, NULL, NULL, 0, 1, 1),
(-2, 'AR21', 'Sub GeForce OS: Un motor con malignas intenciones, un palo y linux.', 0, 0, 0, 0, 0, 3, 6, 196, 14, 0, 21, NULL, -60, -60, 30, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 3, 6, 197, 15, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-1, NULL, 'Juan Perez Jr.', 0, 32, 0, 0, 0, 3, 6, 198, 16, 0, 0, NULL, -120, -81.6, 120, 0, '1', NULL, 0, 1, 1),
(-2, 'AR21', 'Matias Carrizo', 0, 25, 0, 0, 0, 3, 6, 199, 17, 0, 21, NULL, -1000, -750, 500, 0, '4', NULL, 0, 1, 1),
(-2, NULL, 'Minga Arkam XP: Un dispositivo tecnológico con:\n- memoria HBM\n- cuernos metálicos\n- un palo\n- 16 ejes.', 0, 0, 0, 0, 0, 19, 6, 200, 370, 0, 0, NULL, -32, -32, 16, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion nForce OS: Un dispositivo tecnológico con:\n- malware\n- 64 núcleos\n- un posavasos\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 19, 6, 201, 371, 0, 0, NULL, -286, -286, 286, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Sub Neutro OS', 0, 0, 0, 0, 0, 19, 6, 202, 373, 0, 0, NULL, -91.5, -91.5, 30.5, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Neutro GTX: Un objeto pequeño d&#39;or con cuernos metálicos.', 0, 0, 0, 0, 0, 19, 6, 203, 374, 0, 0, NULL, -19.13, -19.13, 19.13, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'FX Engine SE: Un coche con frenos de berilio, un palo y Windows Vista.', 0, 0, 0, 0, 0, 19, 6, 204, 375, 0, 0, NULL, -136, -136, 68, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet Oviode OS: Un coche con chasis de fibra de carbono, reproductor 4k y malware.', 0, 33, 0, 0, 0, 19, 6, 205, 377, 0, 0, NULL, -39, -26.13, 39, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Oviode OS: Un objeto pequeño d&#39;or con reproductor 4k, un palo, un posavasos y frenos de berilio.', 0, 0, 0, 0, 0, 19, 6, 206, 378, 0, 0, NULL, -40, -40, 40, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 19, 6, 207, 379, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-5, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 19, 6, 208, 380, 0, 0, NULL, -500, -500, 100, 0, '2', NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 19, 6, 209, 382, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Minga Proton XP: Un magnetofón con un palo, malware y 16 ejes.', 0, 0, 0, 0, 0, 24, 6, 210, 408, 0, 0, NULL, 35, 35, 17.5, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet nForce NX: Un magnetofón con un posavasos.', 0, 15, 0, 0, 0, 24, 6, 211, 410, 0, 0, NULL, 1010, 858.5, 505, 0, NULL, NULL, 0, 1, 1),
(13, NULL, 'Super Neutro XXL: &quot;La hostia&quot; con Windows Vista, spyware, pantalla Super AMOLED y linux.', 0, 0, 0, 0, 0, 24, 6, 212, 412, 0, 0, NULL, 242.71, 242.71, 18.67, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo nForce NX', 0, 8, 0, 0, 0, 24, 6, 213, 414, 0, 0, NULL, 4, 3.68, 2, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Generator XL: Una targeta gráfica (GPU) con un ambientador de pino, Windows Vista y frenos de berilio.', 0, 0, 0, 0, 0, 24, 6, 214, 415, 0, 0, NULL, 84.87, 84.87, 28.29, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Sub Engine XL', 0, 10.4, 0, 0, 0, 24, 6, 215, 417, 0, 0, NULL, 5.11, 4.57856, 5.11, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'Extreme Engine 3: Una targeta gráfica (GPU) con tecnología digitrónica 4.1, malignas intenciones, 8 cilindros en V y 32 pistones digitales.', 0, 12, 0, 0, 0, 24, 6, 216, 419, 0, 0, NULL, 121.98, 107.3424, 20.33, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 24, 6, 217, 421, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 14, 0, 0, 0, 24, 6, 218, 425, 0, 0, NULL, 360, 309.6, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 24, 6, 219, 429, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1.5, NULL, 'Minga Labtech II', 0, 62, 0, 0, 0, 72, 6, 220, 835, 0, 0, NULL, 53.07, 20.1666, 35.38, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 28, 0, 0, 0, 72, 6, 221, 836, 0, 0, NULL, 354.33, 255.1176, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 72, 6, 222, 837, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 72, 6, 223, 838, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'FX Tool 3: Un objeto pequeño d&#39;or con malignas intenciones.', 0, 0, 0, 0, 0, 69, 6, 224, 812, 0, 0, NULL, 64, 64, 32, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Neo Neutro SE: Una alcachofa con un núcleo híbrido, propiedades psicotrópicas, 16 ejes y frenos de berilio.', 0, 0, 0, 0, 0, 69, 6, 225, 813, 0, 0, NULL, 6, 6, 6, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'FX nForce Nitro: Un dispositivo tecnológico con reproductor 4k, memoria HBM, un posavasos y 8 cilindros en V.', 0, 0, 0, 0, 0, 69, 6, 226, 814, 0, 0, NULL, 51, 51, 17, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo Generator SE: Una alcachofa con:\n- faros de xenon\n- un ambientador de pino\n- malignas intenciones\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 69, 6, 227, 815, 0, 0, NULL, 52, 52, 26, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'Jex Arco XL: Un objeto pequeño d&#39;or con Wifi 4G, 64 núcleos, un ambientador de pino y memoria HBM.', 0, 25, 0, 0, 0, 69, 6, 228, 816, 0, 0, NULL, 100, 75, 40, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Labtech Pro: Un motor con:\n- spyware\n- tecnología digitrónica 4.1\n- un posavasos\n- frenos de berilio.', 0, 0, 0, 0, 0, 69, 6, 229, 817, 0, 0, NULL, 78, 78, 39, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 69, 6, 230, 818, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 69, 6, 231, 819, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 69, 6, 232, 820, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR105', 'Maxi Station GTX: Un objeto pequeño d&#39;or con:\n- 8 cilindros en V\n- un ambientador de pino\n- la virginidad intacta\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 54, 6, 233, 729, 0, 10.5, NULL, 24, 24, 24, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Jex Labtech SE: Un procesador con 32 pistones digitales, malignas intenciones, Windows Vista y 1024 stream processors.', 0, 0, 0, 0, 0, 54, 6, 234, 730, 0, 10.5, NULL, 67.5, 67.5, 22.5, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Broken Engine NX: Un magnetofón con:\n- Windows Vista\n- 1024 stream processors\n- memoria HBM\n- la virginidad intacta.', 0, 32, 0, 0, 0, 54, 6, 235, 731, 0, 10.5, NULL, 26, 17.68, 13, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Ultra nForce Pro', 0, 0, 0, 0, 0, 54, 6, 236, 732, 0, 10.5, NULL, 1.14, 1.14, 1.14, 0, NULL, NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 54, 6, 237, 733, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(5, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 54, 6, 238, 734, 0, 0, NULL, 500, 500, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 54, 6, 239, 735, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, 'AR105', 'Broken Station GT', 0, 0, 0, 0, 0, 57, 6, 240, 753, 0, 10.5, NULL, 21, 21, 7, 0, NULL, NULL, 0, 1, 1),
(15, 'AR105', 'Maxi Generator Pro: Un coche con:\n- un ambientador de pino\n- malware\n- taladro matricial\n- un posavasos.', 0, 3, 0, 0, 0, 57, 6, 241, 754, 0, 10.5, NULL, 346.5, 336.105, 23.1, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 57, 6, 242, 755, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 31, 0, 0, 0, 57, 6, 243, 756, 0, 0, NULL, 300, 207, 100, 0, '2', NULL, 0, 1, 1),
(3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 57, 6, 244, 757, 0, 27, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'FX Neutro GTX: Una targeta gráfica (GPU) con:\n- la virginidad intacta\n- chasis de fibra de carbono\n- 8 cilindros en V\n- un ambientador de pino.', 0, 1, 0, 0, 0, 65, 7, 245, 792, 0, 0, NULL, 844, 835.56, 422, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 65, 7, 246, 793, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 65, 7, 247, 794, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 65, 7, 248, 795, 0, 0, NULL, 240, 240, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Jex Arkam XP: Un objeto pequeño d&#39;or con 1024 stream processors, spyware, frenos de berilio y 32 pistones digitales.', 0, 0, 0, 0, 0, 43, 7, 249, 655, 0, 0, NULL, 22.76, 22.76, 11.38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Broken Generator SE: &quot;La hostia&quot; con un palo, tecnología digitrónica 4.1 y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 43, 7, 250, 657, 0, 0, NULL, 22.86, 22.86, 11.43, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Neo Box 3: Una alcachofa con un ambientador de pino, reproductor 4k y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 43, 7, 251, 658, 0, 0, NULL, 145.68, 145.68, 48.56, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Arkam SE: Una alcachofa con un palo, un ambientador de pino y 1024 stream processors.', 0, 0, 0, 0, 0, 43, 7, 252, 659, 0, 0, NULL, 3, 3, 1, 0, NULL, NULL, 0, 1, 1),
(1.1, NULL, 'Super Labtech NX: Una targeta gráfica (GPU) con Wifi 4G, malignas intenciones y taladro matricial.', 0, 0, 0, 0, 0, 43, 7, 253, 661, 0, 0, NULL, 30.8, 30.8, 28, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 43, 7, 254, 663, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 43, 7, 255, 664, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 43, 7, 256, 665, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Fusion Station XL: &quot;La hostia&quot; con:\n- taladro matricial\n- pantalla Super AMOLED\n- 64 núcleos\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 64, 7, 257, 783, 0, 0, NULL, 10, 10, 10, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet nForce II: Un magnetofón con pantalla Super AMOLED.', 0, 0, 0, 0, 0, 64, 7, 258, 784, 0, 0, NULL, 24.66, 24.66, 12.33, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'Super Labtech OS: Un procesador con:\n- pantalla Super AMOLED\n- 1024 stream processors\n- faros de xenon\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 64, 7, 259, 785, 0, 0, NULL, 17.5, 17.5, 7, 0, NULL, NULL, 0, 1, 1),
(1.5, NULL, 'FX Radeon II', 0, 0, 0, 0, 0, 64, 7, 260, 786, 0, 0, NULL, 51, 51, 34, 0, NULL, NULL, 0, 1, 1),
(6, NULL, 'Extreme Neutro NX: Un motor con un núcleo híbrido, Wifi 4G, 64 núcleos y malignas intenciones.', 0, 30, 0, 0, 0, 64, 7, 261, 787, 0, 0, NULL, 240, 168, 40, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super nForce XXL: un cubo de basura con la virginidad intacta, Windows Vista y cuernos metálicos.', 0, 24, 0, 0, 0, 64, 7, 262, 788, 0, 0, NULL, 147, 111.72, 49, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 24, 0, 0, 0, 64, 7, 263, 789, 0, 0, NULL, 1000, 760, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 64, 7, 264, 790, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 64, 7, 265, 791, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Jex Arkam OS', 0, 0, 0, 0, 0, 38, 7, 266, 631, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 38, 7, 267, 632, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 38, 7, 268, 633, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 38, 7, 269, 634, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Pro Engine 3: Un palo con cuernos metálicos, 64 núcleos y malignas intenciones.', 0, 0, 0, 0, 0, 70, 7, 270, 821, 0, 0, NULL, 17, 17, 17, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Maxi Engine XXL: Una alcachofa con propiedades psicotrópicas, un posavasos, 16 ejes y malignas intenciones.', 0, 0, 0, 0, 0, 70, 7, 271, 822, 0, 0, NULL, 86, 86, 43, 0, NULL, NULL, 0, 1, 1),
(5, NULL, 'Extreme GeForce XXL: &quot;La hostia&quot; con reproductor 4k, Windows Vista, un núcleo híbrido y faros de xenon.', 0, 0, 0, 0, 0, 70, 7, 272, 823, 0, 0, NULL, 115, 115, 23, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 70, 7, 273, 824, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 70, 7, 274, 825, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 70, 7, 275, 826, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(17, 'AR105', 'Fusion Proton GTX: Un magnetofón con:\n- cuernos metálicos\n- 1024 stream processors\n- reproductor 4k\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 51, 7, 276, 710, 0, 10.5, NULL, 493, 493, 29, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Hiper Station NX', 0, 0, 0, 0, 0, 51, 7, 277, 711, 0, 10.5, NULL, 123, 123, 41, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Minga Neutro GTX', 0, 0, 0, 0, 0, 51, 7, 278, 712, 0, 10.5, NULL, 97.14, 97.14, 32.38, 0, NULL, NULL, 0, 1, 1),
(2, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 51, 7, 279, 713, 0, 27, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 5, 0, 0, 0, 51, 7, 280, 714, 0, 0, NULL, 360, 342, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 51, 7, 281, 715, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(-1, NULL, 'Extreme Oviode GTX: Un motor con un ambientador de pino.', 0, 0, 0, 0, 0, 23, 7, 282, 402, 0, 0, NULL, -27, -27, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo Arkam XL: Un objeto pequeño d&#39;or con taladro matricial, 32 pistones digitales, un ambientador de pino y 1024 stream processors.', 0, 0, 0, 0, 0, 23, 7, 283, 403, 0, 0, NULL, -72.51, -72.51, 24.17, 0, NULL, NULL, 0, 1, 1),
(-1.333, NULL, 'Minga GeForce XXL: Un palo con reproductor 4k, 16 ejes, spyware y Windows Vista.', 0, 0, 0, 0, 0, 23, 7, 284, 404, 0, 0, NULL, -18.662, -18.662, 14, 0, NULL, NULL, 0, 1, 1),
(-2.2, NULL, 'Fusion nForce GTX: Un dispositivo tecnológico con:\n- malware\n- faros de xenon\n- reproductor 4k\n- spyware.', 0, 0, 0, 0, 0, 23, 7, 285, 405, 0, 0, NULL, -97.9, -97.9, 44.5, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Pro Labtech 3: Una targeta gráfica (GPU) con:\n- 1024 stream processors\n- cuernos metálicos\n- un palo\n- Wifi 4G.', 0, 28, 0, 0, 0, 23, 7, 286, 406, 0, 0, NULL, -70, -50.4, 35, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Arco GTX: Un procesador con propiedades psicotrópicas, chasis de fibra de carbono y reproductor 4k.', 0, 0, 0, 0, 0, 23, 7, 287, 407, 0, 0, NULL, -23, -23, 23, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Station II: &quot;La hostia&quot; con 8 cilindros en V, Windows Vista, malignas intenciones y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 288, 409, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Box OS: Una targeta gráfica (GPU) con faros de xenon, 8 cilindros en V y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 7, 289, 411, 0, 0, NULL, -141, -141, 47, 0, NULL, NULL, 0, 1, 1),
(-2.7, NULL, 'Giga Arkam NX: Un coche con faros de xenon.', 0, 0, 0, 0, 0, 23, 7, 290, 413, 0, 0, NULL, -89.1, -89.1, 33, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Mega Arkam XL: un cubo de basura con:\n- reproductor 4k\n- propiedades psicotrópicas\n- la virginidad intacta\n- memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 291, 416, 0, 0, NULL, -205, -205, 205, 0, NULL, NULL, 0, 1, 1),
(-19, NULL, 'Hiper Engine Nitro: Un palo con:\n- faros de xenon\n- 8 cilindros en V\n- cuernos metálicos\n- la virginidad intacta.', 0, 0, 0, 0, 0, 23, 7, 292, 418, 0, 0, NULL, -836, -836, 44, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Mega Neutro XL: Un dispositivo tecnológico con:\n- un ambientador de pino\n- faros de xenon\n- un palo\n- 32 pistones digitales.', 0, 0, 0, 0, 0, 23, 7, 293, 420, 0, 0, NULL, -177.94, -177.94, 12.71, 0, NULL, NULL, 0, 1, 1),
(-2.1, NULL, 'Extreme Radeon OS: Un coche con:\n- chasis de fibra de carbono\n- Wifi 4G\n- frenos de berilio\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 7, 294, 422, 0, 0, NULL, -44.1, -44.1, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Motor 3: Un objeto pequeño d&#39;or con reproductor 4k, chasis de fibra de carbono, malignas intenciones y faros de xenon.', 0, 0, 0, 0, 0, 23, 7, 295, 423, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Station SE: Una alcachofa con taladro matricial, frenos de berilio y malignas intenciones.', 0, 0, 0, 0, 0, 23, 7, 296, 424, 0, 0, NULL, -76.14, -76.14, 25.38, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga GeForce Pro: Un coche con 32 pistones digitales, propiedades psicotrópicas, malware y Windows Vista.', 0, 20, 0, 0, 0, 23, 7, 297, 426, 0, 0, NULL, -7.5, -6, 2.5, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX GeForce XP: Un palo con:\n- Wifi 4G\n- 64 núcleos\n- un palo\n- malignas intenciones.', 0, 0, 0, 0, 0, 23, 7, 298, 427, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega nForce NX: Una alcachofa con 32 pistones digitales, malignas intenciones y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 299, 428, 0, 0, NULL, -60.66, -60.66, 20.22, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga Radeon Nitro', 0, 0, 0, 0, 0, 23, 7, 300, 430, 0, 0, NULL, -129, -129, 43, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Fusion Station GTX: Un motor con 1024 stream processors, chasis de fibra de carbono, 32 pistones digitales y un palo.', 0, 0, 0, 0, 0, 23, 7, 301, 431, 0, 0, NULL, -41.66, -41.66, 20.83, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Proton 3: Un magnetofón con 1024 stream processors, 16 ejes y linux.', 0, 0, 0, 0, 0, 23, 7, 302, 432, 0, 0, NULL, -71.4, -71.4, 23.8, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Oviode SE: Un magnetofón con pantalla Super AMOLED, memoria HBM, 1024 stream processors y 16 ejes.', 0, 0, 0, 0, 0, 23, 7, 303, 433, 0, 0, NULL, -87, -87, 29, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Proton XL: un cubo de basura con un ambientador de pino, faros de xenon, 8 cilindros en V y memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 304, 435, 0, 0, NULL, -82, -82, 41, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Ultra Arco GTX: Un objeto pequeño d&#39;or con memoria HBM, malware y frenos de berilio.', 0, 0, 0, 0, 0, 23, 7, 305, 437, 0, 0, NULL, -11, -11, 11, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Oviode GT: Una targeta gráfica (GPU) con propiedades psicotrópicas, Windows Vista y malignas intenciones.', 0, 0, 0, 0, 0, 23, 7, 306, 439, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Station GT: Un coche con spyware.', 0, 27, 0, 0, 0, 23, 7, 307, 440, 0, 0, NULL, -81, -59.13, 27, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Station OS: &quot;La hostia&quot; con chasis de fibra de carbono, linux, cuernos metálicos y 64 núcleos.', 0, 0, 0, 0, 0, 23, 7, 308, 442, 0, 0, NULL, -29, -29, 29, 0, NULL, NULL, 0, 1, 1),
(-10, NULL, 'Broken Oviode Nitro: &quot;La hostia&quot; con un posavasos.', 0, 0, 0, 0, 0, 23, 7, 309, 444, 0, 0, NULL, -483.3, -483.3, 48.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Arco Nitro: &quot;La hostia&quot; con:\n- chasis de fibra de carbono\n- pantalla Super AMOLED\n- la virginidad intacta\n- taladro matricial.', 0, 6, 0, 0, 0, 23, 7, 310, 446, 0, 0, NULL, -83.01, -78.0294, 27.67, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Neutro GT', 0, 0, 0, 0, 0, 23, 7, 311, 448, 0, 0, NULL, -70, -70, 35, 0, NULL, NULL, 0, 1, 1);
INSERT INTO `lineasfacturascli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idfactura`, `idlinea`, `idlineaalbaran`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(-1.4, NULL, 'Sub Station XP: Una targeta gráfica (GPU) con 8 cilindros en V, un ambientador de pino, faros de xenon y Wifi 4G.', 0, 0, 0, 0, 0, 23, 7, 312, 450, 0, 0, NULL, -29.862, -29.862, 21.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Station Nitro: Un dispositivo tecnológico con un núcleo híbrido, un palo, un ambientador de pino y memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 313, 451, 0, 0, NULL, -129, -129, 43, 0, NULL, NULL, 0, 1, 1),
(-2.333, NULL, 'Sub Box GT: Un coche con:\n- cuernos metálicos\n- propiedades psicotrópicas\n- un ambientador de pino\n- 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 7, 314, 452, 0, 0, NULL, -23.33, -23.33, 10, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Generator GT: Una alcachofa con un núcleo híbrido.', 0, 30, 0, 0, 0, 23, 7, 315, 454, 0, 0, NULL, -26, -18.2, 13, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Pro Radeon XL', 0, 0, 0, 0, 0, 23, 7, 316, 456, 0, 0, NULL, -136.71, -136.71, 45.57, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Station NX', 0, 0, 0, 0, 0, 23, 7, 317, 457, 0, 0, NULL, -135, -135, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Generator XL: Un palo con taladro matricial, malware y cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 318, 458, 0, 0, NULL, -135.6, -135.6, 45.2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Motor XXL: un cubo de basura con frenos de berilio, un posavasos, malignas intenciones y spyware.', 0, 16, 0, 0, 0, 23, 7, 319, 459, 0, 0, NULL, -90, -75.6, 30, 0, NULL, NULL, 0, 1, 1),
(-2.4, NULL, 'Hiper Tool 3: Una targeta gráfica (GPU) con:\n- frenos de berilio\n- propiedades psicotrópicas\n- pantalla Super AMOLED\n- spyware.', 0, 32, 0, 0, 0, 23, 7, 320, 460, 0, 0, NULL, -62.4, -42.432, 26, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Engine II: Un palo con reproductor 4k.', 0, 0, 0, 0, 0, 23, 7, 321, 461, 0, 0, NULL, -6, -6, 6, 0, NULL, NULL, 0, 1, 1),
(-4, NULL, 'Hiper Box Nitro: Una targeta gráfica (GPU) con 64 núcleos, memoria HBM, pantalla Super AMOLED y un posavasos.', 0, 0, 0, 0, 0, 23, 7, 322, 462, 0, 0, NULL, -57.32, -57.32, 14.33, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Arco GT', 0, 0, 0, 0, 0, 23, 7, 323, 463, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Motor XXL: Un palo con un núcleo híbrido.', 0, 11, 0, 0, 0, 23, 7, 324, 464, 0, 0, NULL, -105, -93.45, 35, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Super Radeon XP', 0, 0, 0, 0, 0, 23, 7, 325, 465, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Motor XL: Un magnetofón con tecnología digitrónica 4.1, un palo, cuernos metálicos y frenos de berilio.', 0, 0, 0, 0, 0, 23, 7, 326, 466, 0, 0, NULL, -405, -405, 405, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Mega Arkam Nitro: Un palo con linux.', 0, 0, 0, 0, 0, 23, 7, 327, 467, 0, 0, NULL, -19.5, -19.5, 19.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi GeForce SE', 0, 0, 0, 0, 0, 23, 7, 328, 468, 0, 0, NULL, -846, -846, 282, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Maxi Tool II: Un objeto pequeño d&#39;or con memoria HBM, un posavasos y frenos de berilio.', 0, 0, 0, 0, 0, 23, 7, 329, 469, 0, 0, NULL, -36, -36, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Station OS: Un palo con un palo, tecnología digitrónica 4.1, un posavasos y memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 330, 470, 0, 0, NULL, -93, -93, 31, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Neutro NX: un cubo de basura con pantalla Super AMOLED, malware y linux.', 0, 1, 0, 0, 0, 23, 7, 331, 471, 0, 0, NULL, -68, -67.32, 34, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Generator NX: Un coche con un ambientador de pino, malware, 32 pistones digitales y taladro matricial.', 0, 0, 0, 0, 0, 23, 7, 332, 472, 0, 0, NULL, -565, -565, 565, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga nForce 3: Un procesador con faros de xenon.', 0, 0, 0, 0, 0, 23, 7, 333, 473, 0, 0, NULL, -2, -2, 2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Arco NX: Un palo con cuernos metálicos, Wifi 4G, un posavasos y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 7, 334, 474, 0, 0, NULL, -954, -954, 318, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Broken Arco XL: &quot;La hostia&quot; con un posavasos, 1024 stream processors y Windows Vista.', 0, 0, 0, 0, 0, 23, 7, 335, 475, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Giga Arco GTX: Una targeta gráfica (GPU) con linux, 16 ejes y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 7, 336, 476, 0, 0, NULL, -44, -44, 22, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Labtech II: un cubo de basura con spyware, faros de xenon, 1024 stream processors y un ambientador de pino.', 0, 54, 0, 0, 0, 23, 7, 337, 477, 0, 0, NULL, -20, -9.2, 10, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jet GeForce SE', 0, 9, 0, 0, 0, 23, 7, 338, 478, 0, 0, NULL, -44, -40.04, 44, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'FX Radeon Nitro: Una alcachofa con chasis de fibra de carbono, la virginidad intacta y cuernos metálicos.', 0, 4.5, 0, 0, 0, 23, 7, 339, 479, 0, 0, NULL, -74, -70.67, 37, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Proton XL', 0, 0, 0, 0, 0, 23, 7, 340, 480, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo GeForce II: Una targeta gráfica (GPU) con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 341, 481, 0, 0, NULL, -35, -35, 35, 0, NULL, NULL, 0, 1, 1),
(-16, NULL, 'Hiper Labtech SE', 0, 0, 0, 0, 0, 23, 7, 342, 482, 0, 0, NULL, -448, -448, 28, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Ultra Labtech XXL', 0, 0, 0, 0, 0, 23, 7, 343, 483, 0, 0, NULL, -10, -10, 5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Radeon GTX: Una alcachofa con malignas intenciones, malware y faros de xenon.', 0, 29, 0, 0, 0, 23, 7, 344, 484, 0, 0, NULL, -81, -57.51, 27, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken Arkam Pro: Un magnetofón con la virginidad intacta, 64 núcleos, 1024 stream processors y malignas intenciones.', 0, 0, 0, 0, 0, 23, 7, 345, 485, 0, 0, NULL, -74, -74, 37, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken nForce GT: &quot;La hostia&quot; con:\n- chasis de fibra de carbono\n- 64 núcleos\n- 1024 stream processors\n- linux.', 0, 23.2, 0, 0, 0, 23, 7, 346, 486, 0, 0, NULL, -92, -70.656, 46, 0, NULL, NULL, 0, 1, 1),
(-2.56, NULL, 'Jex Motor NX: Un motor con 8 cilindros en V, un palo, propiedades psicotrópicas y un ambientador de pino.', 0, 13.4, 0, 0, 0, 23, 7, 347, 487, 0, 0, NULL, -74.24, -64.29184, 29, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Proton XP', 0, 0, 0, 0, 0, 23, 7, 348, 488, 0, 0, NULL, -32, -32, 32, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Station XP: Una targeta gráfica (GPU) con:\n- taladro matricial\n- tecnología digitrónica 4.1\n- frenos de berilio\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 7, 349, 489, 0, 0, NULL, -345, -345, 345, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Oviode II', 0, 23, 0, 0, 0, 23, 7, 350, 490, 0, 0, NULL, -30, -23.1, 10, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Neutro OS: Un dispositivo tecnológico con:\n- 32 pistones digitales\n- faros de xenon\n- un núcleo híbrido\n- spyware.', 0, 0, 0, 0, 0, 23, 7, 351, 491, 0, 0, NULL, -11, -11, 11, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega GeForce Pro: Una targeta gráfica (GPU) con propiedades psicotrópicas, spyware, pantalla Super AMOLED y Windows Vista.', 0, 0, 0, 0, 0, 23, 7, 352, 492, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Jex Tool SE: un cubo de basura con cuernos metálicos, un posavasos y 1024 stream processors.', 0, 14, 0, 0, 0, 23, 7, 353, 494, 0, 0, NULL, -496, -426.56, 496, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max nForce II: Una alcachofa con:\n- Wifi 4G\n- spyware\n- un posavasos\n- taladro matricial.', 0, 0, 0, 0, 0, 23, 7, 354, 496, 0, 0, NULL, -27, -27, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Arco NX: Una alcachofa con frenos de berilio.', 0, 0, 0, 0, 0, 23, 7, 355, 498, 0, 0, NULL, -9, -9, 3, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Motor XXL: Un coche con faros de xenon, pantalla Super AMOLED, Windows Vista y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 7, 356, 500, 0, 0, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Giga Generator Pro: Un magnetofón con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 7, 357, 502, 0, 0, NULL, -224, -224, 16, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Radeon XL: un cubo de basura con 8 cilindros en V.', 0, 24, 0, 0, 0, 23, 7, 358, 504, 0, 0, NULL, -90.22, -68.5672, 45.11, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Sub Radeon NX: Un palo con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 359, 505, 0, 0, NULL, -46, -46, 46, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Super Labtech 3: Un motor con propiedades psicotrópicas, faros de xenon y un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 7, 360, 506, 0, 0, NULL, -33, -33, 33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Arco 3', 0, 0, 0, 0, 0, 23, 7, 361, 508, 0, 0, NULL, -114, -114, 38, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet GeForce SE: un cubo de basura con propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 362, 510, 0, 0, NULL, -24, -24, 8, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Motor II: &quot;La hostia&quot; con malignas intenciones, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 23, 7, 363, 511, 0, 0, NULL, -1118, -1118, 559, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Engine XP: Un objeto pequeño d&#39;or con:\n- Windows Vista\n- un núcleo híbrido\n- 1024 stream processors\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 7, 364, 512, 0, 0, NULL, -6, -6, 6, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Radeon XXL', 0, 0, 0, 0, 0, 23, 7, 365, 513, 0, 0, NULL, -381, -381, 127, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Radeon SE: Un dispositivo tecnológico con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 366, 514, 0, 0, NULL, -132, -132, 44, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Oviode GTX: Una targeta gráfica (GPU) con:\n- tecnología digitrónica 4.1\n- spyware\n- 8 cilindros en V\n- un ambientador de pino.', 0, 0, 0, 0, 0, 23, 7, 367, 515, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(-17, NULL, 'Fusion Labtech GT: Un magnetofón con:\n- taladro matricial\n- un palo\n- malware\n- 8 cilindros en V.', 0, 2, 0, 0, 0, 23, 7, 368, 517, 0, 0, NULL, -374, -366.52, 22, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Hiper Generator Pro: Un procesador con un posavasos.', 0, 0, 0, 0, 0, 23, 7, 369, 518, 0, 0, NULL, -10.83, -10.83, 10.83, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Arkam 3: Un dispositivo tecnológico con:\n- un posavasos\n- memoria HBM\n- Wifi 4G\n- cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 370, 519, 0, 0, NULL, -97.6, -97.6, 48.8, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Radeon II', 0, 0, 0, 0, 0, 23, 7, 371, 520, 0, 0, NULL, -5, -5, 5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jet Labtech OS', 0, 0, 0, 0, 0, 23, 7, 372, 521, 0, 0, NULL, -39, -39, 13, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Radeon II: Un magnetofón con memoria HBM, reproductor 4k y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 7, 373, 522, 0, 0, NULL, -46, -46, 23, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Mega Arco XXL: Un objeto pequeño d&#39;or con Wifi 4G, un palo, cuernos metálicos y malware.', 0, 0, 0, 0, 0, 23, 7, 374, 524, 0, 0, NULL, -81, -81, 27, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Labtech 3', 0, 0, 0, 0, 0, 23, 7, 375, 526, 0, 0, NULL, -111, -111, 37, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Arkam 3: Un magnetofón con un palo, Windows Vista y 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 7, 376, 528, 0, 0, NULL, -1116, -1116, 372, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo GeForce XL: Un procesador con memoria HBM, 8 cilindros en V, frenos de berilio y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 7, 377, 530, 0, 0, NULL, -18, -18, 18, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub GeForce 3', 0, 0, 0, 0, 0, 23, 7, 378, 532, 0, 0, NULL, -24, -24, 12, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Extreme Labtech 3: Un coche con 8 cilindros en V.', 0, 0, 0, 0, 0, 23, 7, 379, 533, 0, 0, NULL, -8, -8, 8, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Maxi Engine OS: Una alcachofa con:\n- la virginidad intacta\n- 16 ejes\n- 1024 stream processors\n- reproductor 4k.', 0, 0, 0, 0, 0, 23, 7, 380, 534, 0, 0, NULL, -52, -52, 26, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Giga Motor Pro', 0, 0, 0, 0, 0, 23, 7, 381, 536, 0, 0, NULL, -72.5, -72.5, 29, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Generator II: Un coche con pantalla Super AMOLED, 16 ejes y taladro matricial.', 0, 0, 0, 0, 0, 23, 7, 382, 538, 0, 0, NULL, -28.89, -28.89, 9.63, 0, NULL, NULL, 0, 1, 1),
(-1.5, NULL, 'FX Labtech II: Una alcachofa con tecnología digitrónica 4.1, un ambientador de pino, linux y spyware.', 0, 0, 0, 0, 0, 23, 7, 383, 539, 0, 0, NULL, -35.565, -35.565, 23.71, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken nForce 3: Un coche con 1024 stream processors, tecnología digitrónica 4.1 y memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 384, 540, 0, 0, NULL, -24, -24, 12, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Generator NX: Un procesador con:\n- reproductor 4k\n- propiedades psicotrópicas\n- frenos de berilio\n- Wifi 4G.', 0, 23, 0, 0, 0, 23, 7, 385, 541, 0, 0, NULL, -43, -33.11, 43, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Radeon NX: Un motor con un palo, malware y Wifi 4G.', 0, 0, 0, 0, 0, 23, 7, 386, 542, 0, 0, NULL, -78, -78, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'FX Neutro XP: Una targeta gráfica (GPU) con un posavasos, malignas intenciones, un núcleo híbrido y tecnología digitrónica 4.1.', 0, 2, 0, 0, 0, 23, 7, 387, 543, 0, 0, NULL, -195, -191.1, 65, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Generator XXL: Un dispositivo tecnológico con tecnología digitrónica 4.1, 32 pistones digitales y taladro matricial.', 0, 0, 0, 0, 0, 23, 7, 388, 545, 0, 0, NULL, -40, -40, 20, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega GeForce GT: Un dispositivo tecnológico con:\n- Windows Vista\n- malignas intenciones\n- un núcleo híbrido\n- cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 389, 547, 0, 0, NULL, -70, -70, 35, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Mega Motor NX', 0, 31, 0, 0, 0, 23, 7, 390, 549, 0, 0, NULL, -16, -11.04, 8, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Motor GTX: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1, reproductor 4k y linux.', 0, 0, 0, 0, 0, 23, 7, 391, 551, 0, 0, NULL, -12.99, -12.99, 4.33, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Jet Arco Nitro: Un palo con un palo.', 0, 1, 0, 0, 0, 23, 7, 392, 552, 0, 0, NULL, -90, -89.1, 45, 0, NULL, NULL, 0, 1, 1),
(-14, NULL, 'Hiper Arkam GT: &quot;La hostia&quot; con faros de xenon, propiedades psicotrópicas y malware.', 0, 0, 0, 0, 0, 23, 7, 393, 553, 0, 0, NULL, -350, -350, 25, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Extreme Motor NX: &quot;La hostia&quot; con malignas intenciones, un ambientador de pino y memoria HBM.', 0, 0, 0, 0, 0, 23, 7, 394, 555, 0, 0, NULL, -16, -16, 8, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Broken Arkam Pro: Un dispositivo tecnológico con memoria HBM.', 0, 32, 0, 0, 0, 23, 7, 395, 556, 0, 0, NULL, -43.5, -29.58, 17.4, 0, NULL, NULL, 0, 1, 1),
(-5, NULL, 'Pro Neutro OS: &quot;La hostia&quot; con un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 7, 396, 557, 0, 0, NULL, -130, -130, 26, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Sub Box XXL: Un magnetofón con:\n- Wifi 4G\n- malware\n- memoria HBM\n- Windows Vista.', 0, 0, 0, 0, 0, 23, 7, 397, 559, 0, 0, NULL, -135, -135, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Engine XXL: Un magnetofón con 8 cilindros en V, cuernos metálicos, un posavasos y la virginidad intacta.', 0, 0, 0, 0, 0, 23, 7, 398, 560, 0, 0, NULL, -90, -90, 30, 0, NULL, NULL, 0, 1, 1),
(-17, NULL, 'Extreme Arco GTX: Un dispositivo tecnológico con malignas intenciones, un palo, frenos de berilio y 64 núcleos.', 0, 0, 0, 0, 0, 23, 7, 399, 561, 0, 0, NULL, -136, -136, 8, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Generator Nitro: Un dispositivo tecnológico con:\n- malignas intenciones\n- linux\n- la virginidad intacta\n- tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 23, 7, 400, 563, 0, 0, NULL, -27, -27, 9, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Giga Engine 3: Un coche con malware, un palo, la virginidad intacta y Wifi 4G.', 0, 0, 0, 0, 0, 23, 7, 401, 565, 0, 0, NULL, -12, -12, 12, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Labtech II: un cubo de basura con tecnología digitrónica 4.1, frenos de berilio y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 7, 402, 567, 0, 0, NULL, -38, -38, 19, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Motor 3: Una targeta gráfica (GPU) con:\n- frenos de berilio\n- cuernos metálicos\n- memoria HBM\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 23, 7, 403, 569, 0, 0, NULL, -195, -195, 195, 0, NULL, NULL, 0, 1, 1),
(-1.111, NULL, 'Jet Arkam NX', 0, 27, 0, 0, 0, 23, 7, 404, 571, 0, 0, NULL, -22.03113, -16.0827249, 19.83, 0, NULL, NULL, 0, 1, 1),
(-12, NULL, 'Mega Oviode XXL: Un palo con un ambientador de pino, frenos de berilio, un núcleo híbrido y malware.', 0, 0, 0, 0, 0, 23, 7, 405, 573, 0, 0, NULL, -540, -540, 45, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Max Arkam Nitro: Un palo con 8 cilindros en V.', 0, 8, 0, 0, 0, 23, 7, 406, 575, 0, 0, NULL, -105, -96.6, 35, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Minga Engine GTX: Un palo con:\n- malware\n- un ambientador de pino\n- linux\n- frenos de berilio.', 0, 0, 0, 0, 0, 23, 7, 407, 577, 0, 0, NULL, -63, -63, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Arco XP', 0, 0, 0, 0, 0, 23, 7, 408, 578, 0, 0, NULL, -66, -66, 22, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Mega Arkam SE', 0, 0, 0, 0, 0, 23, 7, 409, 579, 0, 0, NULL, -142.5, -142.5, 57, 0, NULL, NULL, 0, 1, 1),
(-2.2, NULL, 'Mega Engine GT: Un palo con spyware, pantalla Super AMOLED y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 410, 581, 0, 0, NULL, -39.6, -39.6, 18, 0, NULL, NULL, 0, 1, 1),
(-2.5, NULL, 'Neo Station XP: Una alcachofa con:\n- faros de xenon\n- malware\n- un núcleo híbrido\n- pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 7, 411, 583, 0, 0, NULL, -90, -90, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Jex Oviode XL: Un procesador con un núcleo híbrido, 1024 stream processors y spyware.', 0, 0, 0, 0, 0, 23, 7, 412, 584, 0, 0, NULL, -120, -120, 40, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Arco Pro: Un objeto pequeño d&#39;or con:\n- tecnología digitrónica 4.1\n- Windows Vista\n- memoria HBM\n- malignas intenciones.', 0, 26, 0, 0, 0, 23, 7, 413, 585, 0, 0, NULL, -25, -18.5, 25, 0, NULL, NULL, 0, 1, 1),
(-9, NULL, 'FX Motor GTX: Un objeto pequeño d&#39;or con cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 414, 586, 0, 0, NULL, -126, -126, 14, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga Oviode 3: un cubo de basura con frenos de berilio, malware, un ambientador de pino y un palo.', 0, 0, 0, 0, 0, 23, 7, 415, 587, 0, 0, NULL, -102, -102, 34, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Generator GT: un cubo de basura con spyware, linux y 1024 stream processors.', 0, 0.4, 0, 0, 0, 23, 7, 416, 588, 0, 0, NULL, -48, -47.808, 48, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Neo Station OS: Un palo con Windows Vista, malignas intenciones y un palo.', 0, 0, 0, 0, 0, 23, 7, 417, 589, 0, 0, NULL, -278, -278, 139, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub Box OS: &quot;La hostia&quot; con memoria HBM, propiedades psicotrópicas, Windows Vista y 1024 stream processors.', 0, 0, 0, 0, 0, 23, 7, 418, 590, 0, 0, NULL, -72, -72, 36, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'FX Engine 3: Un motor con:\n- linux\n- 16 ejes\n- Windows Vista\n- un ambientador de pino.', 0, 38, 0, 0, 0, 23, 7, 419, 591, 0, 0, NULL, -14, -8.68, 14, 0, NULL, NULL, 0, 1, 1),
(-2.6, NULL, 'Extreme Arco 3: Un dispositivo tecnológico con cuernos metálicos, propiedades psicotrópicas y linux.', 0, 0, 0, 0, 0, 23, 7, 420, 592, 0, 0, NULL, -81.9, -81.9, 31.5, 0, NULL, NULL, 0, 1, 1),
(-1.375, NULL, 'Hiper Engine XL: Un objeto pequeño d&#39;or con:\n- memoria HBM\n- 16 ejes\n- malware\n- Wifi 4G.', 0, 28, 0, 0, 0, 23, 7, 421, 593, 0, 0, NULL, -698.5, -502.92, 508, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Proton SE: Un coche con:\n- cuernos metálicos\n- la virginidad intacta\n- spyware\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 23, 7, 422, 594, 0, 0, NULL, -139.2, -139.2, 46.4, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Sub GeForce OS: Un coche con:\n- frenos de berilio\n- un posavasos\n- Wifi 4G\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 23, 7, 423, 595, 0, 0, NULL, -42, -42, 21, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Neo Oviode NX', 0, 16, 0, 0, 0, 23, 7, 424, 596, 0, 0, NULL, -84, -70.56, 28, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max GeForce SE: Un coche con 64 núcleos, memoria HBM y cuernos metálicos.', 0, 0, 0, 0, 0, 23, 7, 425, 597, 0, 0, NULL, -36, -36, 36, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Broken Tool 3: Un procesador con un ambientador de pino.', 0, 0, 0, 0, 0, 23, 7, 426, 598, 0, 0, NULL, -96, -96, 32, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi nForce SE: Una targeta gráfica (GPU) con linux, malware y pantalla Super AMOLED.', 0, 0, 0, 0, 0, 23, 7, 427, 599, 0, 0, NULL, -141.33, -141.33, 47.11, 0, NULL, NULL, 0, 1, 1),
(-2.625, NULL, 'Extreme Arco NX: Un magnetofón con linux, taladro matricial y memoria HBM.', 0, 25, 0, 0, 0, 23, 7, 428, 600, 0, 0, NULL, -354.375, -265.78125, 135, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 23, 7, 429, 601, 0, 0, NULL, -200, -200, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 23, 7, 430, 602, 0, 0, NULL, -1500, -1500, 500, 0, '4', NULL, 0, 1, 1),
(-1, NULL, 'Alumno', 0, 36, 0, 0, 0, 23, 7, 431, 603, 0, 0, NULL, -118.11, -75.5904, 118.11, 0, '3', NULL, 0, 1, 1),
(2, 'AR105', 'Neo Station Pro: &quot;La hostia&quot; con:\n- un posavasos\n- memoria HBM\n- 32 pistones digitales\n- spyware.', 0, 0, 0, 0, 0, 18, 7, 432, 360, 0, 10.5, NULL, 70.66, 70.66, 35.33, 0, NULL, NULL, 0, 1, 1),
(19, 'AR105', 'Minga Generator XXL: un cubo de basura con propiedades psicotrópicas, taladro matricial, chasis de fibra de carbono y pantalla Super AMOLED.', 0, 29.222, 0, 0, 0, 18, 7, 433, 361, 0, 10.5, NULL, 858.8, 607.841464, 45.2, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Minga Generator XL', 0, 0, 0, 0, 0, 18, 7, 434, 363, 0, 10.5, NULL, 98, 98, 49, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Minga Generator XL: Un motor con 16 ejes.', 0, 0, 0, 0, 0, 18, 7, 435, 364, 0, 10.5, NULL, 44, 44, 44, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Minga Motor GT: Un dispositivo tecnológico con:\n- frenos de berilio\n- cuernos metálicos\n- pantalla Super AMOLED\n- un ambientador de pino.', 0, 0, 0, 0, 0, 18, 7, 436, 365, 0, 10.5, NULL, 57, 57, 19, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Mega Neutro GTX', 0, 0, 0, 0, 0, 18, 7, 437, 367, 0, 10.5, NULL, 67.8, 67.8, 22.6, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Super Tool NX: Un magnetofón con 16 ejes, faros de xenon y un palo.', 0, 0, 0, 0, 0, 18, 7, 438, 368, 0, 10.5, NULL, 27, 27, 9, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 18, 7, 439, 369, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(2.2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 18, 7, 440, 372, 0, 0, NULL, 264, 264, 120, 0, '1', NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 18, 7, 441, 376, 0, 21, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(-16, NULL, 'Broken nForce GTX: un cubo de basura con 16 ejes, linux, un posavasos y memoria HBM.', 0, 0, 0, 0, 0, 42, 7, 442, 647, 0, 0, NULL, -224, -224, 14, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Extreme Radeon Pro: Una targeta gráfica (GPU) con 32 pistones digitales.', 0, 0, 0, 0, 0, 42, 7, 443, 648, 0, 0, NULL, -117, -117, 39, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Minga Tool SE: &quot;La hostia&quot; con:\n- reproductor 4k\n- memoria HBM\n- un núcleo híbrido\n- un palo.', 0, 0, 0, 0, 0, 42, 7, 444, 649, 0, 0, NULL, -642, -642, 642, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Fusion Engine XP: Un objeto pequeño d&#39;or con un palo, 64 núcleos, 16 ejes y memoria HBM.', 0, 0, 0, 0, 0, 42, 7, 445, 651, 0, 0, NULL, -1, -1, 1, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Extreme Motor XP: Un coche con:\n- 32 pistones digitales\n- frenos de berilio\n- tecnología digitrónica 4.1\n- linux.', 0, 0, 0, 0, 0, 42, 7, 446, 652, 0, 0, NULL, -6, -6, 3, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Arco Nitro: Un palo con 64 núcleos, un palo, spyware y pantalla Super AMOLED.', 0, 5, 0, 0, 0, 42, 7, 447, 653, 0, 0, NULL, -141, -133.95, 47, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Max Arkam OS: Una targeta gráfica (GPU) con:\n- la virginidad intacta\n- linux\n- propiedades psicotrópicas\n- chasis de fibra de carbono.', 0, 0, 0, 0, 0, 42, 7, 448, 654, 0, 0, NULL, -75.34, -75.34, 37.67, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 22, 0, 0, 0, 42, 7, 449, 656, 0, 0, NULL, -300, -234, 100, 0, '2', NULL, 0, 1, 1),
(-2, NULL, 'Alumno', 0, 0, 0, 0, 0, 42, 7, 450, 660, 0, 0, NULL, -236.22, -236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(-2, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 42, 7, 451, 662, 0, 0, NULL, -240, -240, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'Jex Neutro NX: Un objeto pequeño d&#39;or con:\n- spyware\n- malignas intenciones\n- chasis de fibra de carbono\n- 64 núcleos.', 0, 0, 0, 0, 0, 61, 7, 452, 772, 0, 0, NULL, 9, 9, 9, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jet Labtech NX: Una alcachofa con un núcleo híbrido.', 0, 0, 0, 0, 0, 61, 7, 453, 773, 0, 0, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Fusion Tool GTX: Una alcachofa con linux, reproductor 4k y 16 ejes.', 0, 0, 0, 0, 0, 61, 7, 454, 774, 0, 0, NULL, 674, 674, 337, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Labtech Pro: Un magnetofón con:\n- un núcleo híbrido\n- chasis de fibra de carbono\n- la virginidad intacta\n- linux.', 0, 0, 0, 0, 0, 61, 7, 455, 775, 0, 0, NULL, 132, 132, 44, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 61, 7, 456, 776, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 26, 0, 0, 0, 61, 7, 457, 777, 0, 0, NULL, 120, 88.8, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 14.8, 0, 0, 0, 61, 7, 458, 778, 0, 0, NULL, 236.22, 201.25944, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Ultra Station OS: Una alcachofa con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 75, 7, 459, 921, 0, 0, NULL, 45, 45, 45, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Minga Motor XP: &quot;La hostia&quot; con:\n- Windows Vista\n- 8 cilindros en V\n- 16 ejes\n- taladro matricial.', 0, 0, 0, 0, 0, 75, 7, 460, 922, 0, 0, NULL, 58, 58, 29, 0, NULL, NULL, 0, 1, 1),
(1.7, NULL, 'Pro GeForce GT: Un magnetofón con:\n- un ambientador de pino\n- spyware\n- 8 cilindros en V\n- 1024 stream processors.', 0, 0, 0, 0, 0, 75, 7, 461, 923, 0, 0, NULL, 1171.3, 1171.3, 689, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken Proton XL: Una alcachofa con spyware, memoria HBM, taladro matricial y Wifi 4G.', 0, 0, 0, 0, 0, 75, 7, 462, 924, 0, 0, NULL, 22, 22, 22, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion Motor SE: Un palo con frenos de berilio, memoria HBM y un posavasos.', 0, 17, 0, 0, 0, 75, 7, 463, 925, 0, 0, NULL, 103, 85.49, 103, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Broken nForce XP: Una targeta gráfica (GPU) con malware, memoria HBM y 1024 stream processors.', 0, 0, 0, 0, 0, 75, 7, 464, 926, 0, 0, NULL, 36.71, 36.71, 36.71, 0, NULL, NULL, 0, 1, 1),
(12, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 75, 7, 465, 927, 0, 0, NULL, 6000, 6000, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 75, 7, 466, 928, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 75, 7, 467, 929, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(3, 'AR105', 'Fusion Motor GTX: Un palo con:\n- Windows Vista\n- la virginidad intacta\n- 16 ejes\n- 64 núcleos.', 0, 0, 0, 0, 0, 12, 7, 468, 319, 0, 10.5, NULL, 81, 81, 27, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Fusion Station Nitro: Una targeta gráfica (GPU) con un núcleo híbrido, frenos de berilio, linux y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 12, 7, 469, 321, 0, 10.5, NULL, 874, 874, 437, 0, NULL, NULL, 0, 1, 1),
(1.4, 'AR105', 'Jex Radeon XP', 0, 0, 0, 0, 0, 12, 7, 470, 323, 0, 10.5, NULL, 40.6, 40.6, 29, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Broken Engine GTX: Una alcachofa con:\n- un núcleo híbrido\n- taladro matricial\n- un posavasos\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 12, 7, 471, 325, 0, 10.5, NULL, 17.2, 17.2, 17.2, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 12, 7, 472, 327, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(1.7, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 12, 7, 473, 330, 0, 27, NULL, 200.787, 200.787, 118.11, 0, '3', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 12, 7, 474, 332, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Fusion Motor GT', 0, 0, 0, 0, 0, 40, 7, 475, 640, 0, 0, NULL, 41.25, 41.25, 41.25, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 40, 7, 476, 642, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 40, 7, 477, 643, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 33, 0, 0, 0, 40, 7, 478, 645, 0, 0, NULL, 360, 241.2, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 27, 7, 479, 516, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 8, 0, 0, 0, 32, 7, 480, 607, 0, 0, NULL, 1500, 1380, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 32, 7, 481, 608, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 21, 0, 0, 0, 32, 7, 482, 610, 0, 0, NULL, 236.22, 186.6138, 118.11, 0, '3', NULL, 0, 1, 1),
(6, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 31, 7, 483, 604, 0, 0, NULL, 3000, 3000, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 31, 7, 484, 605, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 31, 7, 485, 606, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 10, 0, 0, 0, 67, 7, 486, 801, 0, 0, NULL, 200, 180, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 67, 7, 487, 802, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 67, 7, 488, 803, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(3, 'AR105', 'Broken Arco GT', 0, 2, 0, 0, 0, 10, 7, 489, 262, 0, 10.5, NULL, 75.6, 74.088, 25.2, 0, NULL, NULL, 0, 1, 1),
(17, 'AR105', 'Hiper Arco XXL: Un coche con 8 cilindros en V.', 0, 0, 0, 0, 0, 10, 7, 490, 264, 0, 10.5, NULL, 136, 136, 8, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Mega Motor OS: Un magnetofón con:\n- reproductor 4k\n- pantalla Super AMOLED\n- malignas intenciones\n- faros de xenon.', 0, 0, 0, 0, 0, 10, 7, 491, 266, 0, 10.5, NULL, 126, 126, 42, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Generator SE', 0, 0, 0, 0, 0, 10, 7, 492, 268, 0, 10.5, NULL, 36, 36, 12, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Tool OS: Un objeto pequeño d&#39;or con un palo, cuernos metálicos y frenos de berilio.', 0, 0, 0, 0, 0, 10, 7, 493, 270, 0, 10.5, NULL, 126.6, 126.6, 42.2, 0, NULL, NULL, 0, 1, 1),
(11, 'AR105', 'FX Engine Pro: &quot;La hostia&quot; con:\n- propiedades psicotrópicas\n- frenos de berilio\n- taladro matricial\n- un posavasos.', 0, 0, 0, 0, 0, 10, 7, 494, 272, 0, 10.5, NULL, 418, 418, 38, 0, NULL, NULL, 0, 1, 1),
(16, 'AR105', 'Ultra Radeon Pro: Un objeto pequeño d&#39;or con propiedades psicotrópicas, spyware y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 10, 7, 495, 274, 0, 10.5, NULL, 680, 680, 42.5, 0, NULL, NULL, 0, 1, 1),
(2.25, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 10, 7, 496, 276, 0, 21, NULL, 1125, 1125, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 10, 7, 497, 280, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 10, 7, 498, 284, 0, 27, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Max Labtech II: un cubo de basura con 32 pistones digitales.', 0, 0, 0, 0, 0, 33, 7, 499, 609, 0, 0, NULL, 31, 31, 31, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Neutro GTX: Un coche con:\n- 1024 stream processors\n- 64 núcleos\n- memoria HBM\n- 8 cilindros en V.', 0, 16, 0, 0, 0, 33, 7, 500, 611, 0, 0, NULL, 201, 168.84, 67, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Oviode NX: &quot;La hostia&quot; con tecnología digitrónica 4.1, linux, chasis de fibra de carbono y spyware.', 0, 0, 0, 0, 0, 33, 7, 501, 612, 0, 0, NULL, 9, 9, 3, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Broken Proton GT: Un motor con:\n- 32 pistones digitales\n- un posavasos\n- propiedades psicotrópicas\n- 16 ejes.', 0, 0, 0, 0, 0, 33, 7, 502, 613, 0, 0, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Broken GeForce Nitro: Un objeto pequeño d&#39;or con Windows Vista, pantalla Super AMOLED y 64 núcleos.', 0, 0, 0, 0, 0, 33, 7, 503, 614, 0, 0, NULL, 114, 114, 38, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Minga Box XL: Un palo con 32 pistones digitales.', 0, 0, 0, 0, 0, 33, 7, 504, 615, 0, 0, NULL, 37, 37, 37, 0, NULL, NULL, 0, 1, 1),
(1.25, NULL, 'Pro GeForce NX: Un palo con memoria HBM, spyware y frenos de berilio.', 0, 0, 0, 0, 0, 33, 7, 505, 616, 0, 0, NULL, 111.25, 111.25, 89, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 24, 0, 0, 0, 33, 7, 506, 618, 0, 0, NULL, 200, 152, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 33, 7, 507, 621, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 33, 7, 508, 623, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Extreme Radeon Pro', 0, 18, 0, 0, 0, 17, 7, 509, 357, 0, 0, NULL, 87, 71.34, 29, 0, NULL, NULL, 0, 1, 1),
(10, NULL, 'Minga Tool SE: &quot;La hostia&quot; con reproductor 4k.', 0, 0, 0, 0, 0, 17, 7, 510, 358, 0, 0, NULL, 450, 450, 45, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 42, 0, 0, 0, 17, 7, 511, 359, 0, 0, NULL, 200, 116, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 17, 7, 512, 362, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 17, 7, 513, 366, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(-2.67, NULL, 'Mega nForce XL', 0, 0, 0, 0, 0, 68, 8, 514, 804, 0, 0, NULL, -40.9311, -40.9311, 15.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Giga Arkam GTX: Un motor con cuernos metálicos.', 0, 0, 0, 0, 0, 68, 8, 515, 805, 0, 0, NULL, -62.01, -62.01, 20.67, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Neo Neutro GT: Un objeto pequeño d&#39;or con linux, malware y chasis de fibra de carbono.', 0, 0, 0, 0, 0, 68, 8, 516, 806, 0, 0, NULL, -40.4, -40.4, 40.4, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Max Box GTX: Una targeta gráfica (GPU) con Wifi 4G, un palo y tecnología digitrónica 4.1.', 0, 25, 0, 0, 0, 68, 8, 517, 807, 0, 0, NULL, -49, -36.75, 49, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Hiper Generator XP: Una alcachofa con:\n- un posavasos\n- faros de xenon\n- reproductor 4k\n- malware.', 0, 0, 0, 0, 0, 68, 8, 518, 808, 0, 0, NULL, -27.34, -27.34, 13.67, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 68, 8, 519, 809, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 68, 8, 520, 810, 0, 0, NULL, -120, -120, 120, 0, '1', NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 68, 8, 521, 811, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(2.14, NULL, 'Broken Generator XP', 0, 0, 0, 0, 0, 21, 8, 522, 385, 0, 0, NULL, 34.24, 34.24, 16, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Jex Labtech SE: Un objeto pequeño d&#39;or con:\n- tecnología digitrónica 4.1\n- 64 núcleos\n- reproductor 4k\n- un palo.', 0, 0, 0, 0, 0, 21, 8, 523, 386, 0, 0, NULL, 47, 47, 47, 0, NULL, NULL, 0, 1, 1),
(12, NULL, 'Mega Neutro XXL: Un coche con:\n- chasis de fibra de carbono\n- 16 ejes\n- tecnología digitrónica 4.1\n- un núcleo híbrido.', 0, 0, 0, 0, 0, 21, 8, 524, 387, 0, 0, NULL, 312, 312, 26, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Extreme Tool SE: Un coche con un palo, un núcleo híbrido y un ambientador de pino.', 0, 0, 0, 0, 0, 21, 8, 525, 388, 0, 0, NULL, 52, 52, 26, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Super Station XL', 0, 0, 0, 0, 0, 21, 8, 526, 390, 0, 0, NULL, 96, 96, 48, 0, NULL, NULL, 0, 1, 1),
(14, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 21, 8, 527, 392, 0, 0, NULL, 1400, 1400, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 21, 8, 528, 395, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 21, 8, 529, 399, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1.6, NULL, 'Maxi Generator OS', 0, 0, 0, 0, 0, 25, 8, 530, 434, 0, 0, NULL, 43.2, 43.2, 27, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Labtech GTX: Una targeta gráfica (GPU) con cuernos metálicos, memoria HBM, 16 ejes y la virginidad intacta.', 0, 16, 0, 0, 0, 25, 8, 531, 436, 0, 0, NULL, 27.42, 23.0328, 9.14, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Extreme Generator Nitro: Un magnetofón con:\n- faros de xenon\n- propiedades psicotrópicas\n- un núcleo híbrido\n- la virginidad intacta.', 0, 16, 0, 0, 0, 25, 8, 532, 438, 0, 0, NULL, 144, 120.96, 48, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Minga Radeon 3: Un palo con:\n- memoria HBM\n- un palo\n- tecnología digitrónica 4.1\n- 16 ejes.', 0, 0, 0, 0, 0, 25, 8, 533, 441, 0, 0, NULL, 114, 114, 38, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Box XXL: Un objeto pequeño d&#39;or con malware, Windows Vista, pantalla Super AMOLED y propiedades psicotrópicas.', 0, 30, 0, 0, 0, 25, 8, 534, 443, 0, 0, NULL, 114, 79.8, 38, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jet Oviode NX: Un procesador con un núcleo híbrido, malware y 1024 stream processors.', 0, 0, 0, 0, 0, 25, 8, 535, 445, 0, 0, NULL, 82, 82, 41, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Jex Generator NX', 0, 5, 0, 0, 0, 25, 8, 536, 447, 0, 0, NULL, 31.68, 30.096, 10.56, 0, NULL, NULL, 0, 1, 1),
(2.43, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 25, 8, 537, 449, 0, 0, NULL, 1215, 1215, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 5, 0, 0, 0, 25, 8, 538, 453, 0, 0, NULL, 236.22, 224.409, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 10, 0, 0, 0, 25, 8, 539, 455, 0, 0, NULL, 360, 324, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Ultra GeForce NX: Un motor con reproductor 4k, un núcleo híbrido y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 29, 8, 540, 544, 0, 0, NULL, 18, 18, 6, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'FX Oviode II: Un dispositivo tecnológico con linux, faros de xenon, un posavasos y 32 pistones digitales.', 0, 0, 0, 0, 0, 29, 8, 541, 546, 0, 0, NULL, 326, 326, 326, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Radeon NX', 0, 8, 0, 0, 0, 29, 8, 542, 548, 0, 0, NULL, 12, 11.04, 12, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 29, 8, 543, 550, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 29, 8, 544, 554, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 29, 8, 545, 558, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Pro nForce GTX: un cubo de basura con memoria HBM, malware y 32 pistones digitales.', 0, 33, 0, 0, 0, 22, 8, 546, 389, 0, 0, NULL, 34.14, 22.8738, 11.38, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi Oviode XXL: un cubo de basura con memoria HBM, taladro matricial, chasis de fibra de carbono y 32 pistones digitales.', 0, 2, 0, 0, 0, 22, 8, 547, 391, 0, 0, NULL, 12.43, 12.1814, 12.43, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Neo Tool 3: Un objeto pequeño d&#39;or con 32 pistones digitales, malware y cuernos metálicos.', 0, 0, 0, 0, 0, 22, 8, 548, 393, 0, 0, NULL, 39, 39, 13, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Engine GT: Un objeto pequeño d&#39;or con:\n- reproductor 4k\n- frenos de berilio\n- la virginidad intacta\n- malware.', 0, 0, 0, 0, 0, 22, 8, 549, 394, 0, 0, NULL, 1167, 1167, 389, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Max Motor GTX', 0, 0, 0, 0, 0, 22, 8, 550, 396, 0, 0, NULL, 75, 75, 25, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Generator XL', 0, 0, 0, 0, 0, 22, 8, 551, 397, 0, 0, NULL, 30.33, 30.33, 30.33, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Alumno', 0, 0, 0, 0, 0, 22, 8, 552, 398, 0, 0, NULL, 236.22, 236.22, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 22, 8, 553, 400, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 2, 0, 0, 0, 22, 8, 554, 401, 0, 0, NULL, 100, 98, 100, 0, '2', NULL, 0, 1, 1),
(-2, NULL, 'Jex Labtech XL: Un dispositivo tecnológico con chasis de fibra de carbono, tecnología digitrónica 4.1 y un ambientador de pino.', 0, 15, 0, 0, 0, 71, 8, 555, 827, 0, 0, NULL, -86, -73.1, 43, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Broken Radeon XP: Un coche con frenos de berilio, propiedades psicotrópicas, la virginidad intacta y linux.', 0, 0, 0, 0, 0, 71, 8, 556, 828, 0, 0, NULL, -76, -76, 38, 0, NULL, NULL, 0, 1, 1),
(-10, NULL, 'Jet Generator XP', 0, 0, 0, 0, 0, 71, 8, 557, 829, 0, 0, NULL, -20, -20, 2, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Ultra Station GT: Un palo con reproductor 4k, malignas intenciones, 32 pistones digitales y 16 ejes.', 0, 0, 0, 0, 0, 71, 8, 558, 830, 0, 0, NULL, -144, -144, 48, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Super Motor Pro: Un palo con 64 núcleos, un posavasos, 8 cilindros en V y un palo.', 0, 0, 0, 0, 0, 71, 8, 559, 831, 0, 0, NULL, -42, -42, 14, 0, NULL, NULL, 0, 1, 1),
(-2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 71, 8, 560, 832, 0, 0, NULL, -1000, -1000, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 71, 8, 561, 833, 0, 0, NULL, -360, -360, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 71, 8, 562, 834, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(3, NULL, 'Mega Oviode 3', 0, 0, 0, 0, 0, 35, 8, 563, 617, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Pro GeForce GT: un cubo de basura con:\n- 8 cilindros en V\n- un ambientador de pino\n- chasis de fibra de carbono\n- la virginidad intacta.', 0, 0, 0, 0, 0, 35, 8, 564, 619, 0, 0, NULL, 138, 138, 46, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 35, 8, 565, 620, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 35, 8, 566, 622, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 35, 8, 567, 624, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR105', 'Ultra Arco 3', 0, 0, 0, 0, 0, 55, 8, 568, 736, 0, 10.5, NULL, 3, 3, 3, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Broken Neutro GT: &quot;La hostia&quot; con malware.', 0, 0, 0, 0, 0, 55, 8, 569, 737, 0, 10.5, NULL, 40, 40, 20, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'Minga Engine OS: Un coche con 1024 stream processors, 64 núcleos, la virginidad intacta y taladro matricial.', 0, 0, 0, 0, 0, 55, 8, 570, 738, 0, 10.5, NULL, 8, 8, 4, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Giga Labtech 3: Un objeto pequeño d&#39;or con faros de xenon.', 0, 0, 0, 0, 0, 55, 8, 571, 739, 0, 10.5, NULL, 41, 41, 41, 0, NULL, NULL, 0, 1, 1),
(2.667, 'AR105', 'Ultra GeForce GT: Un procesador con un núcleo híbrido, un palo, 32 pistones digitales y 1024 stream processors.', 0, 0, 0, 0, 0, 55, 8, 572, 740, 0, 10.5, NULL, 112.014, 112.014, 42, 0, NULL, NULL, 0, 1, 1),
(2, 'AR105', 'FX GeForce 3: &quot;La hostia&quot; con la virginidad intacta, pantalla Super AMOLED, un núcleo híbrido y Wifi 4G.', 0, 0, 0, 0, 0, 55, 8, 573, 741, 0, 10.5, NULL, 86, 86, 43, 0, NULL, NULL, 0, 1, 1),
(10, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 55, 8, 574, 742, 0, 0, NULL, 1000, 1000, 100, 0, '2', NULL, 0, 1, 1),
(2, 'AR21', 'Matias Carrizo', 0, 20, 0, 0, 0, 55, 8, 575, 743, 0, 21, NULL, 1000, 800, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 55, 8, 576, 744, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(-3, NULL, 'Jex Labtech XL', 0, 5, 0, 0, 0, 26, 8, 577, 493, 0, 0, NULL, -106.29, -100.9755, 35.43, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'FX Arco GT: Un palo con 1024 stream processors.', 0, 0, 0, 0, 0, 26, 8, 578, 495, 0, 0, NULL, -39.99, -39.99, 13.33, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Maxi Station GTX: Una targeta gráfica (GPU) con un palo, frenos de berilio, spyware y 32 pistones digitales.', 0, 0, 0, 0, 0, 26, 8, 579, 497, 0, 0, NULL, -55.5, -55.5, 18.5, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Hiper Station NX: Una targeta gráfica (GPU) con reproductor 4k, un palo y malware.', 0, 0, 0, 0, 0, 26, 8, 580, 499, 0, 0, NULL, -21, -21, 7, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Pro Oviode Pro', 0, 0, 0, 0, 0, 26, 8, 581, 501, 0, 0, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 26, 8, 582, 503, 0, 0, NULL, -500, -500, 500, 0, '4', NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 26, 8, 583, 507, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 26, 8, 584, 509, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(1, NULL, 'Broken Generator XP', 0, 0, 0, 0, 0, 45, 8, 585, 672, 0, 0, NULL, 697, 697, 697, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Jex Labtech SE: Un objeto pequeño d&#39;or con tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 45, 8, 586, 673, 0, 0, NULL, 18, 18, 9, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Mega Neutro XXL: Un coche con chasis de fibra de carbono.', 0, 0, 0, 0, 0, 45, 8, 587, 674, 0, 0, NULL, 4.5, 4.5, 4.5, 0, NULL, NULL, 0, 1, 1),
(13, NULL, 'Extreme Tool SE: Un coche con un palo, un núcleo híbrido, un ambientador de pino y la virginidad intacta.', 0, 0, 0, 0, 0, 45, 8, 588, 675, 0, 0, NULL, 390, 390, 30, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 45, 8, 589, 676, 0, 0, NULL, 100, 100, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 45, 8, 590, 677, 0, 0, NULL, 360, 360, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 45, 8, 591, 678, 0, 0, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 45, 8, 592, 679, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Giga Tool 3: Una targeta gráfica (GPU) con:\n- chasis de fibra de carbono\n- taladro matricial\n- un ambientador de pino\n- spyware.', 0, 0, 0, 0, 0, 30, 8, 593, 562, 0, 0, NULL, 13, 13, 13, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Giga Generator XL: Un objeto pequeño d&#39;or con Windows Vista.', 0, 0, 0, 0, 0, 30, 8, 594, 564, 0, 0, NULL, 84, 84, 28, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Hiper GeForce Nitro: Una alcachofa con faros de xenon.', 0, 0, 0, 0, 0, 30, 8, 595, 566, 0, 0, NULL, 86.5, 86.5, 43.25, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Maxi GeForce II', 0, 0, 0, 0, 0, 30, 8, 596, 568, 0, 0, NULL, 81, 81, 27, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Maxi GeForce 3: Un procesador con:\n- la virginidad intacta\n- propiedades psicotrópicas\n- un palo\n- faros de xenon.', 0, 0, 0, 0, 0, 30, 8, 597, 570, 0, 0, NULL, 541, 541, 541, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Giga Labtech GT: Una alcachofa con frenos de berilio, tecnología digitrónica 4.1, malware y taladro matricial.', 0, 0, 0, 0, 0, 30, 8, 598, 572, 0, 0, NULL, 10, 10, 5, 0, NULL, NULL, 0, 1, 1),
(7, NULL, 'Ultra Radeon XL', 0, 0, 0, 0, 0, 30, 8, 599, 574, 0, 0, NULL, 77, 77, 11, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 31, 0, 0, 0, 30, 8, 600, 576, 0, 0, NULL, 300, 207, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 30, 8, 601, 580, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(9, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 30, 8, 602, 582, 0, 0, NULL, 4500, 4500, 500, 0, '4', NULL, 0, 1, 1),
(3, 'AR21', 'Broken Arkam GT: Un magnetofón con un ambientador de pino, cuernos metálicos y memoria HBM.', 0, 33, 0, 0, 0, 2, 8, 603, 8, 0, 21, NULL, 123, 82.41, 41, 0, NULL, NULL, 0, 1, 1),
(1, 'AR27', 'Alumno', 0, 23, 0, 0, 0, 2, 8, 604, 9, 0, 27, NULL, 118.11, 90.9447, 118.11, 0, '3', NULL, 0, 1, 1),
(3, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 2, 8, 605, 10, 0, 21, NULL, 1500, 1500, 500, 0, '4', NULL, 0, 1, 1),
(4, NULL, 'jose ferrari jr', 0, 22, 0, 0, 0, 2, 8, 606, 11, 0, 0, NULL, 400, 312, 100, 0, '2', NULL, 0, 1, 1),
(3, NULL, 'Alumno', 0, 0, 0, 0, 0, 63, 8, 607, 781, 0, 0, NULL, 354.33, 354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 63, 8, 608, 782, 0, 0, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 52, 8, 609, 716, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(1.57, NULL, 'Juan Perez Jr.', 0, 28, 0, 0, 0, 52, 8, 610, 717, 0, 0, NULL, 188.4, 135.648, 120, 0, '1', NULL, 0, 1, 1),
(2.2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 52, 8, 611, 718, 0, 0, NULL, 220, 220, 100, 0, '2', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 16, 8, 612, 350, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(7, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 16, 8, 613, 353, 0, 0, NULL, 3500, 3500, 500, 0, '4', NULL, 0, 1, 1),
(13, NULL, 'Alumno', 0, 0, 0, 0, 0, 16, 8, 614, 356, 0, 0, NULL, 1535.43, 1535.43, 118.11, 0, '3', NULL, 0, 1, 1),
(-1, NULL, 'Minga GeForce XXL', 0, 0, 0, 0, 0, 58, 8, 615, 758, 0, 0, NULL, -15, -15, 15, 0, NULL, NULL, 0, 1, 1),
(-3, NULL, 'Alumno', 0, 0, 0, 0, 0, 58, 8, 616, 759, 0, 0, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'Juan Perez Jr.', 0, 59, 0, 0, 0, 58, 8, 617, 760, 0, 0, NULL, -360, -147.6, 120, 0, '1', NULL, 0, 1, 1),
(-2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 58, 8, 618, 761, 0, 0, NULL, -200, -200, 100, 0, '2', NULL, 0, 1, 1),
(-3, NULL, 'Matias Carrizo', 0, 14, 0, 0, 0, 58, 8, 619, 762, 0, 0, NULL, -1500, -1290, 500, 0, '4', NULL, 0, 1, 1),
(-1, 'AR21', 'Jet Box XXL', 0, 0, 0, 0, 0, 5, 8, 620, 153, 0, 21, NULL, -24, -24, 24, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Minga Proton OS: Un motor con reproductor 4k, frenos de berilio y tecnología digitrónica 4.1.', 0, 0, 0, 0, 0, 5, 8, 621, 154, 0, 21, NULL, -46.83, -46.83, 46.83, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Maxi Labtech NX: Un magnetofón con:\n- frenos de berilio\n- un ambientador de pino\n- 64 núcleos\n- reproductor 4k.', 0, 0, 0, 0, 0, 5, 8, 622, 155, 0, 21, NULL, -256, -256, 256, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Jex nForce Nitro: Un dispositivo tecnológico con 64 núcleos, frenos de berilio, taladro matricial y la virginidad intacta.', 0, 0, 0, 0, 0, 5, 8, 623, 156, 0, 21, NULL, -21, -21, 21, 0, NULL, NULL, 0, 1, 1),
(-1, 'AR21', 'Super Oviode XL', 0, 0, 0, 0, 0, 5, 8, 624, 157, 0, 21, NULL, -43, -43, 43, 0, NULL, NULL, 0, 1, 1),
(-19, 'AR21', 'Minga Proton GTX: Un procesador con taladro matricial.', 0, 8, 0, 0, 0, 5, 8, 625, 158, 0, 21, NULL, -627, -576.84, 33, 0, NULL, NULL, 0, 1, 1);
INSERT INTO `lineasfacturascli` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `dtopor2`, `dtopor3`, `dtopor4`, `idalbaran`, `idfactura`, `idlinea`, `idlineaalbaran`, `irpf`, `iva`, `porcomision`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`, `orden`, `mostrar_cantidad`, `mostrar_precio`) VALUES
(-2, 'AR21', 'Ultra Box NX: Un palo con:\n- la virginidad intacta\n- reproductor 4k\n- 32 pistones digitales\n- propiedades psicotrópicas.', 0, 0, 0, 0, 0, 5, 8, 626, 159, 0, 21, NULL, -4, -4, 2, 0, NULL, NULL, 0, 1, 1),
(-3, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 5, 8, 627, 160, 0, 27, NULL, -354.33, -354.33, 118.11, 0, '3', NULL, 0, 1, 1),
(-3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 5, 8, 628, 161, 0, 0, NULL, -300, -300, 100, 0, '2', NULL, 0, 1, 1),
(-19, 'AR21', 'Matias Carrizo', 0, 13, 0, 0, 0, 5, 8, 629, 162, 0, 21, NULL, -9500, -8265, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Broken Neutro 3', 0, 0, 0, 0, 0, 56, 8, 630, 745, 0, 0, NULL, 223, 223, 223, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Fusion Engine SE: Un procesador con un núcleo híbrido, pantalla Super AMOLED, reproductor 4k y un posavasos.', 0, 82, 0, 0, 0, 56, 8, 631, 746, 0, 0, NULL, 69, 12.42, 23, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Fusion Tool XP: &quot;La hostia&quot; con:\n- frenos de berilio\n- 16 ejes\n- Windows Vista\n- malignas intenciones.', 0, 0, 0, 0, 0, 56, 8, 632, 747, 0, 0, NULL, 32, 32, 32, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Neo GeForce OS: Un magnetofón con 1024 stream processors, faros de xenon y frenos de berilio.', 0, 0, 0, 0, 0, 56, 8, 633, 748, 0, 0, NULL, 54, 54, 27, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Hiper Oviode Pro: Una alcachofa con Wifi 4G.', 0, 0, 0, 0, 0, 56, 8, 634, 749, 0, 0, NULL, 16.11, 16.11, 16.11, 0, NULL, NULL, 0, 1, 1),
(2, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 56, 8, 635, 750, 0, 0, NULL, 1000, 1000, 500, 0, '4', NULL, 0, 1, 1),
(1, NULL, 'Alumno', 0, 0, 0, 0, 0, 56, 8, 636, 751, 0, 0, NULL, 118.11, 118.11, 118.11, 0, '3', NULL, 0, 1, 1),
(2, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 56, 8, 637, 752, 0, 0, NULL, 200, 200, 100, 0, '2', NULL, 0, 1, 1),
(1, 'AR105', 'Minga Motor XP', 0, 13, 0, 0, 0, 53, 8, 638, 719, 0, 10.5, NULL, 15.38, 13.3806, 15.38, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Jex Generator Pro: un cubo de basura con chasis de fibra de carbono, un núcleo híbrido, un palo y propiedades psicotrópicas.', 0, 0, 0, 0, 0, 53, 8, 639, 720, 0, 10.5, NULL, 330, 330, 110, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Fusion Box XXL: Un objeto pequeño d&#39;or con faros de xenon.', 0, 0, 0, 0, 0, 53, 8, 640, 721, 0, 10.5, NULL, 12.99, 12.99, 4.33, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Sub Labtech NX: Un palo con:\n- taladro matricial\n- chasis de fibra de carbono\n- un núcleo híbrido\n- 8 cilindros en V.', 0, 17, 0, 0, 0, 53, 8, 641, 722, 0, 10.5, NULL, 17, 14.11, 17, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Max Motor Pro', 0, 38, 0, 0, 0, 53, 8, 642, 723, 0, 10.5, NULL, 12, 7.44, 4, 0, NULL, NULL, 0, 1, 1),
(3, 'AR105', 'Pro Arkam NX: Un dispositivo tecnológico con un palo.', 0, 3, 0, 0, 0, 53, 8, 643, 724, 0, 10.5, NULL, 54.75, 53.1075, 18.25, 0, NULL, NULL, 0, 1, 1),
(1, 'AR105', 'Giga Station OS: Un magnetofón con frenos de berilio.', 0, 0, 0, 0, 0, 53, 8, 644, 725, 0, 10.5, NULL, 49, 49, 49, 0, NULL, NULL, 0, 1, 1),
(2.11, 'AR27', 'Alumno', 0, 0, 0, 0, 0, 53, 8, 645, 726, 0, 27, NULL, 249.2121, 249.2121, 118.11, 0, '3', NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 53, 8, 646, 727, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(1, 'AR21', 'Matias Carrizo', 0, 0, 0, 0, 0, 53, 8, 647, 728, 0, 21, NULL, 500, 500, 500, 0, '4', NULL, 0, 1, 1),
(3, NULL, 'Hiper Engine Pro: Un motor con 16 ejes.', 0, 0, 0, 0, 0, 50, 8, 648, 703, 0, 0, NULL, 129, 129, 43, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Extreme Generator OS: Un dispositivo tecnológico con:\n- un ambientador de pino\n- un posavasos\n- chasis de fibra de carbono\n- reproductor 4k.', 0, 0, 0, 0, 0, 50, 8, 649, 704, 0, 0, NULL, 36, 36, 36, 0, NULL, NULL, 0, 1, 1),
(2.5, NULL, 'FX Motor OS: Un coche con:\n- frenos de berilio\n- faros de xenon\n- un ambientador de pino\n- linux.', 0, 0, 0, 0, 0, 50, 8, 650, 705, 0, 0, NULL, 122.5, 122.5, 49, 0, NULL, NULL, 0, 1, 1),
(3, NULL, 'Super Arkam GT', 0, 99, 0, 0, 0, 50, 8, 651, 706, 0, 0, NULL, 94.68, 0.9468, 31.56, 0, NULL, NULL, 0, 1, 1),
(1, NULL, 'Juan Perez Jr.', 0, 0, 0, 0, 0, 50, 8, 652, 707, 0, 0, NULL, 120, 120, 120, 0, '1', NULL, 0, 1, 1),
(3, NULL, 'jose ferrari jr', 0, 0, 0, 0, 0, 50, 8, 653, 708, 0, 0, NULL, 300, 300, 100, 0, '2', NULL, 0, 1, 1),
(14, NULL, 'Matias Carrizo', 0, 0, 0, 0, 0, 50, 8, 654, 709, 0, 0, NULL, 7000, 7000, 500, 0, '4', NULL, 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasfacturasprov`
--

CREATE TABLE `lineasfacturasprov` (
  `cantidad` double NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL,
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `idlineaalbaran` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double DEFAULT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codcombinacion` varchar(18) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasfacturasprov`
--

INSERT INTO `lineasfacturasprov` (`cantidad`, `codimpuesto`, `codsubcuenta`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idfactura`, `idlinea`, `idlineaalbaran`, `idsubcuenta`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`, `codcombinacion`) VALUES
(3, 'AR27', NULL, 'Alumno', 0, 0, NULL, 1, 1, NULL, NULL, 0, 27, 450, 450, 150, 0, '3', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasivafactcli`
--

CREATE TABLE `lineasivafactcli` (
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `recargo` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totallinea` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasivafactcli`
--

INSERT INTO `lineasivafactcli` (`codimpuesto`, `idfactura`, `idlinea`, `iva`, `neto`, `recargo`, `totaliva`, `totallinea`, `totalrecargo`) VALUES
('AR21', 1, 1, 21, 138.36, 0, 29.05, 167.41, 0),
('AR27', 4, 2, 27, 300, 0, 81, 381, 0),
('AR27', 4, 3, 27, 300, 0, 81, 381, 0),
('AR21', 5, 4, 21, 500, 0, 105, 605, 0),
('AR0', 2, 5, 0, 120, 0, 0, 120, 0),
('AR0', 2, 6, 0, 120, 0, 0, 120, 0),
('0', 6, 7, 0, 12189.12, 0, 0, 12189.12, 0),
('AR21', 6, 8, 21, 30769.1, 0, 6461.51, 37230.61, 0),
('AR27', 6, 9, 27, 862.2, 0, 232.79, 1094.99, 0),
('AR105', 6, 10, 10.5, 467.43, 0, 49.08, 516.51, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasivafactprov`
--

CREATE TABLE `lineasivafactprov` (
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `recargo` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totallinea` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `lineasivafactprov`
--

INSERT INTO `lineasivafactprov` (`codimpuesto`, `idfactura`, `idlinea`, `iva`, `neto`, `recargo`, `totaliva`, `totallinea`, `totalrecargo`) VALUES
('AR27', 1, 1, 27, 450, 0, 121.5, 571.5, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineasregstocks`
--

CREATE TABLE `lineasregstocks` (
  `cantidadfin` double NOT NULL DEFAULT '0',
  `cantidadini` double NOT NULL DEFAULT '0',
  `codalmacendest` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id` int(11) NOT NULL,
  `idstock` int(11) NOT NULL,
  `motivo` text COLLATE utf8_bin,
  `nick` varchar(12) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineastransstock`
--

CREATE TABLE `lineastransstock` (
  `cantidad` double NOT NULL,
  `descripcion` text COLLATE utf8_bin,
  `idlinea` int(11) NOT NULL,
  `idtrans` int(11) NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
  `validarprov` tinyint(1) DEFAULT NULL,
  `codiso` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `bandera` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
(NULL, 'AX', NULL, 'Islas Gland', 'ALA'),
(NULL, 'AE', NULL, 'Emiratos Árabes Unidos', 'ARE'),
(NULL, 'AR', NULL, 'Argentina', 'ARG'),
(NULL, 'AS', NULL, 'Samoa Americana', 'ASM'),
(NULL, 'TF', NULL, 'Territorios Australes Franceses', 'ATF'),
(NULL, 'BV', NULL, 'Isla Bouvet', 'BVT'),
(NULL, 'CF', NULL, 'República Centroafricana', 'CAF'),
(NULL, 'CC', NULL, 'Islas Cocos', 'CCK'),
(NULL, 'CH', NULL, 'Suiza', 'CHE'),
(NULL, 'CI', NULL, 'Costa de Marfil', 'CIV'),
(NULL, 'CD', NULL, 'República Democrática del Congo', 'COD'),
(NULL, 'CK', NULL, 'Islas Cook', 'COK'),
(NULL, 'CR', NULL, 'Costa Rica', 'CRI'),
(NULL, 'CU', NULL, 'Cuba', 'CUB'),
(NULL, 'CX', NULL, 'Isla de Navidad', 'CXR'),
(NULL, 'KY', NULL, 'Islas Caimán', 'CYM'),
(NULL, 'CZ', NULL, 'República Checa', 'CZE'),
(NULL, 'DJ', NULL, 'Yibuti', 'DJI'),
(NULL, 'DM', NULL, 'Dominica', 'DMA'),
(NULL, 'DK', NULL, 'Dinamarca', 'DNK'),
(NULL, 'DO', NULL, 'República Dominicana', 'DOM'),
(NULL, 'EC', NULL, 'Ecuador', 'ECU'),
(NULL, 'EG', NULL, 'Egipto', 'EGY'),
(NULL, 'ER', NULL, 'Eritrea', 'ERI'),
(NULL, 'EH', NULL, 'Sahara Occidental', 'ESH'),
(NULL, 'ES', NULL, 'España', 'ESP'),
(NULL, 'EE', NULL, 'Estonia', 'EST'),
(NULL, 'ET', NULL, 'Etiopía', 'ETH'),
(NULL, 'FI', NULL, 'Finlandia', 'FIN'),
(NULL, 'FJ', NULL, 'Fiyi', 'FJI'),
(NULL, 'FK', NULL, 'Islas Malvinas', 'FLK'),
(NULL, 'FR', NULL, 'Francia', 'FRA'),
(NULL, 'FO', NULL, 'Islas Feroe', 'FRO'),
(NULL, 'FM', NULL, 'Micronesia', 'FSM'),
(NULL, 'GA', NULL, 'Gabón', 'GAB'),
(NULL, 'GB', NULL, 'Reino Unido', 'GBR'),
(NULL, 'GE', NULL, 'Georgia', 'GEO'),
(NULL, 'GH', NULL, 'Ghana', 'GHA'),
(NULL, 'GI', NULL, 'Gibraltar', 'GIB'),
(NULL, 'GN', NULL, 'Guinea', 'GIN'),
(NULL, 'GP', NULL, 'Guadalupe', 'GLP'),
(NULL, 'GM', NULL, 'Gambia', 'GMB'),
(NULL, 'GW', NULL, 'Guinea-Bissau', 'GNB'),
(NULL, 'GQ', NULL, 'Guinea Ecuatorial', 'GNQ'),
(NULL, 'GR', NULL, 'Grecia', 'GRC'),
(NULL, 'GD', NULL, 'Granada', 'GRD'),
(NULL, 'GL', NULL, 'Groenlandia', 'GRL'),
(NULL, 'GT', NULL, 'Guatemala', 'GTM'),
(NULL, 'GF', NULL, 'Guayana Francesa', 'GUF'),
(NULL, 'GU', NULL, 'Guam', 'GUM'),
(NULL, 'GY', NULL, 'Guyana', 'GUY'),
(NULL, 'HK', NULL, 'Hong Kong', 'HKG'),
(NULL, 'HM', NULL, 'Islas Heard y McDonald', 'HMD'),
(NULL, 'HN', NULL, 'Honduras', 'HND'),
(NULL, 'HR', NULL, 'Croacia', 'HRV'),
(NULL, 'HT', NULL, 'Haití', 'HTI'),
(NULL, 'HU', NULL, 'Hungría', 'HUN'),
(NULL, 'ID', NULL, 'Indonesia', 'IDN'),
(NULL, 'IN', NULL, 'India', 'IND'),
(NULL, 'IO', NULL, 'Territorio Británico del Océano Índico', 'IOT'),
(NULL, 'IE', NULL, 'Irlanda', 'IRL'),
(NULL, 'IR', NULL, 'Irán', 'IRN'),
(NULL, 'IQ', NULL, 'Iraq', 'IRQ'),
(NULL, 'IS', NULL, 'Islandia', 'ISL'),
(NULL, 'IL', NULL, 'Israel', 'ISR'),
(NULL, 'IT', NULL, 'Italia', 'ITA'),
(NULL, 'JM', NULL, 'Jamaica', 'JAM'),
(NULL, 'JO', NULL, 'Jordania', 'JOR'),
(NULL, 'JP', NULL, 'Japón', 'JPN'),
(NULL, 'KZ', NULL, 'Kazajstán', 'KAZ'),
(NULL, 'KE', NULL, 'Kenia', 'KEN'),
(NULL, 'KG', NULL, 'Kirguistán', 'KGZ'),
(NULL, 'KI', NULL, 'Kiribati', 'KIR'),
(NULL, 'KN', NULL, 'San Cristóbal y Nieves', 'KNA'),
(NULL, 'KR', NULL, 'Corea del Sur', 'KOR'),
(NULL, 'KW', NULL, 'Kuwait', 'KWT'),
(NULL, 'LA', NULL, 'Laos', 'LAO'),
(NULL, 'LB', NULL, 'Líbano', 'LBN'),
(NULL, 'LR', NULL, 'Liberia', 'LBR'),
(NULL, 'LY', NULL, 'Libia', 'LBY'),
(NULL, 'LC', NULL, 'Santa Lucía', 'LCA'),
(NULL, 'LI', NULL, 'Liechtenstein', 'LIE'),
(NULL, 'LK', NULL, 'Sri Lanka', 'LKA'),
(NULL, 'LS', NULL, 'Lesotho', 'LSO'),
(NULL, 'LT', NULL, 'Lituania', 'LTU'),
(NULL, 'LU', NULL, 'Luxemburgo', 'LUX'),
(NULL, 'LV', NULL, 'Letonia', 'LVA'),
(NULL, 'MO', NULL, 'Macao', 'MAC'),
(NULL, 'MA', NULL, 'Marruecos', 'MAR'),
(NULL, 'MC', NULL, 'Mónaco', 'MCO'),
(NULL, 'MD', NULL, 'Moldavia', 'MDA'),
(NULL, 'MG', NULL, 'Madagascar', 'MDG'),
(NULL, 'MV', NULL, 'Maldivas', 'MDV'),
(NULL, 'MX', NULL, 'México', 'MEX'),
(NULL, 'MH', NULL, 'Islas Marshall', 'MHL'),
(NULL, 'MK', NULL, 'Macedonia', 'MKD'),
(NULL, 'ML', NULL, 'Malí', 'MLI'),
(NULL, 'MT', NULL, 'Malta', 'MLT'),
(NULL, 'MM', NULL, 'Myanmar', 'MMR'),
(NULL, 'ME', NULL, 'Montenegro', 'MNE'),
(NULL, 'MN', NULL, 'Mongolia', 'MNG'),
(NULL, 'MP', NULL, 'Islas Marianas del Norte', 'MNP'),
(NULL, 'MZ', NULL, 'Mozambique', 'MOZ'),
(NULL, 'MR', NULL, 'Mauritania', 'MRT'),
(NULL, 'MS', NULL, 'Montserrat', 'MSR'),
(NULL, 'MQ', NULL, 'Martinica', 'MTQ'),
(NULL, 'MU', NULL, 'Mauricio', 'MUS'),
(NULL, 'MW', NULL, 'Malaui', 'MWI'),
(NULL, 'MY', NULL, 'Malasia', 'MYS'),
(NULL, 'YT', NULL, 'Mayotte', 'MYT'),
(NULL, 'NA', NULL, 'Namibia', 'NAM'),
(NULL, 'NC', NULL, 'Nueva Caledonia', 'NCL'),
(NULL, 'NE', NULL, 'Níger', 'NER'),
(NULL, 'NF', NULL, 'Isla Norfolk', 'NFK'),
(NULL, 'NG', NULL, 'Nigeria', 'NGA'),
(NULL, 'NI', NULL, 'Nicaragua', 'NIC'),
(NULL, 'NU', NULL, 'Niue', 'NIU'),
(NULL, 'NL', NULL, 'Países Bajos', 'NLD'),
(NULL, 'NO', NULL, 'Noruega', 'NOR'),
(NULL, 'NP', NULL, 'Nepal', 'NPL'),
(NULL, 'NR', NULL, 'Nauru', 'NRU'),
(NULL, 'NZ', NULL, 'Nueva Zelanda', 'NZL'),
(NULL, 'OM', NULL, 'Omán', 'OMN'),
(NULL, 'PK', NULL, 'Pakistán', 'PAK'),
(NULL, 'PA', NULL, 'Panamá', 'PAN'),
(NULL, 'PN', NULL, 'Islas Pitcairn', 'PCN'),
(NULL, 'PE', NULL, 'Perú', 'PER'),
(NULL, 'PH', NULL, 'Filipinas', 'PHL'),
(NULL, 'PW', NULL, 'Palaos', 'PLW'),
(NULL, 'PG', NULL, 'Papúa Nueva Guinea', 'PNG'),
(NULL, 'PL', NULL, 'Polonia', 'POL'),
(NULL, 'PR', NULL, 'Puerto Rico', 'PRI'),
(NULL, 'PT', NULL, 'Portugal', 'PRT'),
(NULL, 'PY', NULL, 'Paraguay', 'PRY'),
(NULL, 'PS', NULL, 'Palestina', 'PSE'),
(NULL, 'PF', NULL, 'Polinesia Francesa', 'PYF'),
(NULL, 'QA', NULL, 'Qatar', 'QAT'),
(NULL, 'RE', NULL, 'Reunión', 'REU'),
(NULL, 'RO', NULL, 'Rumania', 'ROU'),
(NULL, 'RU', NULL, 'Rusia', 'RUS'),
(NULL, 'RW', NULL, 'Ruanda', 'RWA'),
(NULL, 'SD', NULL, 'Sudán', 'SDN'),
(NULL, 'SN', NULL, 'Senegal', 'SEN'),
(NULL, 'SG', NULL, 'Singapur', 'SGP'),
(NULL, 'GS', NULL, 'Islas Georgias del Sur y Sandwich del Sur', 'SGS'),
(NULL, 'SH', NULL, 'Santa Helena', 'SHN'),
(NULL, 'SJ', NULL, 'Svalbard y Jan Mayen', 'SJM'),
(NULL, 'SB', NULL, 'Islas Salomón', 'SLB'),
(NULL, 'SL', NULL, 'Sierra Leona', 'SLE'),
(NULL, 'SV', NULL, 'El Salvador', 'SLV'),
(NULL, 'SM', NULL, 'San Marino', 'SMR'),
(NULL, 'SO', NULL, 'Somalia', 'SOM'),
(NULL, 'PM', NULL, 'San Pedro y Miquelón', 'SPM'),
(NULL, 'RS', NULL, 'Serbia', 'SRB'),
(NULL, 'ST', NULL, 'Santo Tomé y Príncipe', 'STP'),
(NULL, 'SR', NULL, 'Surinam', 'SUR'),
(NULL, 'SK', NULL, 'Eslovaquia', 'SVK'),
(NULL, 'SI', NULL, 'Eslovenia', 'SVN'),
(NULL, 'SE', NULL, 'Suecia', 'SWE'),
(NULL, 'SZ', NULL, 'Suazilandia', 'SWZ'),
(NULL, 'SC', NULL, 'Seychelles', 'SYC'),
(NULL, 'SY', NULL, 'Siria', 'SYR'),
(NULL, 'TC', NULL, 'Islas Turcas y Caicos', 'TCA'),
(NULL, 'TG', NULL, 'Togo', 'TGO'),
(NULL, 'TH', NULL, 'Tailandia', 'THA'),
(NULL, 'TJ', NULL, 'Tayikistán', 'TJK'),
(NULL, 'TK', NULL, 'Tokelau', 'TKL'),
(NULL, 'TM', NULL, 'Turkmenistán', 'TKM'),
(NULL, 'TL', NULL, 'Timor Oriental', 'TLS'),
(NULL, 'TO', NULL, 'Tonga', 'TON'),
(NULL, 'TT', NULL, 'Trinidad y Tobago', 'TTO'),
(NULL, 'TN', NULL, 'Túnez', 'TUN'),
(NULL, 'TR', NULL, 'Turquía', 'TUR'),
(NULL, 'TV', NULL, 'Tuvalu', 'TUV'),
(NULL, 'TW', NULL, 'Taiwán', 'TWN'),
(NULL, 'TZ', NULL, 'Tanzania', 'TZA'),
(NULL, 'UG', NULL, 'Uganda', 'UGA'),
(NULL, 'UA', NULL, 'Ucrania', 'UKR'),
(NULL, 'UM', NULL, 'Islas Ultramarinas de Estados Unidos', 'UMI'),
(NULL, 'UY', NULL, 'Uruguay', 'URY'),
(NULL, 'US', NULL, 'Estados Unidos', 'USA'),
(NULL, 'UZ', NULL, 'Uzbekistán', 'UZB'),
(NULL, 'VC', NULL, 'San Vicente y las Granadinas', 'VCT'),
(NULL, 'VE', NULL, 'Venezuela', 'VEN'),
(NULL, 'VG', NULL, 'Islas Vírgenes Británicas', 'VGB'),
(NULL, 'VI', NULL, 'Islas Vírgenes de los Estados Unidos', 'VIR'),
(NULL, 'VN', NULL, 'Vietnam', 'VNM'),
(NULL, 'VU', NULL, 'Vanuatu', 'VUT'),
(NULL, 'WF', NULL, 'Wallis y Futuna', 'WLF'),
(NULL, 'WS', NULL, 'Samoa', 'WSM'),
(NULL, 'YE', NULL, 'Yemen', 'YEM'),
(NULL, 'ZA', NULL, 'Sudáfrica', 'ZAF'),
(NULL, 'ZM', NULL, 'Zambia', 'ZMB'),
(NULL, 'ZW', NULL, 'Zimbabue', 'ZWE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `cifnif` varchar(30) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentapago` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaportes` double DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recfinanciero` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `acreedor` tinyint(1) DEFAULT '0',
  `personafisica` tinyint(1) DEFAULT '1',
  `debaja` tinyint(1) DEFAULT '0',
  `fechabaja` date DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`cifnif`, `codcontacto`, `codcuentadom`, `codcuentapago`, `coddivisa`, `codpago`, `codproveedor`, `codserie`, `codsubcuenta`, `contacto`, `email`, `fax`, `idsubcuenta`, `ivaportes`, `nombre`, `razonsocial`, `observaciones`, `recfinanciero`, `regimeniva`, `telefono1`, `telefono2`, `tipoidfiscal`, `web`, `acreedor`, `personafisica`, `debaja`, `fechabaja`, `codcliente`) VALUES
('302221231', NULL, NULL, NULL, 'ARS', 'CONT', '000001', NULL, NULL, NULL, '', '', NULL, NULL, 'Escuela JFK', 'Escuela JFK', '', NULL, 'General', '', '', 'CUIT', '', 0, 0, 0, '2018-08-01', '000002');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secuencias`
--

CREATE TABLE `secuencias` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `idsec` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `secuencias`
--

INSERT INTO `secuencias` (`descripcion`, `id`, `idsec`, `nombre`, `valor`, `valorout`) VALUES
('Secuencia del ejercicio 2018 y la serie A', 1, 1, 'nfacturacli', 1, 8),
('Secuencia del ejercicio 2018 y la serie B', 3, 2, 'nfacturacli', 1, 2),
('Secuencia del ejercicio 2018 y la serie A', 1, 3, 'nfacturaprov', 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secuenciasejercicios`
--

CREATE TABLE `secuenciasejercicios` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL,
  `nalbarancli` int(11) NOT NULL,
  `nalbaranprov` int(11) NOT NULL,
  `nfacturacli` int(11) NOT NULL,
  `nfacturaprov` int(11) NOT NULL,
  `npedidocli` int(11) NOT NULL,
  `npedidoprov` int(11) NOT NULL,
  `npresupuestocli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `secuenciasejercicios`
--

INSERT INTO `secuenciasejercicios` (`codejercicio`, `codserie`, `id`, `nalbarancli`, `nalbaranprov`, `nfacturacli`, `nfacturaprov`, `npedidocli`, `npedidoprov`, `npresupuestocli`) VALUES
('2018', 'A', 1, 1, 1, 1, 1, 1, 1, 1),
('2018', 'R', 2, 1, 1, 1, 1, 1, 1, 1),
('2018', 'B', 3, 1, 1, 1, 1, 1, 1, 1),
('2018', 'C', 4, 1, 1, 1, 1, 1, 1, 1),
('2017', 'A', 5, 1, 1, 1, 1, 1, 1, 1),
('2017', 'B', 6, 1, 1, 1, 1, 1, 1, 1),
('2017', 'C', 7, 1, 1, 1, 1, 1, 1, 1),
('2017', 'R', 8, 1, 1, 1, 1, 1, 1, 1),
('2016', 'A', 9, 1, 1, 1, 1, 1, 1, 1),
('2016', 'B', 10, 1, 1, 1, 1, 1, 1, 1),
('2016', 'C', 11, 1, 1, 1, 1, 1, 1, 1),
('2016', 'R', 12, 1, 1, 1, 1, 1, 1, 1),
('2015', 'A', 13, 1, 1, 1, 1, 1, 1, 1),
('2015', 'B', 14, 1, 1, 1, 1, 1, 1, 1),
('2015', 'C', 15, 1, 1, 1, 1, 1, 1, 1),
('2015', 'R', 16, 1, 1, 1, 1, 1, 1, 1),
('2014', 'A', 17, 1, 1, 1, 1, 1, 1, 1),
('2014', 'B', 18, 1, 1, 1, 1, 1, 1, 1),
('2014', 'C', 19, 1, 1, 1, 1, 1, 1, 1),
('2014', 'R', 20, 1, 1, 1, 1, 1, 1, 1),
('2013', 'A', 21, 1, 1, 1, 1, 1, 1, 1),
('2013', 'B', 22, 1, 1, 1, 1, 1, 1, 1),
('2013', 'C', 23, 1, 1, 1, 1, 1, 1, 1),
('2013', 'R', 24, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `series`
--

CREATE TABLE `series` (
  `irpf` double DEFAULT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `siniva` tinyint(1) DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `numfactura` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `series`
--

INSERT INTO `series` (`irpf`, `idcuenta`, `codserie`, `descripcion`, `siniva`, `codcuenta`, `codejercicio`, `numfactura`) VALUES
(0, NULL, 'A', 'SERIE A', 0, NULL, NULL, 1),
(0, NULL, 'B', 'SERIE B', 0, NULL, NULL, 1),
(0, NULL, 'C', 'SERIE C', 0, NULL, NULL, 1),
(0, NULL, 'R', 'RECTIFICATIVAS', 0, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stocks`
--
-- en uso(#1033 - Incorrect information in file: '.\facturas1\stocks.frm')
-- Error leyendo datos: (#1033 - Incorrect information in file: '.\facturas1\stocks.frm')

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE `tarifas` (
  `incporcentual` double NOT NULL,
  `inclineal` double NOT NULL,
  `aplicar_a` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `mincoste` tinyint(1) DEFAULT '0',
  `maxpvp` tinyint(1) DEFAULT '0',
  `codtarifa` varchar(6) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`incporcentual`, `inclineal`, `aplicar_a`, `nombre`, `mincoste`, `maxpvp`, `codtarifa`) VALUES
(0, 0, 'pvp', '100', 0, 0, '000001'),
(0, -120, 'pvp', 'Preescolar', 0, 0, '000002'),
(0, -120, 'pvp', 'Primaria', 0, 0, '000003'),
(0, -150, 'pvp', 'Secundaria', 0, 0, '000004');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ticketprintjob`
--

CREATE TABLE `ticketprintjob` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `texto` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `ticketprintjob`
--

INSERT INTO `ticketprintjob` (`id`, `tipo`, `texto`) VALUES
(1, 'factura', '\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n           CUIT: CUIT: 30-54050846-8          \n=============================================\n\n               FACTURA FAC2018A1              \n              01-07-2018 20:29:01             \nCLIENTE: tito\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\n                                            3\ncuota mes agosto\nPVP:                                    58.00\nIMPORTE:                               138.36\n=============================================\nIVA                                     29.05\nTOTAL DEL DOCUMENT:                    167.41\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n           CUIT: CUIT: 30-54050846-8          \n=============================================\n\n               FACTURA FAC2018A1              \n              01-07-2018 20:29:01             \nCLIENTE: tito\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\n                                            3\ncuota mes agosto\nPVP:                                    58.00\nIMPORTE:                               138.36\n=============================================\nIVA                                     29.05\nTOTAL DEL DOCUMENT:                    167.41\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n---------------------------------------------\n              Instituto JFKennedy             \n               AV CONGRESO 1816               \n                  TEL: 422222                 \n\n  INSTITUTO PRIVADO JOHN FITTZGERALD KENNEDY  \n        CUIT/CUIL: CUIT: 30-54050846-8        \n=============================================\n\n               FACTURA FAC2018B1              \n              11-08-2018 13:07:35             \nCLIENTE: Perez Juan\n=============================================\nREFERENCIA                           CANTIDAD\n=============================================\nIVA                                      0.00\nTOTAL DEL DOCUMENT:                      0.00\n\n\n                  acme.com.ar                 \n\na1hFwH2kFAC2018B1\0\n\n\n\ni\n\n----------------------------------------\n           Instituto JFKennedy          \n            AV CONGRESO 1816            \n               TEL: 422222              \n\nINSTITUTO PRIVADO JOHN FITTZGERALD KENNE\n     CUIT/CUIL: CUIT: 30-54050846-8     \n========================================\n\n            FACTURA FAC2018A1           \n           01-07-2018 20:29:01          \nCLIENTE: tito\n========================================\nREFERENCIA                      CANTIDAD\n========================================\n                                       3\ncuota mes agosto\nPVP:                               58.00\nIMPORTE:                          138.36\n========================================\nIVA                                29.05\nTOTAL DEL DOCUMENT:               167.41\n\n\n               acme.com.ar              \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n\n----------------------------------------\n           Instituto JFKennedy          \n            AV CONGRESO 1816            \n               TEL: 422222              \n\nINSTITUTO PRIVADO JOHN FITTZGERALD KENNE\n     CUIT/CUIL: CUIT: 30-54050846-8     \n========================================\n\n            FACTURA FAC2018A1           \n           01-07-2018 20:29:01          \nCLIENTE: tito\n========================================\nREFERENCIA                      CANTIDAD\n========================================\n                                       3\ncuota mes agosto\nPVP:                               58.00\nIMPORTE:                          138.36\n========================================\nIVA                                29.05\nTOTAL DEL DOCUMENT:               167.41\n\n\n               acme.com.ar              \n\na1hFwH2kFAC2018A1\0\n\n\n\ni\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transstock`
--

CREATE TABLE `transstock` (
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `codalmadestino` varchar(4) COLLATE utf8_bin NOT NULL,
  `codalmaorigen` varchar(4) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `idtrans` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutores`
--

CREATE TABLE `tutores` (
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `nombre` text COLLATE utf8_bin NOT NULL,
  `apellido` text COLLATE utf8_bin NOT NULL,
  `documento` text COLLATE utf8_bin NOT NULL,
  `direccion` text COLLATE utf8_bin NOT NULL,
  `telefono` text COLLATE utf8_bin NOT NULL,
  `habilitado` tinyint(1) DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `fechacreado` date NOT NULL,
  `fechaactualizado` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `tutores`
--

INSERT INTO `tutores` (`referencia`, `nombre`, `apellido`, `documento`, `direccion`, `telefono`, `habilitado`, `descripcion`, `fechacreado`, `fechaactualizado`) VALUES
('123134', 'tutor2', 'si', 'si ', 'si', '', 1, 'si', '2018-08-29', '2018-08-29'),
('123135', 'qq', 'qq', 'qq', 'qq', '', 0, 'qq', '2018-08-31', '2018-08-31'),
('123136', 'sd', 'sd', 'sd', 'd', '5717472643', 1, 'sd', '2018-08-31', '2018-08-31'),
('123137', 'a', 'b', '12', 'ASD12', '123', 1, 'ASSDD2', '2018-10-03', '2018-10-03'),
('123138', 'test11-11', 'test', '123', 'HHX', '422222', 1, 'TEST', '2018-11-11', '2018-11-11'),
('15728', 'Si ', 'SD', 'asd', 'qsd', '', 0, 'sdfs', '2018-08-29', '2018-08-29');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agenciastrans`
--
ALTER TABLE `agenciastrans`
  ADD PRIMARY KEY (`codtrans`);

--
-- Indices de la tabla `agentes`
--
ALTER TABLE `agentes`
  ADD PRIMARY KEY (`codagente`);

--
-- Indices de la tabla `albaranescli`
--
ALTER TABLE `albaranescli`
  ADD PRIMARY KEY (`idalbaran`),
  ADD UNIQUE KEY `uniq_codigo_albaranescli` (`codigo`),
  ADD KEY `ca_albaranescli_series2` (`codserie`),
  ADD KEY `ca_albaranescli_ejercicios2` (`codejercicio`),
  ADD KEY `ca_albaranescli_facturas` (`idfactura`);

--
-- Indices de la tabla `albaranesprov`
--
ALTER TABLE `albaranesprov`
  ADD PRIMARY KEY (`idalbaran`),
  ADD UNIQUE KEY `uniq_codigo_albaranesprov` (`codigo`),
  ADD KEY `ca_albaranesprov_series2` (`codserie`),
  ADD KEY `ca_albaranesprov_ejercicios2` (`codejercicio`),
  ADD KEY `ca_albaranesprov_facturas` (`idfactura`);

--
-- Indices de la tabla `almacenes`
--
ALTER TABLE `almacenes`
  ADD PRIMARY KEY (`codalmacen`);

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`referencia`),
  ADD KEY `ca_alumnos_impuestos` (`codimpuesto`),
  ADD KEY `ca_alumnos_familias` (`codfamilia`),
  ADD KEY `ca_alumnos_fabricantes` (`codfabricante`),
  ADD KEY `codtutores` (`codtutores`);

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`referencia`),
  ADD KEY `ca_articulos_impuestos` (`codimpuesto`),
  ADD KEY `ca_articulos_familias` (`codfamilia`),
  ADD KEY `ca_articulos_fabricantes` (`codfabricante`);

--
-- Indices de la tabla `articulosprov`
--
ALTER TABLE `articulosprov`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_articulo_proveedor2` (`codproveedor`,`refproveedor`);

--
-- Indices de la tabla `articulo_propiedades`
--
ALTER TABLE `articulo_propiedades`
  ADD PRIMARY KEY (`name`,`referencia`),
  ADD KEY `ca_articulo_propiedades_articulos` (`referencia`);

--
-- Indices de la tabla `articulo_trazas`
--
ALTER TABLE `articulo_trazas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_codigo_articulo_trazas` (`numserie`),
  ADD KEY `ca_articulo_trazas_articulos` (`referencia`),
  ADD KEY `ca_articulo_trazas_linalbcli` (`idlalbventa`),
  ADD KEY `ca_articulo_trazas_linfaccli` (`idlfacventa`),
  ADD KEY `ca_articulo_trazas_linalbprov` (`idlalbcompra`),
  ADD KEY `ca_articulo_trazas_linfacprov` (`idlfaccompra`);

--
-- Indices de la tabla `atributos`
--
ALTER TABLE `atributos`
  ADD PRIMARY KEY (`codatributo`);

--
-- Indices de la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cajas_terminales`
--
ALTER TABLE `cajas_terminales`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`codcliente`),
  ADD KEY `ca_clientes_grupos` (`codgrupo`);

--
-- Indices de la tabla `cliente_propiedades`
--
ALTER TABLE `cliente_propiedades`
  ADD PRIMARY KEY (`name`,`codcliente`),
  ADD KEY `ca_cliente_propiedades_clientes` (`codcliente`);

--
-- Indices de la tabla `co_asientos`
--
ALTER TABLE `co_asientos`
  ADD PRIMARY KEY (`idasiento`),
  ADD KEY `ca_co_asientos_ejercicios2` (`codejercicio`);

--
-- Indices de la tabla `co_codbalances08`
--
ALTER TABLE `co_codbalances08`
  ADD PRIMARY KEY (`codbalance`);

--
-- Indices de la tabla `co_conceptospar`
--
ALTER TABLE `co_conceptospar`
  ADD PRIMARY KEY (`idconceptopar`);

--
-- Indices de la tabla `co_cuentas`
--
ALTER TABLE `co_cuentas`
  ADD PRIMARY KEY (`idcuenta`),
  ADD UNIQUE KEY `uniq_codcuenta` (`codcuenta`,`codejercicio`),
  ADD KEY `ca_co_cuentas_ejercicios` (`codejercicio`),
  ADD KEY `ca_co_cuentas_epigrafes2` (`idepigrafe`);

--
-- Indices de la tabla `co_cuentascbba`
--
ALTER TABLE `co_cuentascbba`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `co_cuentasesp`
--
ALTER TABLE `co_cuentasesp`
  ADD PRIMARY KEY (`idcuentaesp`);

--
-- Indices de la tabla `co_epigrafes`
--
ALTER TABLE `co_epigrafes`
  ADD PRIMARY KEY (`idepigrafe`),
  ADD KEY `ca_co_epigrafes_ejercicios` (`codejercicio`),
  ADD KEY `ca_co_epigrafes_gruposepigrafes2` (`idgrupo`);

--
-- Indices de la tabla `co_gruposepigrafes`
--
ALTER TABLE `co_gruposepigrafes`
  ADD PRIMARY KEY (`idgrupo`),
  ADD KEY `ca_co_gruposepigrafes_ejercicios` (`codejercicio`);

--
-- Indices de la tabla `co_partidas`
--
ALTER TABLE `co_partidas`
  ADD PRIMARY KEY (`idpartida`),
  ADD KEY `ca_co_partidas_co_asientos2` (`idasiento`),
  ADD KEY `ca_co_partidas_subcuentas` (`idsubcuenta`);

--
-- Indices de la tabla `co_regiva`
--
ALTER TABLE `co_regiva`
  ADD PRIMARY KEY (`idregiva`);

--
-- Indices de la tabla `co_secuencias`
--
ALTER TABLE `co_secuencias`
  ADD PRIMARY KEY (`idsecuencia`),
  ADD KEY `ca_co_secuencias_ejercicios` (`codejercicio`);

--
-- Indices de la tabla `co_subcuentas`
--
ALTER TABLE `co_subcuentas`
  ADD PRIMARY KEY (`idsubcuenta`),
  ADD UNIQUE KEY `uniq_codsubcuenta` (`codsubcuenta`,`codejercicio`),
  ADD KEY `ca_co_subcuentas_ejercicios` (`codejercicio`),
  ADD KEY `ca_co_subcuentas_cuentas2` (`idcuenta`);

--
-- Indices de la tabla `co_subcuentascli`
--
ALTER TABLE `co_subcuentascli`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_co_subcuentascli_ejercicios` (`codejercicio`),
  ADD KEY `ca_co_subcuentascli_clientes` (`codcliente`),
  ADD KEY `ca_co_subcuentascli_subcuentas` (`idsubcuenta`);

--
-- Indices de la tabla `co_subcuentasprov`
--
ALTER TABLE `co_subcuentasprov`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_co_subcuentasprov_ejercicios` (`codejercicio`),
  ADD KEY `ca_co_subcuentasprov_proveedores` (`codproveedor`),
  ADD KEY `ca_co_subcuentasprov_subcuentas` (`idsubcuenta`);

--
-- Indices de la tabla `cuentasbanco`
--
ALTER TABLE `cuentasbanco`
  ADD PRIMARY KEY (`codcuenta`);

--
-- Indices de la tabla `cuentasbcocli`
--
ALTER TABLE `cuentasbcocli`
  ADD PRIMARY KEY (`codcuenta`),
  ADD KEY `ca_cuentasbcocli_clientes` (`codcliente`);

--
-- Indices de la tabla `cuentasbcopro`
--
ALTER TABLE `cuentasbcopro`
  ADD PRIMARY KEY (`codcuenta`),
  ADD KEY `ca_cuentasbcopro_proveedores` (`codproveedor`);

--
-- Indices de la tabla `dirclientes`
--
ALTER TABLE `dirclientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_dirclientes_clientes` (`codcliente`);

--
-- Indices de la tabla `dirproveedores`
--
ALTER TABLE `dirproveedores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_dirproveedores_proveedores` (`codproveedor`);

--
-- Indices de la tabla `divisas`
--
ALTER TABLE `divisas`
  ADD PRIMARY KEY (`coddivisa`);

--
-- Indices de la tabla `ejercicios`
--
ALTER TABLE `ejercicios`
  ADD PRIMARY KEY (`codejercicio`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fabricantes`
--
ALTER TABLE `fabricantes`
  ADD PRIMARY KEY (`codfabricante`);

--
-- Indices de la tabla `facturascli`
--
ALTER TABLE `facturascli`
  ADD PRIMARY KEY (`idfactura`),
  ADD UNIQUE KEY `uniq_codigo_facturascli` (`codigo`),
  ADD KEY `ca_facturascli_series2` (`codserie`),
  ADD KEY `ca_facturascli_ejercicios2` (`codejercicio`),
  ADD KEY `ca_facturascli_asiento2` (`idasiento`),
  ADD KEY `ca_facturascli_asientop` (`idasientop`);

--
-- Indices de la tabla `facturasprov`
--
ALTER TABLE `facturasprov`
  ADD PRIMARY KEY (`idfactura`),
  ADD UNIQUE KEY `uniq_codigo_facturasprov` (`codigo`),
  ADD KEY `ca_facturasprov_series2` (`codserie`),
  ADD KEY `ca_facturasprov_ejercicios2` (`codejercicio`),
  ADD KEY `ca_facturasprov_asiento2` (`idasiento`),
  ADD KEY `ca_facturasprov_asientop` (`idasientop`);

--
-- Indices de la tabla `familias`
--
ALTER TABLE `familias`
  ADD PRIMARY KEY (`codfamilia`);

--
-- Indices de la tabla `formaspago`
--
ALTER TABLE `formaspago`
  ADD PRIMARY KEY (`codpago`);

--
-- Indices de la tabla `fs_access`
--
ALTER TABLE `fs_access`
  ADD PRIMARY KEY (`fs_user`,`fs_page`),
  ADD KEY `fs_access_page2` (`fs_page`);

--
-- Indices de la tabla `fs_extensions2`
--
ALTER TABLE `fs_extensions2`
  ADD PRIMARY KEY (`name`,`page_from`),
  ADD KEY `ca_fs_extensions2_fs_pages` (`page_from`);

--
-- Indices de la tabla `fs_logs`
--
ALTER TABLE `fs_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fs_pages`
--
ALTER TABLE `fs_pages`
  ADD PRIMARY KEY (`name`);

--
-- Indices de la tabla `fs_roles`
--
ALTER TABLE `fs_roles`
  ADD PRIMARY KEY (`codrol`);

--
-- Indices de la tabla `fs_roles_access`
--
ALTER TABLE `fs_roles_access`
  ADD PRIMARY KEY (`codrol`,`fs_page`),
  ADD KEY `fs_roles_access_page` (`fs_page`);

--
-- Indices de la tabla `fs_roles_users`
--
ALTER TABLE `fs_roles_users`
  ADD PRIMARY KEY (`codrol`,`fs_user`),
  ADD KEY `fs_roles_users_user` (`fs_user`);

--
-- Indices de la tabla `fs_users`
--
ALTER TABLE `fs_users`
  ADD PRIMARY KEY (`nick`),
  ADD KEY `ca_fs_users_pages` (`fs_page`);

--
-- Indices de la tabla `fs_vars`
--
ALTER TABLE `fs_vars`
  ADD PRIMARY KEY (`name`);

--
-- Indices de la tabla `gruposclientes`
--
ALTER TABLE `gruposclientes`
  ADD PRIMARY KEY (`codgrupo`);

--
-- Indices de la tabla `idiomas_fac_det`
--
ALTER TABLE `idiomas_fac_det`
  ADD PRIMARY KEY (`codidioma`);

--
-- Indices de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  ADD PRIMARY KEY (`codimpuesto`);

--
-- Indices de la tabla `kdb`
--
ALTER TABLE `kdb`
  ADD PRIMARY KEY (`idkdb`);

--
-- Indices de la tabla `lineasalbaranescli`
--
ALTER TABLE `lineasalbaranescli`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_lineasalbaranescli_albaranescli2` (`idalbaran`);

--
-- Indices de la tabla `lineasalbaranesprov`
--
ALTER TABLE `lineasalbaranesprov`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_lineasalbaranesprov_albaranesprov2` (`idalbaran`);

--
-- Indices de la tabla `lineasfacturascli`
--
ALTER TABLE `lineasfacturascli`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_linea_facturascli2` (`idfactura`);

--
-- Indices de la tabla `lineasfacturasprov`
--
ALTER TABLE `lineasfacturasprov`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_linea_facturasprov2` (`idfactura`);

--
-- Indices de la tabla `lineasivafactcli`
--
ALTER TABLE `lineasivafactcli`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_lineaiva_facturascli2` (`idfactura`);

--
-- Indices de la tabla `lineasivafactprov`
--
ALTER TABLE `lineasivafactprov`
  ADD PRIMARY KEY (`idlinea`),
  ADD KEY `ca_lineaiva_facturasprov2` (`idfactura`);

--
-- Indices de la tabla `lineasregstocks`
--
ALTER TABLE `lineasregstocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_lineasregstocks_stocks` (`idstock`);

--
-- Indices de la tabla `lineastransstock`
--
ALTER TABLE `lineastransstock`
  ADD PRIMARY KEY (`idlinea`),
  ADD UNIQUE KEY `uniq_referencia_transferencia` (`idtrans`,`referencia`),
  ADD KEY `ca_linea_transstock_articulos` (`referencia`);

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`codpais`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`codproveedor`);

--
-- Indices de la tabla `secuencias`
--
ALTER TABLE `secuencias`
  ADD PRIMARY KEY (`idsec`),
  ADD KEY `ca_secuencias_secuenciasejercicios` (`id`);

--
-- Indices de la tabla `secuenciasejercicios`
--
ALTER TABLE `secuenciasejercicios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ca_secuenciasejercicios_ejercicios` (`codejercicio`);

--
-- Indices de la tabla `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`codserie`);

--
-- Indices de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD PRIMARY KEY (`codtarifa`);

--
-- Indices de la tabla `ticketprintjob`
--
ALTER TABLE `ticketprintjob`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `transstock`
--
ALTER TABLE `transstock`
  ADD PRIMARY KEY (`idtrans`);

--
-- Indices de la tabla `tutores`
--
ALTER TABLE `tutores`
  ADD PRIMARY KEY (`referencia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `albaranescli`
--
ALTER TABLE `albaranescli`
  MODIFY `idalbaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT de la tabla `albaranesprov`
--
ALTER TABLE `albaranesprov`
  MODIFY `idalbaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `articulosprov`
--
ALTER TABLE `articulosprov`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `articulo_trazas`
--
ALTER TABLE `articulo_trazas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `cajas`
--
ALTER TABLE `cajas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `cajas_terminales`
--
ALTER TABLE `cajas_terminales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `co_asientos`
--
ALTER TABLE `co_asientos`
  MODIFY `idasiento` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_cuentas`
--
ALTER TABLE `co_cuentas`
  MODIFY `idcuenta` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_cuentascbba`
--
ALTER TABLE `co_cuentascbba`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_epigrafes`
--
ALTER TABLE `co_epigrafes`
  MODIFY `idepigrafe` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_gruposepigrafes`
--
ALTER TABLE `co_gruposepigrafes`
  MODIFY `idgrupo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_partidas`
--
ALTER TABLE `co_partidas`
  MODIFY `idpartida` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_regiva`
--
ALTER TABLE `co_regiva`
  MODIFY `idregiva` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_secuencias`
--
ALTER TABLE `co_secuencias`
  MODIFY `idsecuencia` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_subcuentas`
--
ALTER TABLE `co_subcuentas`
  MODIFY `idsubcuenta` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_subcuentascli`
--
ALTER TABLE `co_subcuentascli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `co_subcuentasprov`
--
ALTER TABLE `co_subcuentasprov`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dirclientes`
--
ALTER TABLE `dirclientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `dirproveedores`
--
ALTER TABLE `dirproveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `facturascli`
--
ALTER TABLE `facturascli`
  MODIFY `idfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `facturasprov`
--
ALTER TABLE `facturasprov`
  MODIFY `idfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `fs_logs`
--
ALTER TABLE `fs_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=411;
--
-- AUTO_INCREMENT de la tabla `lineasalbaranescli`
--
ALTER TABLE `lineasalbaranescli`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=931;
--
-- AUTO_INCREMENT de la tabla `lineasalbaranesprov`
--
ALTER TABLE `lineasalbaranesprov`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `lineasfacturascli`
--
ALTER TABLE `lineasfacturascli`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=655;
--
-- AUTO_INCREMENT de la tabla `lineasfacturasprov`
--
ALTER TABLE `lineasfacturasprov`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `lineasivafactcli`
--
ALTER TABLE `lineasivafactcli`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `lineasivafactprov`
--
ALTER TABLE `lineasivafactprov`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `lineasregstocks`
--
ALTER TABLE `lineasregstocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `lineastransstock`
--
ALTER TABLE `lineastransstock`
  MODIFY `idlinea` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `secuencias`
--
ALTER TABLE `secuencias`
  MODIFY `idsec` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `secuenciasejercicios`
--
ALTER TABLE `secuenciasejercicios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `ticketprintjob`
--
ALTER TABLE `ticketprintjob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `transstock`
--
ALTER TABLE `transstock`
  MODIFY `idtrans` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `albaranescli`
--
ALTER TABLE `albaranescli`
  ADD CONSTRAINT `ca_albaranescli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_albaranescli_facturas` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_albaranescli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `albaranesprov`
--
ALTER TABLE `albaranesprov`
  ADD CONSTRAINT `ca_albaranesprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_albaranesprov_facturas` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_albaranesprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD CONSTRAINT `ca_alumnos_fabricantes` FOREIGN KEY (`codfabricante`) REFERENCES `fabricantes` (`codfabricante`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_alumnos_familias` FOREIGN KEY (`codfamilia`) REFERENCES `familias` (`codfamilia`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_alumnos_impuestos` FOREIGN KEY (`codimpuesto`) REFERENCES `impuestos` (`codimpuesto`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD CONSTRAINT `ca_articulos_fabricantes` FOREIGN KEY (`codfabricante`) REFERENCES `fabricantes` (`codfabricante`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulos_familias` FOREIGN KEY (`codfamilia`) REFERENCES `familias` (`codfamilia`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulos_impuestos` FOREIGN KEY (`codimpuesto`) REFERENCES `impuestos` (`codimpuesto`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `articulosprov`
--
ALTER TABLE `articulosprov`
  ADD CONSTRAINT `ca_articulosprov_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `articulo_propiedades`
--
ALTER TABLE `articulo_propiedades`
  ADD CONSTRAINT `ca_articulo_propiedades_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `articulo_trazas`
--
ALTER TABLE `articulo_trazas`
  ADD CONSTRAINT `ca_articulo_trazas_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulo_trazas_linalbcli` FOREIGN KEY (`idlalbventa`) REFERENCES `lineasalbaranescli` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulo_trazas_linalbprov` FOREIGN KEY (`idlalbcompra`) REFERENCES `lineasalbaranesprov` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulo_trazas_linfaccli` FOREIGN KEY (`idlfacventa`) REFERENCES `lineasfacturascli` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_articulo_trazas_linfacprov` FOREIGN KEY (`idlfaccompra`) REFERENCES `lineasfacturasprov` (`idlinea`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `ca_clientes_grupos` FOREIGN KEY (`codgrupo`) REFERENCES `gruposclientes` (`codgrupo`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `cliente_propiedades`
--
ALTER TABLE `cliente_propiedades`
  ADD CONSTRAINT `ca_cliente_propiedades_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_asientos`
--
ALTER TABLE `co_asientos`
  ADD CONSTRAINT `ca_co_asientos_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_cuentas`
--
ALTER TABLE `co_cuentas`
  ADD CONSTRAINT `ca_co_cuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_cuentas_epigrafes2` FOREIGN KEY (`idepigrafe`) REFERENCES `co_epigrafes` (`idepigrafe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_epigrafes`
--
ALTER TABLE `co_epigrafes`
  ADD CONSTRAINT `ca_co_epigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_epigrafes_gruposepigrafes2` FOREIGN KEY (`idgrupo`) REFERENCES `co_gruposepigrafes` (`idgrupo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_gruposepigrafes`
--
ALTER TABLE `co_gruposepigrafes`
  ADD CONSTRAINT `ca_co_gruposepigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_partidas`
--
ALTER TABLE `co_partidas`
  ADD CONSTRAINT `ca_co_partidas_co_asientos2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_partidas_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_secuencias`
--
ALTER TABLE `co_secuencias`
  ADD CONSTRAINT `ca_co_secuencias_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_subcuentas`
--
ALTER TABLE `co_subcuentas`
  ADD CONSTRAINT `ca_co_subcuentas_cuentas2` FOREIGN KEY (`idcuenta`) REFERENCES `co_cuentas` (`idcuenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_subcuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_subcuentascli`
--
ALTER TABLE `co_subcuentascli`
  ADD CONSTRAINT `ca_co_subcuentascli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_subcuentascli_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_subcuentascli_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `co_subcuentasprov`
--
ALTER TABLE `co_subcuentasprov`
  ADD CONSTRAINT `ca_co_subcuentasprov_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_subcuentasprov_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_co_subcuentasprov_subcuentas` FOREIGN KEY (`idsubcuenta`) REFERENCES `co_subcuentas` (`idsubcuenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `cuentasbcocli`
--
ALTER TABLE `cuentasbcocli`
  ADD CONSTRAINT `ca_cuentasbcocli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `cuentasbcopro`
--
ALTER TABLE `cuentasbcopro`
  ADD CONSTRAINT `ca_cuentasbcopro_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `dirclientes`
--
ALTER TABLE `dirclientes`
  ADD CONSTRAINT `ca_dirclientes_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `dirproveedores`
--
ALTER TABLE `dirproveedores`
  ADD CONSTRAINT `ca_dirproveedores_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `facturascli`
--
ALTER TABLE `facturascli`
  ADD CONSTRAINT `ca_facturascli_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturascli_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturascli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturascli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `facturasprov`
--
ALTER TABLE `facturasprov`
  ADD CONSTRAINT `ca_facturasprov_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturasprov_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturasprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_facturasprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `fs_access`
--
ALTER TABLE `fs_access`
  ADD CONSTRAINT `fs_access_page2` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fs_access_user2` FOREIGN KEY (`fs_user`) REFERENCES `fs_users` (`nick`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fs_extensions2`
--
ALTER TABLE `fs_extensions2`
  ADD CONSTRAINT `ca_fs_extensions2_fs_pages` FOREIGN KEY (`page_from`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fs_roles_access`
--
ALTER TABLE `fs_roles_access`
  ADD CONSTRAINT `fs_roles_access_page` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fs_roles_access_roles` FOREIGN KEY (`codrol`) REFERENCES `fs_roles` (`codrol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fs_roles_users`
--
ALTER TABLE `fs_roles_users`
  ADD CONSTRAINT `fs_roles_users_roles` FOREIGN KEY (`codrol`) REFERENCES `fs_roles` (`codrol`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fs_roles_users_user` FOREIGN KEY (`fs_user`) REFERENCES `fs_users` (`nick`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fs_users`
--
ALTER TABLE `fs_users`
  ADD CONSTRAINT `ca_fs_users_pages` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasalbaranescli`
--
ALTER TABLE `lineasalbaranescli`
  ADD CONSTRAINT `ca_lineasalbaranescli_albaranescli2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranescli` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasalbaranesprov`
--
ALTER TABLE `lineasalbaranesprov`
  ADD CONSTRAINT `ca_lineasalbaranesprov_albaranesprov2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranesprov` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasfacturascli`
--
ALTER TABLE `lineasfacturascli`
  ADD CONSTRAINT `ca_linea_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasfacturasprov`
--
ALTER TABLE `lineasfacturasprov`
  ADD CONSTRAINT `ca_linea_facturasprov2` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasivafactcli`
--
ALTER TABLE `lineasivafactcli`
  ADD CONSTRAINT `ca_lineaiva_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasivafactprov`
--
ALTER TABLE `lineasivafactprov`
  ADD CONSTRAINT `ca_lineaiva_facturasprov2` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineasregstocks`
--
ALTER TABLE `lineasregstocks`
  ADD CONSTRAINT `ca_lineasregstocks_stocks` FOREIGN KEY (`idstock`) REFERENCES `stocks` (`idstock`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `lineastransstock`
--
ALTER TABLE `lineastransstock`
  ADD CONSTRAINT `ca_linea_transstock` FOREIGN KEY (`idtrans`) REFERENCES `transstock` (`idtrans`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ca_linea_transstock_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `secuencias`
--
ALTER TABLE `secuencias`
  ADD CONSTRAINT `ca_secuencias_secuenciasejercicios` FOREIGN KEY (`id`) REFERENCES `secuenciasejercicios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `secuenciasejercicios`
--
ALTER TABLE `secuenciasejercicios`
  ADD CONSTRAINT `ca_secuenciasejercicios_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

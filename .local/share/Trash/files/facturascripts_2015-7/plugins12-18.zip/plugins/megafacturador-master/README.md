# megafacturador
Plugin que permite convertir en facturas múltiples albaranes de compra o venta con un solo clic.

https://www.facturascripts.com/plugin/megafacturador
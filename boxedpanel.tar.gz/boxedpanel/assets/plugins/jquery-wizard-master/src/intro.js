/*
 * jQuery Wizard
 * https://github.com/amazingSurge/jQuery-Wizard
 *
 * Copyright (c) 2015 amazingSurge
 * Licensed under the MIT license.
 */
(function($, document, window, undefined) {
    "use strict";
